#' Computes the quadratic mean of a numeric vector. It is the square
#' root of the product of n numbers, as follows.
#' \deqn{y_g = \sqrt{ \left(\sum_{i=1}^{2} y_i\right) /n}}.
#'  The quadratic mean can be used a central position statistics of
#' a random variable.
#'
#' @details It is different from the arithmetic mean.
#'
#' @title Function to compute the quadratic mean of a numeric vector
#' @param y is a numeric vector
#'
#' @return This function returns the quadratic mean, a numeric scalar.
#' @author Christian Salas-Eljatib.
#' @references
#' Salas-Eljatib, C. 2021. Análisis de datos con el programa
#'  estadístico R: una introducción  aplicada. Ediciones
#'  Universidad Mayor, Santiago, Chile. 170 p.
#'  \url{https://eljatib.com/rlibro}
#' @examples
#'
#' y.var <- rnorm(16, 30, sd=19)
#' qmean(y.var)
#' @rdname qmean
#' @export
#'
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
qmean <- function(y){
    sqrt(
    ( (sum(y^2)) /length(y) ) 
       )
}

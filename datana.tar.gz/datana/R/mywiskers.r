# This is a handy function for looking for trends in residuals etc.
# xlim: x-axis limits (NULL = the range of x); ...: further options of
# plot() (or points() when add=TRUE)
mywhiskers<-function(x,y,nclass=10,limits=NA,add=FALSE,se=TRUE,
                     main="",xlab="x",ylab="y",ylim=NA,xlim=NULL,lwd=1, xaxs = "r", yaxs = "r", ...) {

  ##- axis style as in par(): "r" (regular) or "i" (internal)
  if(!(is.character(xaxs) && length(xaxs)==1 && xaxs %in% c("r","i")))
    stop("mywhiskers(): 'xaxs' must be \"r\" or \"i\".")
  if(!(is.character(yaxs) && length(yaxs)==1 && yaxs %in% c("r","i")))
    stop("mywhiskers(): 'yaxs' must be \"r\" or \"i\".")
  op.ax <- graphics::par(xaxs = xaxs, yaxs = yaxs)
  on.exit(graphics::par(op.ax), add = TRUE)
            away<-is.na(x+y);
            x<-x[!away];
            y<-y[!away];
  if (is.na(limits[1])) limits<-seq(min(x),max(x)+1e-10,length=nclass+1) else nclass=length(limits)-1
  means<-sapply(1:nclass,function(i) mean(y[x>=limits[i]&x<limits[i+1]]));
  if(se){ses<-sapply(1:nclass,function(i) stats::sd(y[x>=limits[i]&x<limits[i+1]])/
                                                         sqrt(sum(x>=limits[i]&x<limits[i+1])))
                    } else {
                    ses<-sapply(1:nclass,function(i) stats::sd(y[x>=limits[i]&x<limits[i+1]]))
                    }
            lb<-means-1.96*ses;ub<-means+1.96*ses;
            xclass<-1/2*(limits[-1]+limits[-nclass-1]);
            if (add) {
               graphics::points(xclass,means,...); 
               } else {
               if(is.na(ylim[1])) ylim<-c(min(lb),max(ub))
               plot(xclass,means,ylim=ylim,main=main,xlab=xlab,ylab=ylab,xlim=if(is.null(xlim)) range(x) else xlim,...);
               }
            sapply(1:nclass,function(i) graphics::lines(xclass[c(i,i)],c(lb[i],ub[i]),lwd=lwd));
    invisible()
}

# xlim: x-axis limits (NULL = from the data); col: color of the points;
# ...: further options of plot()
resplot2<-function(x,res,limits=NA,ylim=range(res),xlim=NULL,col="gray",
    xlab="x",ylab="res",main="", xaxs = "r", yaxs = "r", ...) {

  ##- axis style as in par(): "r" (regular) or "i" (internal)
  if(!(is.character(xaxs) && length(xaxs)==1 && xaxs %in% c("r","i")))
    stop("resplot2(): 'xaxs' must be \"r\" or \"i\".")
  if(!(is.character(yaxs) && length(yaxs)==1 && yaxs %in% c("r","i")))
    stop("resplot2(): 'yaxs' must be \"r\" or \"i\".")
  op.ax <- graphics::par(xaxs = xaxs, yaxs = yaxs)
  on.exit(graphics::par(op.ax), add = TRUE)
    plot(x,res,col=col,xlim=xlim,ylim=ylim,xlab=xlab,ylab=ylab,main=main,...)
    mywhiskers(x,res,add=TRUE,lwd=5,limits=limits)
    graphics::abline(0,0)
    mywhiskers2(x,res,se=FALSE,add=TRUE,limits=limits)   
}

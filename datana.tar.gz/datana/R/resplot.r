# xlim: x-axis limits (NULL = from the data); col: color of the points;
# ...: further options of plot()
resplot<-function(x,res,limits=NA,ylim=range(res),xlim=NULL,col="red",xlab="x",
                  ylab="res",las=1, main="",..., xaxs = "r", yaxs = "r"){

  ##- axis style as in par(): "r" (regular) or "i" (internal)
  if(!(is.character(xaxs) && length(xaxs)==1 && xaxs %in% c("r","i")))
    stop("resplot(): 'xaxs' must be \"r\" or \"i\".")
  if(!(is.character(yaxs) && length(yaxs)==1 && yaxs %in% c("r","i")))
    stop("resplot(): 'yaxs' must be \"r\" or \"i\".")
  op.ax <- graphics::par(xaxs = xaxs, yaxs = yaxs)
  on.exit(graphics::par(op.ax), add = TRUE)
 plot(x,res,col=col,xlim=xlim,ylim=ylim,xlab=xlab,ylab=ylab,las=las,main=main,...)
 mywhiskers(x,res,add=TRUE,lwd=5,limits=limits);
 graphics::abline(0,0)
 mywhiskers(x,res,se=FALSE,add=TRUE,limits=limits);
}
#' # Creates a fake dataframe
#' set.seed(1234)
#' df <- as.data.frame(cbind(Y=rnorm(30, 30,9), X=rexp(30,rate=0.9)))
#' head(df)
#' descstat(df)
#' plot(Y~X, data=df)
#' # Fitting a candidate model
#' mod1 <- lm(Y~X, data=df)
#' #Using the resplot function
#' resplot(x = df$X, res=residuals(mod1))

##- Inside ggplot2::aes() the columns of the long-format plot data are
##- referred to by their bare names ('value' and 'f2', built further
##- below), which R CMD check cannot see as bindings. Declared here so
##- the check does not report "no visible binding for global variable".
utils::globalVariables(c("value", "f2"))

#' Produces a time series plot, of variable 'y' as a function of 'x' by
#' an observational unit factor.
#'
#'   Both 'y' and 'x' must be numeric variables, and the column representing
#'   the observational unit, must be
#'   a factor. This factor identifies the longitudinal context of the data,
#'    for instance, a student
#'   being measured on time. Besides, two more factors can be added to the
#'   plotting details, in order
#'    to represent the potential variability among them.
#'
#'
#' @title Produces a time series plot
#' @param data a dataframe with at least tree columns representing the
#' response variable ("y"),
#'   the main predictor variable ("x"), and a variable indicating the
#'   observational unit ("obs.unit").
#' @param y a character vector with the name(s) of the response
#' variable(s), i.e. of the column(s) of `data` to be plotted against
#' `x`. If two or more variables are given (e.g. `y = c("gha","nha")`),
#' one panel row is arranged per variable, in the order given (first
#' row for the first variable, second row for the second one, and so
#' on). The y-axis scale is shared within a row (i.e. across the
#' levels of `factvar1`) and free between rows, since the variables may
#' have different units.
#' @param x a character giving the column name of the main predictor
#' variable. Generally this variable
#' is time.
#' @param obs.unit a character giving the column name containing the info
#' of the observational unit.
#' @param factvar1 an optional character having the name of a column having
#' a factor variable (e.g., treatment). The
#'  detault value is set to NULL.
#' @param factvar2 an optional character having the name of a column having
#' another factor variable (e.g., species). The
#'  detault value is set to NULL. Notice that `factvar2` cannot be
#'  used if `factvar1` is not provided.
#' @param only.lines a logic value if only lines, but not including dots,
#'  are going to be drwan in the plot. The detault
#'  value is set to FALSE.
#' @param xlab Label for the X-axis
#' @param ylab Label for the Y-axis. In the multi-response case it can
#' be a vector with one label per `y` variable (e.g. the labels created
#' with `biometrics::labelsGraph()`), and each one will be used as the
#' Y-axis label of its row-panel (i.e. on the y-axis, at the left of
#' each row), instead of a single overall axis label.
#' @param linetype.lab is an optional string to be used as the title of the
#'  factor being represented by lines. It is only
#'  needed if factvar1 and factvar2 are defined. See example.
#' @param factvar2.line a logic value if the second factor, factvar2, is going
#'  to be segregated according to the
#'  type of lines. The detault  value is set to TRUE.
#' @param factvar2.col a logic value if the second factor, factvar2, is going to
#'  be segregated according to the
#'  color of the lines only. The detault  value is set to FALSE.
#' @param max.y.all A number representing the maximum level of Y-axis for all
#' classes
#' @param levels.i.want A vector having the levels for the factor under study
#' @param col.lev.i.want A vector having the colors to be used for the factor
#'  under study
#' @param col.lines A string specifying the single color to be used for the
#'  lines of the timeseries
#' @param mfrow an optional numeric vector of two positive integers, e.g.
#'  `mfrow = c(2, 1)`, mimicking the `mfrow` option of [graphics::par()]
#'  of base R. It gives the number of rows and columns in which the
#'  panels will be arranged, filling them by rows. It is considered
#'  when `factvar1` is provided, or when several `y` variables are given
#'  without `factvar1`. In the multi-response case with `factvar1` the
#'  panel layout is fixed (rows = variables, columns = levels of
#'  `factvar1`), thus this option is ignored (with a message).
#'  The default value is set to NA, thus a default panel layout is used.
#' @param mfcol as `mfrow`, but the panels are filled by columns,
#'  mimicking the `mfcol` option of [graphics::par()] of base R. Only
#'  one of `mfrow` or `mfcol` can be used at a time.
#' @param ylim an optional specification of the y-axis limits, one per
#'  response variable. It can be a numeric vector of length two,
#'  `c(ymin, ymax)`, shared by all the response variables, or a list
#'  with one such vector per `y` variable (e.g.
#'  `ylim = list(nha = c(0, 1000), gha = c(0, 30))`). As in the `ylim`
#'  of base R, the values outside the limits are not drawn, and the
#'  data given by the user are never modified. An `NA` as either bound
#'  means that side is left to the data (e.g. `c(0, NA)` starts the
#'  axis at zero). The default value is set to NA, thus the limits are
#'  taken from the data.
#' @param ylim.start.zero a logical value. If `TRUE`, the y-axis of
#'  every response variable starts at zero (a shortcut for a zero lower
#'  bound; a lower bound explicitly given in `ylim` takes precedence).
#'  By default is set to `FALSE`.
#' @param xaxis.all a logical value. If `TRUE`, the x-axis (ticks and
#'  numbers) is drawn for every row of panels; by default (`FALSE`) only
#'  the bottom row of panels draws the x-axis. In any case the x-axis
#'  label (title) is printed only at the very bottom of the figure.
#' @param xlim an optional numeric vector of length two, `c(xmin, xmax)`,
#'  with the limits of the x-axis, shared by all the panels (the rows of
#'  a multi-response plot share the same x variable). As in the `xlim`
#'  of base R, values outside the limits are not drawn. An `NA` as
#'  either bound means that side is left to the data. The default value
#'  is set to NA.
#' @param xaxs axis style of the x-axis, as in [graphics::par()] of
#'  base R: `"r"` (the default) leaves the usual expansion of the axis
#'  beyond the data, and `"i"` draws the axis exactly at the limits of
#'  the data.
#' @param yaxs as `xaxs`, but for the y-axis. With `yaxs = "i"` (and
#'  e.g. `ylim.start.zero = TRUE`) the y and x axes meet at the origin
#'  of the data, e.g. at the 0,0 coordinate.
#' @param ... additional options of the [ggplot2::theme()] function,
#'  which allow the user to modify any theme element of the plot (e.g.
#'  `strip.placement`, `strip.text.y.left`, `axis.text.x`, `text`).
#'  They are applied after the internal theme of the function, thus
#'  the values given here take precedence. See [ggplot2::theme()] for
#'  the full list of available options.
#'
#' @return This function returns a time series plot
#' @author Christian Salas-Eljatib
#' @references
#' Salas-Eljatib, C. 2021. Análisis de datos con el programa estadístico R:
#' una introducción
#'  aplicada. Ediciones Universidad Mayor, Santiago, Chile. 170 p.
#'   \url{https://eljatib.com/rlibro}
#' @note Please, uses the function with caution, and run first the examples to
#'  understand it better.
#' @examples
#' data(ficdiamgr, package="datana")
#' df <- ficdiamgr
#' head(df)
#' str(df)
#' df$site<-as.factor(df$site)
#' df$species<-as.factor(df$species)
#' table(df$tree,df$species)
#' table(df$species,df$site)
#'#
#' timeserplot(df, y="dbh", x="time", obs.unit = "tree")
#' timeserplot(df, y="dbh", x="time", obs.unit = "tree", only.lines = TRUE)
#'#
#'## Otros ejemplos de uso de la funcion
#'timeserplot(df, y="dbh", x="time", obs.unit = "tree", col.lines = "blue",
#' only.lines = TRUE)
#' timeserplot(df, y="dbh", x="time", obs.unit = "tree", only.lines = FALSE)
#'#
#'timeserplot(df, y="dbh", x="time", obs.unit = "tree", factvar1="site")
#'timeserplot(df, y="dbh", x="time", obs.unit = "tree", factvar1="site",
#' factvar2= "species")
#' timeserplot(df, y="dbh", x="time", obs.unit = "tree", factvar1="site",
#'  factvar2= "species", factvar2.col = TRUE, only.lines = TRUE)
#'#
#'## deciding the panel layout (rows x columns), as par(mfrow) does
#' timeserplot(df, y="dbh", x="time", obs.unit = "tree", factvar1="site",
#'  mfrow=c(1,2))
#' timeserplot(df, y="dbh", x="time", obs.unit = "tree", factvar1="site",
#'  factvar2="species", mfrow=c(2,1))
#'#
#'## several response variables: one row per variable
#' df2 <- ficdiamgr
#' df2$ba <- pi*(df2$dbh/200)^2
#' timeserplot(df2, y=c("dbh","ba"), x="time", obs.unit="tree")
#' ## now adding a factvar1 (rows = variables, cols = levels of factvar1)
#' timeserplot(df2, y=c("dbh","ba"), x="time", obs.unit="tree",
#'  factvar1="site")
#' ## filling the panels by columns, as par(mfcol=c(2,1)) does
#' timeserplot(df2, y=c("dbh","ba"), x="time", obs.unit="tree",
#'  mfcol=c(2,1))
#' ## the y-axis of every response variable starts at zero
#' timeserplot(df2, y=c("dbh","ba"), x="time", obs.unit="tree",
#'  ylim.start.zero = TRUE)
#' ## or the user gives the limits of each response variable
#' timeserplot(df2, y=c("dbh","ba"), x="time", obs.unit="tree",
#'  ylim = list(dbh = c(0, 110), ba = c(0, 0.7)))
#' ## x-axis numbers are drawn for every row of panels by default;
#' ## with xaxis.all = FALSE only the bottom row keeps them
#' timeserplot(df2, y=c("dbh","ba"), x="time", obs.unit="tree",
#'  xaxis.all = FALSE)
#' ## axes meeting at the origin of the data (no axis expansion)
#' timeserplot(df2, y=c("dbh","ba"), x="time", obs.unit="tree",
#'  ylim.start.zero = TRUE, xaxs = "i", yaxs = "i")
#' @rdname timeserplot
#' @export
#' @importFrom stats setNames
#'
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
timeserplot <- function(data=data, y=y, x=x, obs.unit=obs.unit,
                        factvar1 = NA, factvar2=NA,only.lines=FALSE,
                        ylab=NA, xlab=NA,linetype.lab=NA,
                factvar2.line=TRUE,factvar2.col=FALSE,col.lines="black",
                max.y.all=NA,levels.i.want=FALSE, col.lev.i.want=FALSE,
                mfrow=NA, mfcol=NA, ylim=NA, xlim=NA, ylim.start.zero=FALSE,
                xaxis.all=FALSE, xaxs="r", yaxs="r", ...){
  db<-data;

  if(prod(is.na(factvar1))){has.factvar1 <-0} else {has.factvar1 <-1}
  if(prod(is.na(factvar2))){has.factvar2 <-0} else {has.factvar2 <-1}

  ##- factvar2 is only allowed if factvar1 is provided
  if(has.factvar1==0 & has.factvar2==1){
    stop("timeserplot(): the option 'factvar2' cannot be used if 'factvar1' is not provided.")
  }

  ##- number of response variables
  y <- unique(y)
  num.y <- length(y)
  has.multiy <- num.y > 1
  if(has.multiy){
    mis.y <- setdiff(y, names(db))
    if(length(mis.y) > 0)
      stop("timeserplot(): the column(s) ", paste0("'", mis.y, "'", collapse=", "),
           " of option 'y' were not found in 'data'.")
  }

  ##- y-axis limits, one per response variable. They can be given with
  ##- 'ylim' (a numeric vector c(ymin, ymax) shared by all the responses,
  ##- or a list with one such vector per 'y' variable), and/or with
  ##- 'ylim.start.zero' (zero as the lower bound for every response).
  ##- NA as either bound means: let the data decide that side. As in the
  ##- ylim of base R, the values outside the limits are not drawn; the
  ##- data given by the user are never modified.
  lim.list <- setNames(rep(list(c(NA_real_, NA_real_)), num.y), y)
  has.lim <- FALSE
  if(!(is.atomic(ylim) && all(is.na(ylim)))){
    if(is.numeric(ylim) && length(ylim)==2){
      for(i in seq_along(y)){lim.list[[i]] <- as.numeric(ylim)}
    } else if(is.list(ylim)){
      if(length(ylim) > 0){
        if(is.null(names(ylim)) || any(names(ylim)=="")){
          if(length(ylim) != num.y)
            stop("timeserplot(): an unnamed 'ylim' list must have one element per 'y' variable.")
          names(ylim) <- y
        }
        bad <- setdiff(names(ylim), y)
        if(length(bad) > 0)
          stop("timeserplot(): the names of 'ylim' must be among the 'y' variables: ",
               paste(y, collapse=", "))
        for(nm in names(ylim)){
          v <- ylim[[nm]]
          if(!is.numeric(v) || length(v)!=2)
            stop("timeserplot(): each element of 'ylim' must be a numeric vector of length two, e.g. c(0, 30).")
          lim.list[[nm]] <- as.numeric(v)
        }
      }
    } else {
      stop("timeserplot(): 'ylim' must be a numeric vector of length two, or a list with one such vector per 'y' variable.")
    }
    has.lim <- TRUE
  }
  if(!is.logical(ylim.start.zero) || length(ylim.start.zero)!=1 ||
     is.na(ylim.start.zero)){
    stop("timeserplot(): 'ylim.start.zero' must be TRUE or FALSE.")
  }
  if(ylim.start.zero){
    for(i in seq_along(y)){
      v <- lim.list[[i]]
      if(is.na(v[1])){v[1] <- 0}
      lim.list[[i]] <- v
    }
    has.lim <- TRUE
  }

  ##- x-axis limits: a single numeric vector c(xmin, xmax) shared by all
  ##- the panels (the rows share the same x variable); NA on either side
  ##- means that side is left to the data
  has.xlim <- FALSE
  xlim.v <- c(NA_real_, NA_real_)
  if(!(is.atomic(xlim) && all(is.na(xlim)))){
    if(is.numeric(xlim) && length(xlim)==2){
      xlim.v <- as.numeric(xlim)
      has.xlim <- TRUE
    } else {
      stop("timeserplot(): 'xlim' must be a numeric vector of length two, e.g. c(0, 100).")
    }
  }
  if(has.xlim){
    xr <- range(db[[x]], na.rm = TRUE)
    if(is.na(xlim.v[1])){xlim.v[1] <- xr[1]}
    if(is.na(xlim.v[2])){xlim.v[2] <- xr[2]}
  }

  ##- the x-axis (ticks and numbers) is drawn for every row of panels,
  ##- not only for the bottom one; the x-axis label (title) is printed
  ##- only at the very bottom
  if(!is.logical(xaxis.all) || length(xaxis.all)!=1 || is.na(xaxis.all)){
    stop("timeserplot(): 'xaxis.all' must be TRUE or FALSE.")
  }
  axes.h <- if(xaxis.all){"all_x"} else {"margins"}

  ##- axis expansion in the style of base R: "r" (regular: the usual
  ##- expansion of the axis beyond the data) or "i" (internal: the axes
  ##- meet exactly at the limits of the data; e.g. with ylim.start.zero
  ##- and data starting at zero, the axes meet at the 0,0 coordinate)
  if(!(is.character(xaxs) && length(xaxs)==1 && xaxs %in% c("r","i")))
    stop("timeserplot(): 'xaxs' must be \"r\" or \"i\".")
  if(!(is.character(yaxs) && length(yaxs)==1 && yaxs %in% c("r","i")))
    stop("timeserplot(): 'yaxs' must be \"r\" or \"i\".")
  scale.x.h <- NULL
  scale.y.h <- NULL
  ##- an axis with explicit limits (or with xaxs/yaxs="i") is drawn
  ##- exactly at those limits, as in the xlim/ylim of base R
  if(xaxs=="i" || has.xlim){
    scale.x.h <- if(is.numeric(db[[x]])){
      ggplot2::scale_x_continuous(expand = ggplot2::expansion(mult = 0))
    } else {
      ggplot2::scale_x_discrete(expand = ggplot2::expansion(mult = 0))
    }
  }
  if(yaxs=="i" || has.lim){
    scale.y.h <- ggplot2::scale_y_continuous(expand = ggplot2::expansion(mult = 0))
  }

  ##- panel layout (as par(mfrow)/par(mfcol) of base R)
  if(prod(is.na(mfrow))){has.mfrow <-0} else {has.mfrow <-1}
  if(prod(is.na(mfcol))){has.mfcol <-0} else {has.mfcol <-1}
  if(has.mfrow==1 & has.mfcol==1){
    stop("timeserplot(): use only one of 'mfrow' or 'mfcol', not both.")
  }
  if(has.mfrow==1 || has.mfcol==1){
    lay <- if(has.mfrow==1) mfrow else mfcol
    if(!is.numeric(lay) || length(lay)!=2 || any(is.na(lay)) ||
       any(lay<=0) || any(lay!=round(lay))){
      stop("timeserplot(): 'mfrow'/'mfcol' must be a numeric vector of two positive integers, e.g. mfrow=c(2,3).")
    }
    lay.name <- if(has.mfrow==1) "mfrow" else "mfcol"
    if(has.multiy & has.factvar1==1){
      message("timeserplot(): in the multi-response case the panel layout is fixed (one row per 'y' variable, one column per level of 'factvar1'), thus '", lay.name, "' is being ignored.")
      has.mfrow <- 0
      has.mfcol <- 0
    } else if(!has.multiy & has.factvar1==0){
      message("timeserplot(): the option '", lay.name, "' is only considered when 'factvar1' is provided or when several 'y' variables are given (and 'factvar1' is not), thus it is ignored.")
      has.mfrow <- 0
      has.mfcol <- 0
    }
  }

  ##- additional theme() options given by the user through '...';
  ##- they are applied at the very end, thus they can modify any
  ##- theme element used internally by this function
  user.dots <- list(...)
  user.theme <- NULL
  if(length(user.dots) > 0){
    ##- the old names of the renamed options must not be silently taken
    ##- as theme() options
    old.names <- c("factor1"="factvar1", "factor2"="factvar2",
                   "factor2.line"="factvar2.line", "factor2.col"="factvar2.col")
    hit <- intersect(names(user.dots), names(old.names))
    if(length(hit) > 0)
      stop("timeserplot(): the option '", hit[1], "' was renamed to '",
           old.names[[hit[1]]], "'; please use the new name.")
    user.theme <- do.call(ggplot2::theme, user.dots)
  }

  ##- axis and legend labels
  if(is.atomic(xlab) && all(is.na(xlab))){xlab.h<-x} else {xlab.h <- xlab}
  if(is.atomic(ylab) && all(is.na(ylab))){ylab.h<-y} else {ylab.h <- ylab}
  if(is.atomic(linetype.lab) && all(is.na(linetype.lab))){
    linetype.lab.h<-factvar2} else {linetype.lab.h <- linetype.lab}

  ##+ (multi) several response variables: one panel row per variable
  if(has.multiy){
    n <- nrow(db)
    ##- [[ ]] returns plain vectors also for tibbles (e.g. dplyr results)
    dfL <- data.frame(
      obs.unit = rep(db[[obs.unit]], num.y),
      x        = rep(db[[x]], num.y),
      value    = unlist(lapply(y, function(v) db[[v]]), use.names = FALSE),
      respvar  = rep(y, each = n),
      stringsAsFactors = FALSE)
    if(has.factvar1==1){dfL$f1 <- rep(db[[factvar1]], num.y)}
    if(has.factvar2==1){dfL$f2 <- rep(db[[factvar2]], num.y)}
    ##- panel labels: one per response (e.g. from biometrics::labelsGraph())
    if(is.atomic(ylab) && all(is.na(ylab))){
      lab.h <- y
    } else if(length(ylab) == num.y){
      lab.h <- ylab
    } else {
      message("timeserplot(): in the multi-response case 'ylab' must have one label per 'y' variable, thus the variable names are used instead.")
      lab.h <- y
    }
    lab.str <- vapply(seq_along(lab.h), function(i) {
      one <- if(is.expression(lab.h)) lab.h[[i]] else lab.h[i]
      paste(deparse(one), collapse = "")
    }, "")
    ##- user-defined y-axis limits: values outside the limits are not
    ##- drawn (as in the ylim of base R); the data of the user are
    ##- never modified, only this copy used for drawing
    if(has.lim){
      for(i in seq_along(y)){
        v <- lim.list[[i]]
        idx <- dfL$respvar == y[i]
        if(!is.na(v[1])){dfL$value[idx & !is.na(dfL$value) & dfL$value < v[1]] <- NA}
        if(!is.na(v[2])){dfL$value[idx & !is.na(dfL$value) & dfL$value > v[2]] <- NA}
      }
    }
    dfL$respvar <- factor(dfL$respvar, levels = y, labels = lab.str)

    ##- blank points pinning the y-axis range of each response variable
    blank.layer <- NULL
    if(has.lim){
      x0 <- min(db[[x]], na.rm = TRUE)
      blank.df <- NULL
      for(i in seq_along(y)){
        v <- lim.list[[i]]
        vv <- v[!is.na(v)]
        if(length(vv) == 0) next
        b <- data.frame(x = x0, value = vv, stringsAsFactors = FALSE)
        b$respvar <- factor(lab.str[i], levels = levels(dfL$respvar))
        if(has.factvar1==1){b$f1 <- rep(db[[factvar1]][1], length(vv))}
        blank.df <- rbind(blank.df, b)
      }
      blank.layer <- ggplot2::geom_blank(data = blank.df,
        ggplot2::aes(x = x, y = value), inherit.aes = FALSE)
    }

    p <- ggplot2::ggplot(dfL, ggplot2::aes(x = x, y = value,
                                           group = obs.unit))
    if(has.factvar2==1 & factvar2.col==TRUE){
      p <- p + ggplot2::geom_line(ggplot2::aes(col = f2)) +
        ggplot2::labs(col = linetype.lab.h)
    } else if(has.factvar2==1){
      p <- p + ggplot2::geom_line(ggplot2::aes(linetype = f2)) +
        ggplot2::labs(linetype = linetype.lab.h)
    } else {
      p <- p + ggplot2::geom_line()
    }
    if(only.lines==FALSE){p <- p + ggplot2::geom_point()}
    if(has.factvar1==1){
      p <- p + ggplot2::facet_grid(respvar ~ f1, scales = "free_y",
        switch = "y", axes = axes.h, axis.labels = axes.h,
        labeller = ggplot2::labeller(respvar = ggplot2::label_parsed))
    } else {
      if(has.mfrow==1){
        p <- p + ggplot2::facet_wrap(~ respvar, nrow = mfrow[1],
          ncol = mfrow[2], dir = "h", scales = "free_y",
          strip.position = "left", axes = axes.h, axis.labels = axes.h,
          labeller = ggplot2::label_parsed)
      } else if(has.mfcol==1){
        p <- p + ggplot2::facet_wrap(~ respvar, nrow = mfcol[1],
          ncol = mfcol[2], dir = "v", scales = "free_y",
          strip.position = "left", axes = axes.h, axis.labels = axes.h,
          labeller = ggplot2::label_parsed)
      } else {
        p <- p + ggplot2::facet_wrap(~ respvar, nrow = num.y, ncol = 1,
          dir = "h", scales = "free_y",
          strip.position = "left", axes = axes.h, axis.labels = axes.h,
          labeller = ggplot2::label_parsed)
      }
    }
    p <- p +
      ggplot2::xlab(xlab.h) +
      ggplot2::labs(y = NULL) +
      ggplot2::theme(panel.background = ggplot2::element_blank(),
                     panel.border = ggplot2::element_blank(),
                     panel.grid.major = ggplot2::element_blank(),
                     panel.grid.minor = ggplot2::element_blank(),
                     axis.line = ggplot2::element_line(colour = "black"),
                     ##- the per-variable labels act as the y-axis
                     ##- title of each row-panel (as a regular ylab),
                     ##- drawn to the exterior of the axis numbers
                     strip.placement = "outside",
                     strip.background.y = ggplot2::element_blank(),
                     strip.text.y.left = ggplot2::element_text(angle = 90))
    if(has.lim){p <- p + blank.layer}
    if(has.xlim){p <- p + ggplot2::coord_cartesian(xlim = xlim.v)}
    if(!is.null(scale.x.h)){p <- p + scale.x.h}
    if(!is.null(scale.y.h)){p <- p + scale.y.h}
    if(!is.null(user.theme)){p <- p + user.theme}
    print(p)
    return(invisible(p))
  }

  if(has.factvar1==0 & has.factvar2==0){
    df.h <- data.frame(assign(obs.unit,db[,obs.unit]),
                       assign(x,db[,x]),assign(y,db[,y]))
    names(df.h) <- c(obs.unit,x,y) } else {nada=111}
  if(has.factvar1==1 & has.factvar2==0){
    df.h <- data.frame(assign(obs.unit,db[,obs.unit]),
          assign(factvar1,db[,factvar1]),assign(x,db[, x]),assign(y,db[,y]))
    names(df.h) <- c(obs.unit,factvar1,x,y) } else {nada=111}
  if(has.factvar1==1 & has.factvar2==1){
    df.h <- data.frame(assign(obs.unit,db[,obs.unit]),
  assign(factvar1,db[,factvar1]),assign(factvar2,db[,factvar2]),assign(x,db[, x]),
    assign(y,db[,y]))
    names(df.h) <- c(obs.unit,factvar1,factvar2,x,y) } else {nada=111}

  ##- object holding the panel layout of the factvar1 panels
  if(has.factvar1==1){
    if(has.mfrow==1){
      facet.h <- ggplot2::facet_wrap(df.h[,factvar1], nrow=mfrow[1],
                                     ncol=mfrow[2], dir="h",
                                     axes = axes.h, axis.labels = axes.h)
    } else if(has.mfcol==1){
      facet.h <- ggplot2::facet_wrap(df.h[,factvar1], nrow=mfcol[1],
                                     ncol=mfcol[2], dir="v",
                                     axes = axes.h, axis.labels = axes.h)
    } else {
      facet.h <- ggplot2::facet_wrap(df.h[,factvar1],
                                     axes = axes.h, axis.labels = axes.h)
    }
  }

  ##- user-defined axis limits for the single response variable
  if(has.lim || has.xlim){
    ca <- list()
    if(has.lim){
      v <- lim.list[[1]]
      rr <- range(df.h[[y]], na.rm = TRUE)
      lo <- if(is.na(v[1])) rr[1] else v[1]
      hi <- if(is.na(v[2])) rr[2] else v[2]
      ca$ylim <- c(lo, hi)
    }
    if(has.xlim){ca$xlim <- xlim.v}
    lim.coord <- do.call(ggplot2::coord_cartesian, ca)
  }

  if(has.factvar1==0 & has.factvar2==0 & only.lines==FALSE){
  ggplot2::ggplot(df.h, ggplot2::aes(x=df.h[,x], y=df.h[,y],
                                     group=df.h[,obs.unit]))
    p<- ggplot2::ggplot(df.h, ggplot2::aes(x=df.h[,x],
              y=df.h[,y], group=df.h[,obs.unit])) +
      ggplot2::geom_line()+ ggplot2::geom_point()+
      ggplot2::xlab(xlab.h) + ggplot2::ylab(ylab.h)
    p <- p +
      ggplot2::theme(panel.background = ggplot2::element_blank(),
                     panel.border = ggplot2::element_blank(),
                     panel.grid.major = ggplot2::element_blank(),
                     panel.grid.minor = ggplot2::element_blank(),
                     axis.line = ggplot2::element_line(colour = "black"))

    if(has.factvar1==1){p <- p + facet.h}
    if(!is.null(scale.x.h)){p <- p + scale.x.h}
    if(!is.null(scale.y.h)){p <- p + scale.y.h}
    if(has.lim || has.xlim){p <- p + lim.coord}
    if(!is.null(user.theme)){p <- p + user.theme}
    print(p)
  } else {nada=0}

  if(has.factvar1==0 & has.factvar2==0 & only.lines==TRUE){
    ggplot2::ggplot(df.h, ggplot2::aes(x=df.h[,x], y=df.h[,y],
                                       group=df.h[,obs.unit]))
    p<- ggplot2::ggplot(df.h, ggplot2::aes(x=df.h[,x], y=df.h[,y],
                                           group=df.h[,obs.unit])) +
      ggplot2::geom_line()+
      ggplot2::xlab(xlab.h) + ggplot2::ylab(ylab.h)
    p <- p +
      ggplot2::theme(panel.background = ggplot2::element_blank(),
                     panel.border = ggplot2::element_blank(),
                     panel.grid.major = ggplot2::element_blank(),
                     panel.grid.minor = ggplot2::element_blank(),
                     axis.line = ggplot2::element_line(colour = "black"))
    if(has.factvar1==1){p <- p + facet.h}
    if(!is.null(scale.x.h)){p <- p + scale.x.h}
    if(!is.null(scale.y.h)){p <- p + scale.y.h}
    if(has.lim || has.xlim){p <- p + lim.coord}
    if(!is.null(user.theme)){p <- p + user.theme}
    print(p)
  } else {nada=0}

  ##for one factor plotting
  if(has.factvar1==1 & has.factvar2==0  & only.lines==FALSE){
    p <- ggplot2::ggplot(df.h, ggplot2::aes(x=df.h[,x], y=df.h[,y],
                                            group=df.h[,obs.unit])) +
      ggplot2::geom_point() +
      ggplot2::geom_line() +
      ggplot2::facet_wrap(df.h[,factvar1]) +
      ggplot2::ylab(ylab.h) + ggplot2::xlab(xlab.h)
    p <- p +
      ggplot2::theme(panel.background = ggplot2::element_blank(),
                     panel.border = ggplot2::element_blank(),
                     panel.grid.major = ggplot2::element_blank(),
                     panel.grid.minor = ggplot2::element_blank(),
                     axis.line = ggplot2::element_line(colour = "black"))
    if(has.factvar1==1){p <- p + facet.h}
    if(!is.null(scale.x.h)){p <- p + scale.x.h}
    if(!is.null(scale.y.h)){p <- p + scale.y.h}
    if(has.lim || has.xlim){p <- p + lim.coord}
    if(!is.null(user.theme)){p <- p + user.theme}
    print(p)
  } else {nada=0}

  if(has.factvar1==1 & has.factvar2==0  & only.lines==TRUE){
    p <- ggplot2::ggplot(df.h, ggplot2::aes(x=df.h[,x], y=df.h[,y],
                                            group=df.h[,obs.unit])) +
      ggplot2::geom_line() +
      ggplot2::facet_wrap(df.h[,factvar1]) +
      ggplot2::ylab(ylab.h) + ggplot2::xlab(xlab.h)
    p <- p +
      ggplot2::theme(panel.background = ggplot2::element_blank(),
                     panel.border = ggplot2::element_blank(),
                     panel.grid.major = ggplot2::element_blank(),
                     panel.grid.minor = ggplot2::element_blank(),
                     axis.line = ggplot2::element_line(colour = "black"))
    if(has.factvar1==1){p <- p + facet.h}
    if(!is.null(scale.x.h)){p <- p + scale.x.h}
    if(!is.null(scale.y.h)){p <- p + scale.y.h}
    if(has.lim || has.xlim){p <- p + lim.coord}
    if(!is.null(user.theme)){p <- p + user.theme}
    print(p)
  } else {nada=0}

  ##for two factors plotting
if(has.factvar1==1 & has.factvar2==1 & factvar2.col==TRUE){
  factvar2.line=FALSE} else {nada=999}

if(has.factvar1==1 & has.factvar2==1 & factvar2.line==TRUE  & only.lines==FALSE){
    p<-  ggplot2::ggplot(df.h, ggplot2::aes(x=df.h[,x], y=df.h[,y],
                                            group=df.h[,obs.unit])) +
      ggplot2::geom_line(ggplot2::aes(linetype=df.h[,factvar2]))+
      ggplot2::facet_wrap(df.h[,factvar1])+
      ggplot2::geom_point()+
      ggplot2::xlab(xlab.h) + ggplot2::ylab(ylab.h) +
      ggplot2::labs(linetype=linetype.lab.h)
    p <- p +
      ggplot2::theme(panel.background = ggplot2::element_blank(),
                     panel.border = ggplot2::element_blank(),
                     panel.grid.major = ggplot2::element_blank(),
                     panel.grid.minor = ggplot2::element_blank(),
                     axis.line = ggplot2::element_line(colour = "black"))
    if(has.factvar1==1){p <- p + facet.h}
    if(!is.null(scale.x.h)){p <- p + scale.x.h}
    if(!is.null(scale.y.h)){p <- p + scale.y.h}
    if(has.lim || has.xlim){p <- p + lim.coord}
    if(!is.null(user.theme)){p <- p + user.theme}
    print(p)
  } else {nada=0}

  if(has.factvar1==1 & has.factvar2==1 & factvar2.line==TRUE  & only.lines==TRUE){
    p<-  ggplot2::ggplot(df.h, ggplot2::aes(x=df.h[,x], y=df.h[,y],
                                            group=df.h[,obs.unit])) +
      ggplot2::geom_line(ggplot2::aes(linetype=df.h[,factvar2]))+
      ggplot2::facet_wrap(df.h[,factvar1])+
      ggplot2::xlab(xlab.h) + ggplot2::ylab(ylab.h) +
      ggplot2::labs(linetype=linetype.lab.h)
    p <- p +
      ggplot2::theme(panel.background = ggplot2::element_blank(),
                     panel.border = ggplot2::element_blank(),
                     panel.grid.major = ggplot2::element_blank(),
                     panel.grid.minor = ggplot2::element_blank(),
                     axis.line = ggplot2::element_line(colour = "black"))
    if(has.factvar1==1){p <- p + facet.h}
    if(!is.null(scale.x.h)){p <- p + scale.x.h}
    if(!is.null(scale.y.h)){p <- p + scale.y.h}
    if(has.lim || has.xlim){p <- p + lim.coord}
    if(!is.null(user.theme)){p <- p + user.theme}
    print(p)
  } else {nada=0}

  if(has.factvar1==1 & has.factvar2==1 & factvar2.col==TRUE  & only.lines==FALSE){
    p<-  ggplot2::ggplot(df.h, ggplot2::aes(x=df.h[,x], y=df.h[,y],
                                            group=df.h[,obs.unit])) +
      ggplot2::geom_line(ggplot2::aes(col=df.h[,factvar2]))+
      ggplot2::facet_wrap(df.h[,factvar1])+
      ggplot2::geom_point()+
      ggplot2::xlab(xlab.h) + ggplot2::ylab(ylab.h) +
      ggplot2::labs(col=linetype.lab.h)
    p <- p +
      ggplot2::theme(panel.background = ggplot2::element_blank(),
                     panel.border = ggplot2::element_blank(),
                     panel.grid.major = ggplot2::element_blank(),
                     panel.grid.minor = ggplot2::element_blank(),
                     axis.line = ggplot2::element_line(colour = "black"))
    if(has.factvar1==1){p <- p + facet.h}
    if(!is.null(scale.x.h)){p <- p + scale.x.h}
    if(!is.null(scale.y.h)){p <- p + scale.y.h}
    if(has.lim || has.xlim){p <- p + lim.coord}
    if(!is.null(user.theme)){p <- p + user.theme}
    print(p)
  } else {nada=0}

  if(has.factvar1==1 & has.factvar2==1 & factvar2.col==TRUE  & only.lines==TRUE){
    p<-  ggplot2::ggplot(df.h, ggplot2::aes(x=df.h[,x], y=df.h[,y],
                                            group=df.h[,obs.unit])) +
      ggplot2::geom_line(ggplot2::aes(col=df.h[,factvar2]))+
      ggplot2::facet_wrap(df.h[,factvar1])+
      ggplot2::xlab(xlab.h) + ggplot2::ylab(ylab.h) +
      ggplot2::labs(col=linetype.lab.h)
    p <- p +
      ggplot2::theme(panel.background = ggplot2::element_blank(),
                     panel.border = ggplot2::element_blank(),
                     panel.grid.major = ggplot2::element_blank(),
                     panel.grid.minor = ggplot2::element_blank(),
                     axis.line = ggplot2::element_line(colour = "black"))
    if(has.factvar1==1){p <- p + facet.h}
    if(!is.null(scale.x.h)){p <- p + scale.x.h}
    if(!is.null(scale.y.h)){p <- p + scale.y.h}
    if(has.lim || has.xlim){p <- p + lim.coord}
    if(!is.null(user.theme)){p <- p + user.theme}
    print(p)
  } else {nada=0}

}
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

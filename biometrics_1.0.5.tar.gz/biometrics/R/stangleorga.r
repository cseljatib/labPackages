# stangleOrga.r
# ================
# Core hidden function of the biometrics package.
# Authors:
#   J. H. Gove  <jhgove@unh.edu>  (original Sweave core, Jun 2005)
#   C. Salas-Eljatib  <christian.salas@uchile.cl>  (extensions, 2009-2026)
#
##--------------------------------------------------------------------
##
##  A nice little routine to obtain an .R file (with only the R codes) from
##   a .Rwn file (i.e., a Sweave file) that is located
##   in the './SweaveTeXBib' directory of the current Rwork directory.
##
##  Arguments...
##    filename = an rnw file name in the /Rwork/Sweave directory
##
##   Christian Salas	christian.salas@yale.edu         Mar 15, 2009
##-------------------------------------------------------------------
###  @keywords internal
stangleOrga <- function(filename, outname = NA, extension = "rnw",
                        command = "pdflatex", silent = FALSE, preview = FALSE) {
    sw.dir<-NULL;out.dir.f<-NULL;cur.dir<-getwd();
    sweaveset() ##now is a function
    out.dir<-out.dir
    sw.dirh<-getwd() ##>asume lo corremos desde donde esta el Sweave file

    if (command=='latex') command='simpdftex latex --maxpfb'
    extension<-paste('.',extension,sep='')
    path=options('latexcmd')[[1]]
    path=substr(path,start=1,stop=nchar(path)-5)


    ##1. generate the .R file from Sweave from R...
                                        #  fn = unlist(strsplit(filename, "\\."))[1]
    cat('\nRunning Stangle()...\n')

    ##  cur.dir = getwd()
    ## where is the main .Rnw file?
    ##  sw.dir = paste(getwd(), '/SweaveLaTeXBib/', sep='')
    ##  Sweave(file.path(sw.dir, fileName))
    ##        Sweave(file.path(sw.dir, paste(fileName,extension,sep='') ))

                                        #    Stangle(file.path(sw.dir, paste(fileName,extension,sep='') ))
    Stangle(file.path(sw.dirh, paste(filename,extension,sep='') ))

    cat('\nMoving the .R file to the /rwork/outs subfolder \n')
                                        #      fPathtex = file.path( getwd(), paste(fn, '.R', sep='') )
    fPathtex <- file.path( cur.dir, paste(filename, '.R', sep='') )
                                        #    system(paste('mv ', fPathtex, file.path( sw.dir ) ) )
                                        #     #    system(paste('mv ', fPathtex, file.path( out.dir ) ) )
    ##> ojo no tiene que ser con doble //
                                        #    system(paste('mv ', fPathtex, file.path( "../outs" ) ) )
    system(paste('mv ', fPathtex, file.path( out.dir) ) )
                                        #    system(paste('mv ', fPathtex, out.dir.f ) )

    out.dir.h<-    paste(".",datana::deleteLeft(out.dir,3),sep = "")
    fPathtexB <- file.path( out.dir.h, paste(filename, '.R', sep='') )

    ##+ =============================
    ##+ Portion for chanching the name of the pdf-file output
    exist.name1<-exist.name2<-analizar.cambio.nombre<-cambiar.nombre<-0

    if(exists("filename")){exist.name1<-1}
    if(!is.na(outname)){exist.name2<-1}

    if(exist.name1==1){assign("basefile",filename)}
    if(exist.name2==1){assign("newfile",outname)} else {newfile=NA}

    if(exist.name1==1 & exist.name2==1){analizar.cambio.nombre<-1}
    if(analizar.cambio.nombre==1){if(basefile != newfile){cambiar.nombre<-1}}

    fPathtexC <- file.path( out.dir.h, paste(newfile, '.R', sep='') )

    ##+ =============================
                                        #) change the name of the output pdf file
    if (cambiar.nombre==1)
    {
                                        #            system(paste(path,'mv',' ',basefile,'.pdf
        ## ,newfile,'.pdf', sep=''),intern=silent)
        system(paste('mv ', fPathtexB, fPathtexC),intern=silent )
        filename<-newfile
    }
    if (preview)
    {
        system(paste(options('pdfviewer')[[1]],' ',filename,'.pdf',sep=''))
    }
    if (cambiar.nombre==1) {
        message("You have changed the name of the output R file, from: '", filename, ".R' to: '", newfile, ".R'", sep="")
    }
    ##+ End of: Portion for chanching the name of the pdf-file output
    ##+ =============================


    cat('~~~~~ ')
    cat('The process is done!, you have an .R file')
    cat('~~~~~ \n')
    ## clean up...
                                        #
    setwd(cur.dir) #come back to the original working folder
                                        #  return(invisible(j))
}

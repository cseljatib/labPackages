# sweavetexorgaf.R
# ================
# Internal function of the biometrics package.
# NOT exported — call via biometrics:::sweavetexOrga() if needed outside
# the package, but normal use is through exported wrappers or interactively
# after library(biometrics).
#
# Authors:
#   J. H. Gove  <jhgove@unh.edu>  (original Sweave core, Jun 2005,
#                                   USDA Forest Service)
#   C. Salas-Eljatib  <christian.salas@uchile.cl>
#                                  (extensions, Dec 2009 - Apr 2026,
#                                   Santiago, Chile)
#
# Note on @importFrom utils Sweave:
#   That directive belongs in biometrics-package.R (or any other .R file
#   in R/) so it is registered once at the package level.  It must NOT be
#   repeated here since this function is not exported.


#' Compile a Sweave document (internal)
#'
#' Runs the full Sweave \eqn{\to} BibTeX \eqn{\to} pdfLaTeX pipeline from
#' within a \code{SweaveTeXBib/} directory (or any working directory that
#' contains the \code{.rnw} file).  Optionally moves auxiliary chapter
#' \code{.tex} files and calls \code{generaApuntes.py} to slice, stamp, and
#' archive chapter PDFs.
#'
#' @param filename    Character. Base name of the \code{.rnw} file, without
#'   extension.
#' @param outname     Character or \code{NA} (default). If supplied, the
#'   compiled PDF is renamed to \code{outname.pdf}.
#' @param extension   Character. Extension of the source file (default
#'   \code{"rnw"}).
#' @param command     Character. LaTeX engine; only \code{"pdflatex"} (default)
#'   is fully supported.  Passing \code{"latex"} falls back to
#'   \code{simpdftex latex --maxpfb}.
#' @param silent      Logical. Suppress shell-command console output when
#'   \code{TRUE} (default \code{FALSE}).
#' @param preview     Logical. Open the output PDF in the system viewer after
#'   compilation (default \code{FALSE}).
#' @param latex.files Logical. Move all \code{.tex} files -- except the main
#'   one -- to \code{chaptersLaTeX/}, creating a dated \code{.tar.gz} backup
#'   first (default \code{FALSE}).  The folder is created automatically if it
#'   does not exist.
#' @param pdf.files  Logical. Call \code{generaApuntes.py} after compilation
#'   to auto-detect chapter boundaries, stamp each chapter PDF with a banner
#'   and watermark, and save them to \code{../chaptersPdf/}.  Requires Python 3
#'   with \pkg{pypdf} and \pkg{reportlab} (default \code{FALSE}).  The
#'   destination folder is created automatically if it does not exist.
#' @param py.script   Character or \code{NULL} (default). Full path to
#'   \code{generaApuntes.py}.  When \code{NULL} the function searches, in
#'   order: (1) current working directory, (2) \code{inst/python/} of the
#'   installed \pkg{biometrics} package, (3) the \env{GENERA_APUNTES_PATH}
#'   environment variable, (4) common Debian system locations
#'   (\file{/usr/local/bin}, \file{~/.local/bin}).
#' @param dest.dir    Character or \code{NULL} (default). Destination for
#'   chapter PDFs (forwarded as \code{--dest} to the Python script).
#'   \code{NULL} uses the script's built-in default (\file{../chaptersPdf}).
#' @param standalone.dir Character or \code{NULL} (default). Destination for
#'   the standalone LaTeX bundle (\code{--standalone}).  \code{NULL} uses
#'   \file{standAlonefiles/} inside the current \code{SweaveTeXBib/} directory.
#' @param banner.line1 Character or \code{NULL}. First line of the blue banner
#'   stamped on page 1 of every chapter PDF (\code{--banner1}).  \code{NULL}
#'   keeps the script's built-in text.
#' @param banner.line2 Character or \code{NULL}. Second banner line
#'   (\code{--banner2}).
#' @param banner.line3 Character or \code{NULL}. Third banner line
#'   (\code{--banner3}).
#'
#' @return Invisibly, a named list:
#'   \describe{
#'     \item{\code{pdf}}{Path to the final PDF (character).}
#'     \item{\code{pdf.files.status}}{Exit code from
#'       \code{generaApuntes.py}, or \code{NA_integer_} if not run.}
#'   }
#'
#' @details
#' \strong{Expected project layout (defaults):}
#' \preformatted{
#'   project/
#'     SweaveTeXBib/           <- set working directory here before calling
#'       mybook.rnw
#'       mybook.tex            <- produced by Sweave
#'       chaptersLaTeX/        <- chapter .tex files (latex.files)
#'       chaptersRnw/          <- .tex files produced from .rnw chunks
#'       standAlonefiles/      <- standalone bundle  (pdf.files)
#'         defiFiles/          <- preamble and definition files
#'         latexparts/         <- all \input-ed .tex parts
#'         figures/            <- figures (if any found)
#'         images/             <- images  (if any found)
#'     chaptersPdf/            <- chapter PDFs       (pdf.files)
#' }
#'
#' \strong{Python dependencies} (only when \code{pdf.files = TRUE}):
#' \preformatted{pip install pypdf reportlab --break-system-packages}
#'
#' \strong{System-wide installation of \code{generaApuntes.py} on Debian:}
#' \preformatted{
#'   # all users:
#'   sudo cp generaApuntes.py /usr/local/bin/
#'   sudo chmod +x /usr/local/bin/generaApuntes.py
#'
#'   # per-user (no sudo):
#'   cp generaApuntes.py ~/.local/bin/
#'   chmod +x ~/.local/bin/generaApuntes.py
#'   # ensure ~/.local/bin is on PATH (add to ~/.bashrc if needed):
#'   # export PATH="$HOME/.local/bin:$PATH"
#' }
#'
#' Alternatively, place \code{generaApuntes.py} in \file{inst/python/} of
#' the \pkg{biometrics} source tree; after installation,
#' \code{system.file("python", "generaApuntes.py", package = "biometrics")}
#' will locate it automatically.
#'
#' @seealso \code{\link[utils]{Sweave}}
#'
#' @keywords internal
sweavetexOrgaf <- function(filename,
                          outname        = NA,
                          extension      = "rnw",
                          command        = "pdflatex",
                          silent         = FALSE,
                          preview        = FALSE,
                          latex.files    = FALSE,
                          pdf.files      = FALSE,
                          py.script      = NULL,
                          dest.dir       = NULL,
                          standalone.dir = NULL,
                          banner.line1   = NULL,
                          banner.line2   = NULL,
                          banner.line3   = NULL)
{
  sw.dir <- NULL
  sweaveset()                            ##! sets sw.dir and other path vars
  sw.dirh <- getwd()                     ##> assumes run from the Sweave file folder

  ## -- 0. Validate inputs ----------------------------------------------------
  if (missing(filename) || !nzchar(filename))
    stop("'filename' must be a non-empty character string (without extension).")

  extension <- paste0(".", sub("^\\.", "", extension))   # ensure leading dot

  if (command == "latex") command <- "simpdftex latex --maxpfb"

  ## -- 1. Sweave -------------------------------------------------------------
  rnw.file <- file.path(sw.dirh, paste0(filename, extension))
  if (!file.exists(rnw.file))
    stop("Source file not found: ", rnw.file)

  message("=== [1/4] Sweave ===")
  utils::Sweave(rnw.file)

  ## -- 2. BibTeX -------------------------------------------------------------
  message("=== [2/4] BibTeX ===")
  fn    <- sub("\\..*$", "", filename)          # strip any embedded extension
  fPath <- file.path(sw.dirh, fn)
  ret   <- system(paste("bibtex", shQuote(fPath)), intern = FALSE)
  if (ret != 0L)
    message("WARNING: bibtex returned exit code ", ret)

  ## -- 3. pdfLaTeX -----------------------------------------------------------
  message("=== [3/4] pdfLaTeX ===")
  tex.file <- file.path(sw.dirh, paste0(fn, ".tex"))
  if (!file.exists(tex.file))
    stop("Expected .tex file not found after Sweave: ", tex.file)

  ret <- system(paste("pdflatex", shQuote(tex.file)), intern = FALSE)
  if (ret != 0L)
    message("WARNING: pdflatex returned exit code ", ret)

  ## -- 4. Clean up .log ------------------------------------------------------
  log.file <- file.path(sw.dirh, paste0(fn, ".log"))
  if (file.exists(log.file)) file.remove(log.file)

  ## -- 5. Rename output PDF (optional) ---------------------------------------
  pdf.out <- file.path(sw.dirh, paste0(fn, ".pdf"))

  if (!is.na(outname) && nzchar(outname) && outname != fn) {
    new.pdf <- file.path(sw.dirh, paste0(outname, ".pdf"))
    if (file.rename(pdf.out, new.pdf)) {
      message("Output PDF renamed: ", basename(pdf.out),
              " -> ", basename(new.pdf))
      pdf.out <- new.pdf
      fn      <- outname
    } else {
      message("WARNING: could not rename PDF to ", new.pdf)
    }
  }

  ## -- 6. Preview ------------------------------------------------------------
  if (preview) {
    viewer <- getOption("pdfviewer", default = "xdg-open")
    system(paste(viewer, shQuote(pdf.out)))
  }

  ## -- 7. Move chapter .tex files --------------------------------------------
  if (latex.files) {
    message("=== [4a] Moving chapter .tex files ===")

    dest.tex   <- file.path(sw.dirh, "chaptersLaTeX")
    backup.tex <- file.path(dest.tex, ".xBackups")
    dir.create(dest.tex,   showWarnings = FALSE, recursive = TRUE)
    dir.create(backup.tex, showWarnings = FALSE, recursive = TRUE)

    existing.tex <- list.files(dest.tex, pattern = "\\.tex$",
                               full.names = FALSE, recursive = FALSE)
    if (length(existing.tex) > 0L) {
      arc <- file.path(backup.tex,
                       paste0("backup_", format(Sys.Date(), "%Y-%m-%d"),
                              ".tar.gz"))
      ret <- system(
        paste0("tar -czf ", shQuote(arc),
               " -C ",      shQuote(dest.tex), " ",
               paste(shQuote(existing.tex), collapse = " ")),
        intern = FALSE)
      if (ret == 0L)
        message("  Backup OK: ", basename(arc),
                " [", length(existing.tex), " file(s)]")
      else
        message("  WARNING: backup tar returned ", ret)
    }

    main.tex <- paste0(fn, ".tex")
    all.tex  <- list.files(sw.dirh, pattern = "\\.tex$",
                           full.names = TRUE,  recursive = FALSE)
    to.move  <- all.tex[basename(all.tex) != main.tex]

    if (length(to.move) == 0L) {
      message("  No chapter .tex files found to move.")
    } else {
      for (f in to.move) {
        ok <- file.rename(f, file.path(dest.tex, basename(f)))
        message(if (ok) "  Moved : " else "  FAILED: ", basename(f))
      }
    }
  }

  ## -- 8. Chapter PDF splitting via generaApuntes.py -------------------------
  py.status <- NA_integer_

  if (pdf.files) {
    message("=== [4b] Running generaApuntes.py ===")

    script <- .find_genera_apuntes(py.script)

    if (is.null(script)) {
      message("pdf.files = TRUE but generaApuntes.py was not found.\n",
              "Install it system-wide or supply the 'py.script' argument.\n",
              "See ?sweavetexOrgaf for installation instructions.")
    } else {
      message("  Using script: ", script)

      ## Ensure chaptersPdf destination exists before handing off to Python
      dest.chapters <- if (!is.null(dest.dir)) dest.dir else
                         file.path(dirname(sw.dirh), "chaptersPdf")
      dir.create(dest.chapters, showWarnings = FALSE, recursive = TRUE)

      ## Ensure standAlonefiles destination exists (inside SweaveTeXBib/)
      dest.standalone <- if (!is.null(standalone.dir)) standalone.dir else
                           file.path(sw.dirh, "standAlonefiles")
      dir.create(dest.standalone, showWarnings = FALSE, recursive = TRUE)

      ## Build CLI -- only pass flags that were explicitly set by the caller
      args <- shQuote(pdf.out)
      if (!is.null(dest.dir))       args <- paste(args, "--dest",
                                                   shQuote(dest.dir))
      if (!is.null(standalone.dir)) args <- paste(args, "--standalone",
                                                   shQuote(standalone.dir))
      if (!is.null(banner.line1))   args <- paste(args, "--banner1",
                                                   shQuote(banner.line1))
      if (!is.null(banner.line2))   args <- paste(args, "--banner2",
                                                   shQuote(banner.line2))
      if (!is.null(banner.line3))   args <- paste(args, "--banner3",
                                                   shQuote(banner.line3))

      cmd       <- paste("python3", shQuote(script), args)
      py.status <- system(cmd, intern = FALSE)

      if (py.status == 0L) {
        message("  Chapter PDFs saved to: ", dest.chapters)
      } else {
        message("  WARNING: generaApuntes.py returned exit code ", py.status)
      }
    }
  }

  ## -- Return ----------------------------------------------------------------
  invisible(list(pdf             = pdf.out,
                 pdf.files.status = py.status))
}


# -- .find_genera_apuntes ------------------------------------------------------
# Internal helper -- NOT exported.
# Searches for generaApuntes.py in five locations in order, returning the
# first match as a character path, or NULL if not found anywhere.

.find_genera_apuntes <- function(py.script) {

  script.name <- "generaApuntes.py"

  ## 1. Explicit path supplied by the caller
  if (!is.null(py.script)) {
    if (file.exists(py.script)) return(py.script)
    warning("py.script not found: ", py.script, call. = FALSE)
    return(NULL)
  }

  ## 2. Current working directory (legacy: placed next to the .rnw)
  cwd.cand <- file.path(getwd(), script.name)
  if (file.exists(cwd.cand)) return(cwd.cand)

  ## 3. inst/python/ of the installed biometrics package
  pkg.cand <- tryCatch(
    system.file("python", script.name, package = "biometrics",
                mustWork = FALSE),
    error = function(e) ""
  )
  if (nzchar(pkg.cand) && file.exists(pkg.cand)) return(pkg.cand)

  ## 4. User-defined environment variable GENERA_APUNTES_PATH
  env.path <- Sys.getenv("GENERA_APUNTES_PATH", unset = "")
  if (nzchar(env.path)) {
    env.cand <- file.path(env.path, script.name)
    if (file.exists(env.cand)) return(env.cand)
  }

  ## 5. Common Debian system-wide / per-user locations
  sys.cands <- c(
    "/usr/local/bin/generaApuntes.py",
    "/usr/local/lib/generaApuntes.py",
    file.path(Sys.getenv("HOME"), ".local", "bin", "generaApuntes.py")
  )
  found <- Filter(file.exists, sys.cands)
  if (length(found) > 0L) return(found[[1L]])

  NULL   # not found anywhere
}

#' Include a Sweave chapter in a master document
#'
#' Compiles a chapter .rnw file via Sweave and includes the resulting
#' .tex file. Designed to be called from Sweave chunks in a master
#' book document.
#'
#' @param file Character. Base name of the chapter .rnw file (no extension).
#' @param title Character. Chapter title for the LaTeX \\chapter{} command.
#' @param label Character. LaTeX label for the chapter (without "sec:" prefix).
#'   If NULL, defaults to the file name.
#' @param chapter.dir Character. Path to the directory containing the
#'   chapter .rnw files. Defaults to the global \code{fold.ch} variable
#'   set by \code{sweaveset()}, or an empty string (same directory as master).
#'
#' @seealso Internal functions: \code{sweavetexOrga}, \code{sweaveset}
#' @keywords internal
sweaveChapter <- function(file,
                          title,
                          label    = NULL,
                          chapter.dir = NULL) {
  if (is.null(chapter.dir)) {
    if (exists("fold.ch", envir = globalenv())) {
      chapter.dir <- get("fold.ch", envir = globalenv())
    } else {
      chapter.dir <- ""
    }
  }

  if (is.null(label)) label <- file

  cat(paste0("\\chapter{", title, "} \\label{sec:", label, "}"), "\n")

  rnw.path <- file.path(chapter.dir, paste0(file, ".rnw"))
  if (!file.exists(rnw.path))
    stop("Chapter .rnw not found: ", rnw.path)

  ignored <- capture.output(Sweave(rnw.path))

  cat(paste0("\\input{", file, ".tex}"), "\n")

  invisible(NULL)
}

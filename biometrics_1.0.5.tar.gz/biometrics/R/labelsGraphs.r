labelsGraph <- function() {
  labels <- list(
    # a nivel de arbol
    e.lab = 'Edad (a\u00f1os)',
    e.lab.eng = 'Age (yr)',

    time.lab = "Tiempo (a\u00f1os)",
    time.lab.eng = "Time (year)",

    cd.lab = 'Clase diam\u00E9trica (cm)',

    d.lab = 'Di\u00e1metro (cm)',
    d.lab.eng = 'Diameter (cm)',

    dst.lab = 'Di\u00e1metro sobre toc\u00F3n (cm)',
    dst.lab.eng = 'Diameter at stump height (cm)',

    h.lab = 'Altura (m)',
    h.lab.eng = 'Height (m)',

    g.lab = expression(paste("\u00c1rea basal (cm"^{2}, paste(")"))),
    g.lab.eng = expression(paste("Basal area (m"^{2}, paste(")"))),

    v.lab = expression(paste("Volumen (m"^{3}, paste(")"))),
    v.lab.eng = expression(paste("Volume (m"^{3}, paste(")"))),

    # a nivel de rodal
    nha.lab = "Densidad (arb/ha)",
    nha.lab.eng = expression(paste("Density (trees/"^{ }, paste("ha)"))),

    gha.lab = expression(paste("\u00c1rea basal (m"^{2}, paste("/ha)"))),
    gha.lab.eng = expression(paste("Basal area (m"^{2}, paste("/ha)"))),

    qmd.lab = 'Di\u00e1metro medio cuadr\u00e1tico (cm)',
    qmd.lab.log = 'Di\u00e1metro medio cuadr\u00e1tico (ln [cm])',
    qmd.lab.eng = 'Quadratic mean diameter (cm)',

    hm.lab = 'Altura media (m)',
    hm.lab.eng = 'Average height (m)',

    vha.lab = expression(paste("Volumen (m"^{3}, paste("/ha)"))),
    vha.lab.eng = expression(paste("Volume (m"^{3}, paste("/ha)"))),

    htop.lab = 'Altura dominante (m)',
    htop.lab.eng = 'Top height (m)',

    dmed.exp = expression(bar(D)),
    ddom.exp = expression(paste("", italic(D[d], ""),)),
    dgc.exp = expression(paste("", italic(D[gc], ""),)),

    bal.lab = expression(
      paste(italic("bal ")[], paste("(m"^{2}, paste("/ha)")))
    ),

    pbal.lab = expression(paste("Proporcion \u00e1rea basal acumulada")),

    qmd.exp = expression(paste("", italic(D[bar(g)], "",))),
    qmd.explab = expression(paste(italic('D')[bar(g)], paste(" (cm)"))),
    qmd.explab.log = expression(
      paste(italic('ln(D')[bar(g)], paste(") [ln(cm)]"))
    )
  )

  list2env(labels, envir = parent.frame())
  invisible(NULL)
}

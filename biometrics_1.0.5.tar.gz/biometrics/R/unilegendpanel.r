#' Generate legend for unique values
#'
#' @description
#' Function that generate a legend with unique values of selected
#' variables in each pane of a [lattice::xyplot()] call, where this
#' function has to be passed to the `panel` argument.
#'
#' @param data Data which containts the variables and values for the
#' legend. It should be the same data that was used in the
#' [lattice::xyplot()] call.
#' @param uvars Vector of strings to indicate which variables
#' (columns) to consider.
#' @param unames Vector of strings containing alternative label names for
#' the `uvars` parameter.
#' @param uunits Vector of strings containing units of measure for
#' each variable in `uvars`.
#' @param decnum The number of decimals to be used in the values of
#' each `uvars`.
#' @author Nicolás Campos
#' @examples
#' ## Loading a dataframe of taper data
#' df <- biometrics::tapereuca2
#' ## filtering only three trees
#' df <- subset(df, narb %in% c(5, 10, 14))
#' ## common xyplot, no `unilegendpanel' use
#' lattice::xyplot(dlcc ~ hl | narb, data = df, type = "b", layout = c(1, 3))
#' ## adding the diameter and height of each tree to the panels
#' lattice::xyplot(dlcc ~ hl | narb, data = df, type = "b", layout = c(1, 3),
#'                 panel = unilegendpanel(data = df, uvars = c("dap", "htot")))
#' ## Modifying the labels
#' lattice::xyplot(dlcc ~ hl | narb, data = df, type = "b", layout = c(1, 3),
#'                 panel = unilegendpanel(data = df, uvars = c("dap", "htot"),
#'                                        unames = c("Diameter", "Height")))
#' ## Adding units of measure
#' lattice::xyplot(dlcc ~ hl | narb, data = df, type = "b", layout = c(1, 3),
#'                 panel = unilegendpanel(data = df, uvars = c("dap", "htot"),
#'                                        unames = c("Diameter", "Height"),
#'                                        uunits = c("cm", "m")))
#' ## Setting decimal numbers (it uses `round' function) for height
#' lattice::xyplot(dlcc ~ hl | narb,
#'                 data = df, type = "b", layout = c(1, 3),
#'                 panel = unilegendpanel(data = df, uvars = c("dap", "htot"),
#'                                        unames = c("Diameter", "Height"),
#'                                        uunits = c("cm", "m"),
#'                                        decnum = 1))
#' @rdname unilegendpanel
#' @export
######################################################################
unilegendpanel <- function(data,
                           uvars = c("dap", "htot"),
                           unames = NULL,
                           uunits = NULL,
                           decnum = 2) {
    if (is.null(unames)) {
        unames <- uvars
    }
    if (is.null(uunits)) {
        uunits <- rep("", length(uvars))
    }
    if (length(unames) != length(uvars)) {
        stop("unames must have the same length as uvars")
    }
    if (length(uunits) != length(uvars)) {
        stop("uunits must have the same length as uvars")
    }
    if (!all(uvars %in% names(data))) {
        stop("Some variables in uvars are not present in data")
    }
    function(x, y, subscripts = NULL, groups = NULL, ...) {
        ## Fallback if lattice does not provide subscripts
        if (is.null(subscripts)) {
            subscripts <- seq_along(x)
        }
        ## Draw grouped lines
        if (is.null(groups)) {
            lattice::panel.xyplot(x, y, ...)
        } else {
            lattice::panel.superpose(x, y, groups = groups,
                                     subscripts = subscripts, ...)
        }
        ## Values belonging to the current pane
        valores <- unique(data[subscripts, uvars, drop = FALSE])
        ## Round numeric variables only
        valores[] <- lapply(valores, function(z) {
            if (is.numeric(z)) {
                round(z, digits = decnum)
            } else {
                z
            }
        })
        texto <- paste(
            sapply(seq_along(uvars), function(i) {
                valor <- paste(unique(valores[[uvars[i]]]), collapse = ", ")
                unidad <- if (nzchar(uunits[i])) {
                              paste0(" ", uunits[i])
                          } else {
                              ""
                          }
                paste0(unames[i], " = ", valor, unidad)
            }),
            collapse = "\n")
        grid::grid.text(label = texto,
                        x = grid::unit(0.98, "npc"),
                        y = grid::unit(0.98, "npc"),
                        just = c("right", "top"),
                        gp = grid::gpar(cex = 0.8))
    }
}

#' @description
#' Basal area of the largest tree (BAL), defined as:
#'
#' \deqn{bal_{ik} = G_{k}(1 - p_{(i)k}),}
#'
#' where: \eqn{bal_{ik}} is the basal area (in m²/ha) in trees largest
#' than the *i*-th tree in the *k*-th sample plot which contains
#' \eqn{n_{k}} trees; \eqn{G_{k}} is the total basal area (in m²/ha);
#' and \eqn{p_{(i)k}} is the proportion between accumulated basal area
#' (ordered) up to the *i*-th tree and the basal area of the *k*-th
#' sample plot. Note that in \eqn{p_{(i)k}} the *i* is used inside
#' parenthesis, meaning that this represent an ordered statistic
#' (*i.e.*, basal area ordered from lowest to higher.)
#'
#' @title Basal area of the largest tree (BAL)
#'
#' @param gha vector of basal areas of trees, in m²/ha.
#' @param G the value of the plot basal area, in m²/ha. If no value is
#' provided, it's assumed to be the sum of the `gha` argument.
#'
#' @returns a vector with the `bal` values for each tree, following
#' the order of the `gha` argument.
#'
#' @author Christian Salas-Eljatib and Nicolás Campos.
#'
#' @examples
#'
#' ## load data of eucalyptus trees
#' data(eucaplot)
#' df <- eucaplot
#' ## data comes from a sample plot of 500 m2
#' df$plot.area <- 500
#' ## estimating the expansion factor of each tree
#' df$ef <- 10000 / df$plot.area
#' ## basal area of each tree
#' df$g <- biometrics::gtree(df$dbh)
#' ## basal area extrapolated to the hectarea
#' df$g.ha <- df$g * df$ef
#' ## bal
#' df$bal <- biometrics::bal(gha = df$g.ha)
#'
#' @rdname bal
#' @export
##@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
bal <- function(gha, G = NA) {
    ## original order
    oo <- seq_along(gha)
    df.h <- data.frame(oo, gha)
    ## order datafram from lowest to higher basal area
    df.h <- df.h[order(df.h$gha), ]
    ## if no G is provided it is assumed as the sum of all individual
    ## basal areas
    if (is.na(G)) {
        G <- sum(gha)
    }
    pik <- (1 / G) * cumsum(df.h$gha)
    df.h$bal <- G * (1 - pik)
    ## restore order of values
    df.h <- df.h[order(df.h$oo), ]
    df.h$bal
}

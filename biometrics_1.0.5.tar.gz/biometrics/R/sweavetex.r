Sweavetex<-function(filename=filename,outname=NA,extension='rnw',
                    command='pdflatex',silent=FALSE,preview=FALSE)
{    
##- ----------------------------------------------------------------
#  A nice little routine to run any Sweave script in order to
#   obtain a .tex file, which is first checked for bibliog.references,
#   and then a pdf file is produced
#
#  Arguments...
#    fileName = an rnw file name 
#
#  Returns...
#    pdflatex command invisibly
#
#  Author: Jeff Gove, modified by   
#   C. Salas	christian.salas@yale.edu         August 16 2008
#   C. Salas	christian.salas@uchile.cl         dec3, 2025  
#-------------------------------------------------------------------------------  
    #if(is.null(filename)){filename<-getfilename()}


    if (command=='latex') command='simpdftex latex --maxpfb'
        extension<-paste('.',extension,sep='')
        path<-options('latexcmd')[[1]]
        path<-substr(path,start=1,stop=nchar(path)-5)
# generate the .tex file with Sweave
        Sweave(paste(filename,extension,sep=''))
#
# run BibTeX...
        cat('\nRunning  BibTeX...\n')        
        system(paste(path,'bibtex',' ',filename,sep=''),intern=silent)
#
# run pdfLaTeX...
        cat('\nRunning pdfLaTeX (Sweavetex function!...\n')        
        system(paste(path,command,' ',filename,sep=''),intern=silent)
#        if (command=='latex')
#        {
#                system(paste(path,'dvipdfm',' ',filename,sep=''))
                                        #        }

##+ =============================
##+ Portion for chanching the name of the pdf-file output     
  exist.name1<-exist.name2<-analizar.cambio.nombre<-cambiar.nombre.pdf<-0
  if(exists("filename")){exist.name1<-1}
  if(!is.na(outname)){exist.name2<-1}
    
  if(exist.name1==1){assign("basefile",filename)}
  if(exist.name2==1){assign("newfile",outname)} else {newfile=NA}
    
  if(exist.name1==1 & exist.name2==1){analizar.cambio.nombre<-1}
  if(analizar.cambio.nombre==1){if(basefile != newfile){cambiar.nombre.pdf<-1}}
    
##+ =============================
#) change the name of the output pdf file
        if (cambiar.nombre.pdf==1)
        {
            system(paste(path,'mv',' ',basefile,'.pdf ',newfile,'.pdf', sep=''),intern=silent)
            filename<-newfile
        } 
        if (preview)
        {
                system(paste(options('pdfviewer')[[1]],' ',filename,'.pdf',sep=''))
        }
if (cambiar.nombre.pdf==1) {   
message("You have changed the name of the output pdf file, from: '", basefile, ".pdf' to: '", newfile, ".pdf'", sep="")
}
##+ End of: Portion for chanching the name of the pdf-file output
##+ =============================
    
if(silent==FALSE) {   
message("Well done my friend!, you successfully compiled the '", newfile, ".pdf' file.", sep="")
}

}

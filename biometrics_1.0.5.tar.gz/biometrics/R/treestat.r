#' Computes several descriptive statistics of variables at
#' the tree-level per sample plot. It can also be be applied
#' to compute them by levels of factor within each available plot.
#'
#' @details For a given tree list of a sample plot, several
#' descriptive statistics are computed for the selected random
#' variables, by plot and measurement year. 
#'
#' @title Function to compute descriptive statistics at tree-level,
#' segregated by a factor (`factvar`) per sample plot.
#' @param data data frame having the tree list of a sample plot.
#' @param plot.id a string having the plot code-number or unique
#' identificator.
#' @param t a number of year of measurement, if not provided the
#' current year is assigned by default.
#' @param y a string-vector with the name(s) of the random
#' variable(s) to which the descriptive statistics will be
#' computed. By default uses `dbh` as the name of the variable.
#' @param factvar (optional) a string having de name of the variable
#' used as factor. Each level of the 'factvar` is a category.
#' @param t (optional) a time variable having the the measurement
#' year (in numeric or character format). The default is `NA`, in
#' which case the current year is assigned.
#' @param d (optional) a text with the name of the column of the
#' `data` having the diameter at breast-heigth. The default is `NA`.
#' If provided, it is assumed to be in cm. See option `metrics` to
#' change it to the imperial system.
#' @param full logical; if `TRUE`, the output includes some extra
#' descriptive statistics as explained in the datana::descstat()
#' function. The default is `FALSE`.
#' @param want.add.d logical; if `TRUE`, the computations will
#' include the diameter at breast-heigth defined in option `d`, as an
#' extra random variable to be added at the end of the vector `y`.
#' The default is `FALSE`.
#' @param want.add.g logical; if `TRUE`, the computations will
#' include the tree basal area, only possible if option `d` was
#' defined, as an extra random variable to be added at the end of
#' the vector `y`. The default is `FALSE`. 
#' @param short.names logical; if `TRUE`, the name of the
#' statistics are short names as explained in the datana::descstat()
#' function. The default is `FALSE`.
#' @param eng logical; if `TRUE` (by default), the language of some
#' of the output-column names will be English; if "FALSE" will
#' be Spanish. For instance, the levels of the
#' factor-variable (`factvar`) is named "level"; otherwise will be
#' "nivel".
#' @param names.override this is automatically set for the short names
#' of some outputs, nonetheless, if a user wants specific short names,
#' it will need to provide this option in the following fashion
#' names.override = list(msg_no_y="", g="", fact="", lvl="",
#' none="", all="",msg_no_dbh="", msg_add_d="", msg_add_g="",
#' msg_add_dg="", msg_factors="").
#' @param ... aditional options for basic stats functions.
#'
#' @return Returns a data frame with the statistics per plot and
#' time for the selected y variables. If `factvar` is given, the
#' same statistics will be added but segregated by each level,
#' or category(ies), of the `factvar`. Notice that by default the
#' diameter `d` has to be in cm, and the resulting tree-level
#' basal area will be in m\eqn{^{2}}{^2}. In case you want the basal
#' area to be computed in ft\eqn{^{2}}{^2}, you can add the option
#' `metric=FALSE`, which will be passed to the function `gtree()` of
#' the biometrics package.
#'
#' @author Christian Salas-Eljatib.
#' @references
#' - Salas-Eljatib C. 2025. Biometría y Modelación Forestal.
#'  Borrador de libro, en revisión. 352 p.
#'
#' @examples
#'
#' # Dataframe to be used
#' #' #?biometrics::eucaplot2
#' df<-biometrics::eucaplot2
#' head(df)
#' datana::descstat(df[,c("dap","atot")])
#' df$parce<-1
#' ## Using the function
#' treestat(data=df,plot.id="parce",y="atot")
#' # Now, for two random variables, instead of a single one 
#' treestat(data=df,plot.id="parce",y=c("dap","atot"))
#' # If the d is provided, Do you want to add both the diameter
#' # and the basal area (g), as random variables? 
#' treestat(data=df,plot.id="parce",y="atot",d="dap",want.add.d=TRUE,want.add.g=TRUE)
#' ## Do the same as before, but adding the computation by a factor
#' 
#' treestat(data=df,plot.id="parce",y="atot",factvar="clase.copa")
#' df$time<-2025;df$time[1:5]<-2020
#' df
#' ## Using the function per measurement year
#' treestat(data=df,plot.id="parce",y="atot",t="time",full=TRUE)
#' # Do the same as before, but adding the computation by a factor
#' treestat(data=df,plot.id="parce",y="atot",t="time",
#'          factvar="clase.copa")
#' ## same as before, but for two random variables
#' treestat(data=df,plot.id="parce",y=c("dap","atot"),t="time",
#'          factvar="clase.copa",full = TRUE)
#' ## same as before, but for two random variables and two factors
#' treestat(data=df,plot.id="parce",y=c("dap","atot"),t="time",
#'           factvar=c("clase.copa","sanidad"),full = TRUE)
#' @rdname treestat
#' @export
#'
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
treestat<-function (data, plot.id, t = NA, y, d = NA, factvar = NA, full = FALSE, 
    short.names = TRUE, eng = TRUE, want.add.d = FALSE, want.add.g = FALSE, 
    names.override = list(), ...) 
{
    lang <- if (eng) {
        list(msg_no_y = "================ \n No numeric variable has been specified in 'y'. \n================ ", 
            g = "g", fact = "factor", lvl = "level", none = "None", 
            all = "All", msg_no_dbh = "The 'dbh' column has not been specified, please do it under the option 'd='", 
            msg_add_d = "The 'dbh' was specified as the column '%s'.", 
            msg_add_g = "Basal area (g) will be computed from dbh column '%s'.", 
            msg_add_dg = "Both 'dbh' and basal area (g) will be added from the column '%s'.", 
            msg_factors = "================ \n Processing factor(s): %s \n================ ")
    }
    else {
        list(msg_no_y = "================ \n No se ha especificado ninguna variable numerica en 'y'. \n================ ", 
            g = "g", fact = "factor", lvl = "nivel", none = "Ninguno", 
            all = "Todos", msg_no_dbh = "La columna del 'dap' no se ha especificado, hagalo en la opcion 'd='", 
            msg_add_d = "El 'dap' fue especificado como la columna '%s'.", 
            msg_add_g = "El area basal (g) se calculara a partir de la columna 'dap' '%s'.", 
            msg_add_dg = "Tanto 'dap como area basal (g) seran agregadas a partir de la columna '%s'.", 
            msg_factors = "================ \n Procesando factor(es): %s  \n================ ")
    }
    if (missing(y) || length(y) == 0) {
        stop(lang$msg_no_y)
    }
    if (length(names.override) > 0) {
        for (nm in names(names.override)) {
            if (nm %in% names(lang)) 
                lang[[nm]] <- names.override[[nm]]
        }
    }
    ## fxdescstatdf <- function(dh, ...) data.frame(datana::descstat(dh, 
    ##     ...))
##     fxdescstatdf <- function(dh, ...) {
##     res <- datana::descstat(dh, ...)
##     snms <- row.names(res)
##     if (is.null(snms)) snms <- names(res)
##     res <- as.numeric(unlist(res))
##     names(res) <- snms
##     res
## }
    df <- data
    we.have.dbh <- !is.na(d)
    if (we.have.dbh) {
        df$d <- df[[d]]
        df[[lang$g]] <- biometrics::gtree(df$d)
        if (want.add.d & !want.add.g) 
            message(sprintf(lang$msg_add_d, d))
        if (!want.add.d & want.add.g) 
            message(sprintf(lang$msg_add_g, d))
        if (want.add.d & want.add.g) 
            message(sprintf(lang$msg_add_dg, d))
        if (want.add.d) 
            y <- unique(c(y, d))
        if (want.add.g) 
            y <- unique(c(y, lang$g))
    }
    else if (want.add.d | want.add.g) {
        stop(lang$msg_no_dbh)
    }
    y <- unique(y)
    if (is.na(t)) {
        df$t <- as.numeric(format(Sys.Date(), "%Y"))
        t <- "t"
    }
    else df$t <- df[[t]]
    has.fact <- !all(is.na(factvar))
    if (has.fact) 
        factvar <- factvar[!is.na(factvar)]
    if (has.fact && length(factvar) > 0) {
        message(sprintf(lang$msg_factors, paste(factvar, collapse = ", ")))
    }
    all.fact.combs <- if (has.fact) {
        unique(df[, factvar, drop = FALSE])
    }
    else data.frame(dummy = 1)
    out.list <- lapply(seq_len(nrow(all.fact.combs)), function(i) {
        if (has.fact) {
            sel <- apply(df[, factvar, drop = FALSE], 1, function(r) all(r == 
                all.fact.combs[i, ]))
            subdf <- df[sel, , drop = FALSE]
        }
        else subdf <- df
        if (nrow(subdf) == 0) {
            row <- data.frame(matrix(NA, nrow = 1, ncol = length(y) * 
                length(row.names(datana::descstat(df[[y[1]]], 
                  full = full, short.names = short.names))) + 
                length(c(plot.id, t, factvar))))
            colnames(row) <- c(plot.id, t, factvar, unlist(lapply(y, 
                function(v) paste0(row.names(datana::descstat(df[[v]], 
                  full = full, short.names = short.names)), ".", 
                  v))))
            if (has.fact) 
                row[, factvar] <- all.fact.combs[i, ]
            row[, plot.id] <- unique(df[[plot.id]])[1]
            row[, t] <- unique(df[[t]])[1]
            return(row)
        }
        out.df <- NULL
        by.keys <- c(plot.id, t)
        if (has.fact) 
            by.keys <- c(by.keys, factvar)
        ## for (v in y) {
        ##     subdf$y <- subdf[[v]]
        ##     ## tmp <- by(subdf$y, subdf[, by.keys, drop = FALSE], 
        ##     ##     fxdescstatdf, full = full, short.names = short.names, 
        ##     ##     landscape = TRUE)
        ##     tmp <- by(subdf$y, subdf[, by.keys, drop = FALSE],
        ##               fxdescstatdf, full = full, short.names = short.names)            
        ##     tmp <- array2DF(tmp, simplify = TRUE)
        ##     stat.names <- row.names(datana::descstat(subdf$y, 
        ##         full = full, short.names = short.names))
        ##     stat.names <- stat.names[seq_len(ncol(tmp) - length(by.keys))]
        ##     names(tmp) <- c(by.keys, paste0(stat.names, ".", 
        ##         v))
        ##     if (is.null(out.df)) 
        ##         out.df <- tmp
        ##     else out.df <- merge(out.df, tmp, by = by.keys, all = TRUE)
        ## }
        for (v in y) {
    split_fac <- interaction(subdf[, by.keys, drop = FALSE], drop = TRUE, lex.order = TRUE)
    subdf_list <- split(subdf, split_fac)
    
    tmp_list <- lapply(subdf_list, function(chunk) {
        keys_df <- chunk[1, by.keys, drop = FALSE]
        st <- datana::descstat(chunk[[v]], full = full, short.names = short.names)
        
        s_names <- row.names(st)
        if (is.null(s_names) || length(s_names) == 0) s_names <- names(st)
        
        vals <- as.numeric(unlist(st))
        if (is.null(s_names) || length(s_names) != length(vals)) {
            s_names <- paste0("V", seq_along(vals))
        }
        
        st_df <- as.data.frame(matrix(vals, nrow = 1))
        colnames(st_df) <- paste0(s_names, ".", v)
        cbind(keys_df, st_df)
    })
    
    tmp <- do.call(rbind, tmp_list)
    rownames(tmp) <- NULL
    
    if (is.null(out.df)) 
        out.df <- tmp
    else out.df <- merge(out.df, tmp, by = by.keys, all = TRUE)
}
        if (has.fact) {
            if (length(factvar) == 1) {
                out.df[[lang$fact]] <- factvar
                out.df[[lang$lvl]] <- out.df[, factvar]
            }
            else {
                for (j in seq_along(factvar)) {
                  out.df[[paste0(lang$fact, ".", j)]] <- factvar[j]
                  out.df[[paste0(lang$fact, j, ".level")]] <- all.fact.combs[i, 
                    factvar[j]]
                }
            }
        }
        out.df
    })
    out <- do.call(rbind, out.list)
    if (!has.fact) 
        out[[lang$lvl]] <- lang$all
    ord.cols <- c(plot.id, t)
    if (has.fact) {
        if (length(factvar) == 1) 
            ord.cols <- c(ord.cols, lang$fact, lang$lvl)
        else for (j in seq_along(factvar)) ord.cols <- c(ord.cols, 
            paste0(lang$fact, ".", j), paste0(lang$fact, j, ".level"))
    }
    ord.cols <- ord.cols[ord.cols %in% names(out)]
    out <- out[do.call(order, out[, ord.cols, drop = FALSE]), 
               ]
    rownames(out) <- NULL
    out
}

#' @title Function that fits a list of models on a given dataframe.
#'
#' @param modlist List that contains the models to be fitted.
#' To know the structure, see examples below.
#' @param data `dataframe` that contains the values that correspond to
#' observed values and variables as columns.
#' @param file  a (writable binary-mode) connection or the name of the
#' file where the data will be saved (when tilde expansion is done).
#' @param file.full wheter to include all output (`TRUE`) or
#' just the fitted models plus their respective `pred.f` field
#' (`FALSE`, default).
#' @param warnings a writable connection or the name of the file to
#' log error to, if no file is provided values are not saved.
#' @param trace logical value indicating if a trace of the iteration
#' progress of [stats::nls()] should be printed (`TRUE`) or not
#' (`FALSE`, default).
#' @param params a csv file tosave the parameters and the values
#' obtained. If no file is provided values are not saved.
#' @param ... Other options used to control de behavior of
#' [stats::nls()].
#'
#' @examples
#' ## list of example models
#' model.list <- list(
#'     mod1 = list(expr = vtot ~ I(dap^2) + I(dap^2 * atot^2) +I(d6),
#'                 pred.f = function(yhat, vars) hat,
#'                 type = "lm"),
#'     mod2 = list(expr = I(log(vtot)) ~ I(log(dap)) + I(log(atot)),
#'                 pred.f = function(yhat, vars) exp(yhat),
#'                 type = "lm"))
#'
#' ## example dataframe
#' df <- biometrics::treevolruca2
#' head(df)
#'
#' ## fitting models to dataframe
#' fitted.results <- bankfit(modlist = model.list, data = df)
#'
#' ## obaining coefficients of model 2
#' coef(fitted.results$mod2$mod)
#'
#' @rdname bankfit
#' @export
##@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
bankfit <- function(modlist, data, file = NULL, file.full = FALSE,
                    warnings = NULL, trace = FALSE, params = NULL, ...) {

    ## log errors if a filename was supplied
    log.con <- NULL
    close.log <- FALSE

    if (!is.null(warnings)) {
        if (inherits(warnings, "connection")) {
            log.con <- warnings
        } else {
            log.con <- file(warnings, open = "wt")
            close.log <- TRUE
        }

        on.exit({
            if (close.log && isOpen(log.con)) {
                close(log.con)
            }
        }, add = TRUE)
    }

    .log.error <- function(model, error) {
        error.message <- conditionMessage(error)

        ## Colored message for the console
        console.message <- paste0(
            "\033[33mError processing model\033[0m \033[31m<",
            model,
            ">\033[0m\n\033[34mMessage:\033[0m ",
            error.message
        )

        warning(console.message, call. = FALSE)

        ## Plain message for the log file
        if (!is.null(log.con)) {
            log.message <- paste0(
                "Time: ", format(Sys.time()), "\n",
                "Error processing model <", model, ">\n",
                "Message: ", error.message, "\n"
            )

            writeLines(log.message, con = log.con)
            flush(log.con)
        }
    }

    bankfit.out <- lapply(names(modlist), function(x) {
        mod.name.h <- x
        mod.type <- modlist[[x]][["type"]]
        pred.f <- modlist[[x]][["pred.f"]]
        if (trace) {
            cat("\n=====================================================\n",
                sprintf("Procesing model: [%s] type: [%s]", mod.name.h, mod.type),
                "\n=====================================================\n")
        }
        ## fitting process, either lm() or nls() with trycatch
        ## indicating non fitted model. In case of an already fitted
        ## model, just save the expresion for posterior prediction
        if (mod.type == "lm") {
            mod <- tryCatch(
                expr = {
                    lm(modlist[[x]][["expr"]], data = data)
                },
                error = function(e) {
                    .log.error(x, e)
                    return(NA)
                }
            )
            summodel <- datana::modresults(mod)
            time.h <- NA
        } else if (mod.type == "fitted") {
            mod <- modlist[[x]][["expr"]]
            summodel <- NULL
            time.h <- NA
        } else if (mod.type == "nls") {
            elapsed.time <- system.time(
                mod <- tryCatch(
                    expr = {
                        nls(modlist[[x]][["expr"]],
                            data = data,
                            start = modlist[[x]][["start.vals"]],
                            trace = trace
                            )
                    },
                    error = function(e) {
                        .log.error(x, e)
                        return(NA)
                    }
                ))
            
            ## ! TODO summary of nls models has to be implemented
            summodel <- NULL
            print(mod)
            time.h <- unname(elapsed.time["elapsed"])
        }
        if (trace) {
            cat("\n=====================================================\n",
                sprintf(
                    "Done! %d of %d completed in %.4f seconds.",
                    match(mod.name.h, names(modlist)),
                    length(names(modlist)),
                    time.h
                ),
                "\n=====================================================\n")
        }
        list(
            mod = mod, summ = summodel, data = data,
            pred.f = pred.f, type = mod.type, conv.time = time.h
        )
    })
    names(bankfit.out) <- names(modlist)
    ## Cleaning non convergent models
    bankfit.out <- Filter(function(x) {
        all(!is.na(x[["mod"]]))
    }, bankfit.out)
    ## saving the object if asked for
    if (!is.null(file)) {
            if (file.full == FALSE) {
                    bankfit.out <- lapply(bankfit.out, function(x) {
                            x["data"] <- NULL
                            x["summ"] <- NULL
                            return(x)
                    })
                    save(bankfit.out, file = file)
            }
            if (file.full == TRUE) {
                    save(bankfit.out, file = file)
            }
    }
    if (!is.null(params)) {
        fitted.parameters <- get.params(bankfit.out)
        write.csv(fitted.parameters, params, row.names = FALSE)
    }
    return(bankfit.out)
}

## bankfit <- function(modlist, data, file = NULL, file.full = FALSE,
##                     warnings = NULL, trace = FALSE, ...) {

##     ## log errors if a filename was supplied
##     log.con <- NULL
##     close.log <- FALSE

##     if (!is.null(warnings)) {
##         if (inherits(warnings, "connection")) {
##             log.con <- warnings
##         } else {
##             log.con <- file(warnings, open = "wt")
##             close.log <- TRUE
##         }

##         on.exit({
##             if (close.log && isOpen(log.con)) {
##                 close(log.con)
##             }
##         }, add = TRUE)
##     }

##     .log.error <- function(model, error) {
##         error.message <- conditionMessage(error)

##         ## Colored message for the console
##         console.message <- paste0(
##             "\033[33mError processing model\033[0m \033[31m<",
##             model,
##             ">\033[0m\n\033[34mMessage:\033[0m ",
##             error.message
##         )

##         warning(console.message, call. = FALSE)

##         ## Plain message for the log file
##         if (!is.null(log.con)) {
##             log.message <- paste0(
##                 "Time: ", format(Sys.time()), "\n",
##                 "Error processing model <", model, ">\n",
##                 "Message: ", error.message, "\n"
##             )

##             writeLines(log.message, con = log.con)
##             flush(log.con)
##         }
##     }

##     bankfit.out <- lapply(names(modlist), function(x) {
##         mod.name.h <- x
##         mod.type <- modlist[[x]][["type"]]
##         pred.f <- modlist[[x]][["pred.f"]]
##         if (trace) {
##             cat("\n=====================================================\n",
##                 sprintf("Procesing model: [%s] type: [%s]", mod.name.h, mod.type),
##                 "\n=====================================================\n")
##         }
##         ## fitting process, either lm() or nls() with trycatch
##         ## indicating non fitted model. In case of an already fitted
##         ## model, just save the expresion for posterior prediction
##         if (mod.type == "lm") {
##             mod <- tryCatch(
##                 expr = {
##                     lm(modlist[[x]][["expr"]], data = data)
##                 },
##                 error = function(e) {
##                     .log.error(x, e)
##                     return(NA)
##                 }
##             )
##             summodel <- datana::modresults(mod)
##         } else if (mod.type == "fitted") {
##             mod <- modlist[[x]][["expr"]]
##             summodel <- NULL
##         } else if (mod.type == "nls") {
##             mod <- tryCatch(
##                 expr = {
##                     nls(modlist[[x]][["expr"]],
##                         data = data,
##                         start = modlist[[x]][["start.vals"]],
##                         trace = trace
##                         )
##                 },
##                 error = function(e) {
##                     .log.error(x, e)
##                     return(NA)
##                 }
##             )
##             ## ! TODO summary of nls models has to be implemented
##             summodel <- NULL
##             print(mod)
##         }
##         if (trace) {
##             cat("\n=====================================================\n",
##                 sprintf(
##                     "Done! %d of %d completed.",
##                     match(mod.name.h, names(modlist)),
##                     length(names(modlist))
##                 ),
##                 "\n=====================================================\n")
##         }
##         list(
##             mod = mod, summ = summodel, data = data,
##             pred.f = pred.f, type = mod.type
##         )
##     })
##     names(bankfit.out) <- names(modlist)
##     ## Cleaning non convergent models
##     bankfit.out <- Filter(function(x) {
##         all(!is.na(x[["mod"]]))
##     }, bankfit.out)
##     ## saving the object if asked for
##     if (!is.null(file)) {
##         if (file.full == FALSE) {
##             bankfit.out <- lapply(bankfit.out, function(x) {
##                 x["data"] <- NULL
##                 x["summ"] <- NULL
##                 return(x)
##             })
##             save(bankfit.out, file = file)
##         }
##         if (file.full == TRUE) {
##             save(bankfit.out, file = file)
##         }
##     }
##     return(bankfit.out)
## }

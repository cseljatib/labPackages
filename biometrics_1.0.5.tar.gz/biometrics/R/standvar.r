#' Computes stand-level variables for a given sample plot. The
#' variables are the following: density, basal area,
#' stand-level diameters (mean, quadratic, and dominant),
#' and, if tree-height is provided, average height and top height.
#' Additionally, an aggregated stand variable (e.g. stand volume)
#' is computed for each tree-level variable asked for via `y`.
#'
#' @details For a given imputed tree list of a sample plot, several
#' stand-level variales are computed. Density, basal area, and the
#' stand-level diameters are always computed. If the tree-height
#' column (`h`) is not provided, the height-related stand variables
#' (`hmean`, `hdom`) are not computed, but the function still runs
#' normally. Likewise, if `y` is not provided, no aggregated
#' variable is computed, but the function still runs normally.
#' Thus, the imputed-tree list only needs the tree-level variables
#' required for the requested stand-level ones. If there is a
#' remeasurement for a plot, the computation is by plot and
#' measurement year.
#'
#' @title Function to compute stand-level variables for a given
#' imputed-tree-list.
#' @param data data frame having the tree list of a sample plot.
#' @param plot.id a string having the plot code-number or unique
#' identificator.
#' @param plot.area column name having the plot area in m\eqn{^{2}}{^2}.
#' @param time a number of year of measurement, if not provided the
#' current year is assigned by default.
#' @param d a text of the column-name having the diameter at
#' breast-heigth. By default is assumed to be in cm. See option
#' `metrics` to change it to the imperial system. This option
#' must be provided; from it, the stand-level diameters
#' (`dmean`, `dg`, and `ddom`) are always computed.
#' @param h a text of the column-name having the total height
#' of the tree. By default is set to NA. If provided this variable
#' is assumed to be measured in meters. See option
#' `metrics` to use the imperial system. If it is not provided,
#' the height-related stand variables (`hmean`, `hdom`) are not
#' computed, but the function still runs normally.
#' @param y a string-vector with the name(s) of the tree-level
#' variable(s) to which aggregated stand variables are needed
#' to be computed. For example, volume is such a variable. By
#' default is set to `NA`, thus no aggregated variable will be
#' computed; even so, density, basal area, and the stand-level
#' diameters will still be obtained. If any name in `y` is the
#' same as the one given in `d`, it is dropped from the
#' aggregation and a message is issued, since the sum of
#' diameters is not a meaningful stand variable.
#' For instance, if is a vector, `y=c("vgross","vnet")`,
#' those variables must be present in the tree list as column names.
#' Notice that the resulting stand variable accronimg for each
#' variable will be "vgross.ha" and "vnet.ha", by default.
#' @param factvar a string having de name of the variable
#' used as factor. Each level of the 'factvar` is a category.
#' @param metric is a logic value, the default is to `TRUE`, thus
#' the diameter `d` has to be in cm, and the resulting tree-level
#' basal area will be in m\eqn{^{2}}{^2}. If `metric` is `FALSE`,
#' the diameter `d` has to be in inches, and the computed tree
#' basal area will be in ft\eqn{^{2}}{^2}.
#' @param eng logical; if `TRUE` (by default), the language of some
#' of the output-column names will be English; if "FALSE" will
#' be Spanish. For instance, the levels of the
#' factor-variable (`factvar`) is named "level"; otherwise will be
#' "nivel".
#' @param ... aditional options for basic stats functions.
#'
#' @return Returns a data frame with the the stand variables
#' per plot. If `factvar` is provided, the stand variables
#' will be a also computed for each level of the `factvar`.
#' Since `d` must be provided, the stand-level diameters
#' (`dmean`, `dg`, `ddom`) are always computed. The columns
#' `hmean` and `hdom` only appear if `h` was
#' provided, and one `<y>.ha` column appears for each variable
#' asked for in `y`. Dominant diameter and dominant height are
#' computed using the function `domvar()`.
#'
#' @author Christian Salas-Eljatib.
#' @references
#' - Salas-Eljatib C. 2025. Biometría y Modelación Forestal.
#'  Borrador de libro, en revisión. 352 p.
#'
#' @examples
#'
## Dataframe to be used
#' df<-biometrics::eucaplot2
#' #see the metadata by typing ?eucaplot2
#' head(df)
#' datana::descstat(df[,c("dap","atot")])
#' ## Preparing the treelist, in the required format
#' df$parce<-1;df$sup.plot<-500
#' ## Estimating tree-volume using an artifical factor form
#' df$vol<-gtree(x=df$dap)*df$atot*0.35
#' ## Using the function
#' standvar(data=df,plot.id="parce",plot.area="sup.plot",
#'          d="dap",h="atot",y="vol")
#' # Without tree-height: no height stand variables are computed
#' standvar(data=df,plot.id="parce",plot.area="sup.plot",
#'          d="dap",y="vol")
#' # Without tree-height and without any aggregated variable:
#' # only density, basal area and stand-level diameters are computed
#' standvar(data=df,plot.id="parce",plot.area="sup.plot",d="dap")
#' # If 'y' includes the diameter column (the same as 'd'), it is
#' # excluded from the aggregated variables, and a message is shown
#' standvar(data=df,plot.id="parce",plot.area="sup.plot",
#'          d="dap",h="atot",y=c("vol","dap"))
#' # Do the same as before, but adding the computation by a factor
#' standvar(data=df,plot.id="parce",plot.area="sup.plot",
#'          d="dap",h="atot",y="vol",factvar = "clase.copa")
#' ## More than one aggregated variable. For instance, adding biomass
#' ##  and tree carbon, aside of volume. A naive estimation
#' ##  of tree-biomass and carbon, could be 
#' df$biom<-df$v*420 #(kg/m3)
#' df$carb<-df$biom*0.5 #50% of biomass is carbon
#' df
#' standvar(data=df,plot.id="parce",plot.area="sup.plot",
#'          d="dap",h="atot",y=c("vol","biom","carb"))
#'  #what if the sample plot has a remeasurement
#' df$measu.yr<-2025;df$measu.yr[1:5]<-2020
#' df
#' #' ## Using the function per measurement year
#' standvar(data=df,plot.id="parce",plot.area="sup.plot",
#'          d="dap",h="atot",y=c("vol","biom","carb"),time="measu.yr")
#' # Do the same as before, but adding the computation by a factor
#' standvar(data=df,plot.id="parce",plot.area="sup.plot",
#'          d="dap",h="atot",y=c("vol","biom","carb"),time="measu.yr",
#'          factvar = "clase.copa")
#' # More than one plot
#' df<-biometrics::radiatapl2
#' table(df$parce)
#' ## naive imputation of tree-height
#' df[is.na(df$atot),"atot"]<-df[is.na(df$atot),"dap"]*0.8
#' ## Estimating tree-volume using an artifical factor form
#' df$vtot<-gtree(x=df$dap)*df$atot*0.35
#' datana::descstat(df[,c("dap","atot","vtot")])
#' df$sup.plot<-150
#' standvar(data=df,plot.id="parce",plot.area="sup.plot",
#'          d="dap",h="atot",y="vtot")
#' standvar(data=df,plot.id="parce",plot.area="sup.plot",
#'              d="dap",h="atot",y="vtot",factvar = "sanidad")
#' @rdname standvar
#' @export
#'
##@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
standvar <- function(data, plot.id, plot.area, time = NA, d, y = NA,
   h= NA,factvar = NA, metric = TRUE, eng = TRUE, ...) {

if (eng == TRUE) {
    factor.name <- "factor"
    level.name <- "level"
    none.name <- "None"
    all.name <- "All"
} else {
    factor.name <- "factor"
    level.name <- "nivel"
    none.name <- "Ninguno"
    all.name <- "Todos"
}

##- Opcion (d): obligatoria! de ella se calculan siempre las
##- variables de rodal: dmean, dg, y ddom
    if (missing(d) || any(is.na(d)) || !all(d %in% names(data))) {
        stop("standvar(): the option 'd' (name of the diameter column) ",
            "must be provided and be present in 'data'; from it the ",
            "stand variables 'dmean', 'dg' and 'ddom' are always computed.")
    }
##- Opcion (h): fue provista la columna con la altura total?
    h.provided <- !all(is.na(h))
    if (h.provided) {h <- h[!is.na(h)]}
##- Opcion (y): fueron provistas variables agregadas?
    y <- unique(y[!is.na(y)])
##- si 'y' incluye a la misma variable 'd', se excluye de las
##- variables agregadas (sumar diametros no tiene sentido)
    if (any(y %in% d)) {
        y.duplic <- y[y %in% d]
        message("standvar(): 'y' includes the diameter variable: '",
            paste(y.duplic, collapse = "', '"),
            "' (the same as 'd'), thus it(them) will not be",
            " computed as aggregated variable(s); note that the",
            " diameter is always summarized at stand level as",
            " 'dmean', 'dg' and 'ddom'.")
        y <- y[!y %in% d]
    }
    num.variables <- length(y)

##*(1a) Inicio de funcion interna-especifica clave =========
    ##-se define funcion base como un texto (string)
    ##! importante que la estructura se mantenga!
    ##! las entradas del data.frame() se guardan en un vector de
    ##! textos, para poder condicionar las alturas (h) y luego
    ##! agregar las variables agregadas (y) sin romper la estructura
    fx.entries <- c(
        "nha = sum(dh$fexp)",
        "gha = sum(dh$gtree.ha)",
        "dmean = mean(dh$d)",
        "dg = dg.fx(n = sum(dh$fexp), g = sum(dh$gtree.ha))",
        "ddom = domvar(data = dh, varint = \"d\", varsort = \"d\", plot.area = mean(dh$plot.area))"
    )
    ##- las variables ligadas a la altura solo se calculan
    ##- si es que la opcion 'h' fue provista
    if (h.provided) {
        fx.entries <- c(fx.entries,
            "hmean = mean(dh$h)",
            "hdom = domvar(data = dh, varint = \"h\", varsort = \"h\", plot.area = mean(dh$plot.area))"
        )
    }
    fxforestvar.body <- paste0("function(dh) {\n  data.frame(\n    ",
        paste(fx.entries, collapse = ",\n    "), "\n  )\n}")
    ##- la siguiente linea carga como funcion la string forestvar.body
    fxforestvar <- eval(parse(text = paste("fxforestvar <-", fxforestvar.body)))

    ##* Fin de funcion interna-especifica clave ===========

    df <- data
    df$plot.area <- df[, plot.area]
    df$fexp <- 10000 / df[, plot.area]
    df$d <- df[, d]
    if (h.provided) {df$h <- df[, h]}
    df$plot.id <- df[, plot.id]
    df$g <- gtree(x = df$d, metric = metric)
    df$gtree.ha <- df$g * df$fexp


##? Cuantas variables agregadas existen?
    ##* Se modifica funcion clave si es que hay variables agregadas
    if (num.variables >= 1) {
        for (i in 1:num.variables) {
            name.aca <- paste(y[i], ".tree.ha", sep = "")
            name.vaca <- paste(y[i], ".ha", sep = "")
            df[[name.aca]] <- df[[y[i]]] * df$fexp
            text.h <- sprintf("%s = sum(dh$%s)", name.vaca, name.aca)
            fx.entries <- c(fx.entries, text.h)
        }
        fxforestvar.body <- paste0("function(dh) {\n  data.frame(\n    ",
            paste(fx.entries, collapse = ",\n    "), "\n  )\n}")
        fxforestvar <- eval(parse(text = paste("fxforestvar <-", fxforestvar.body)))
    }

    ##? Is there any factor-variable?
    catego <- prod(!is.na(factvar))
    catego

    if(is.na(time)){
        df$time <- as.numeric(format(Sys.Date(), "%Y"))
        time <- "time"
    }
    if (!is.na(time)) {
        df$time <- df[, time]
    }

##     out <- c()
##     out.factvar <- c()

##     ##+ (1) Computing without seggregation
##     by.keys <- c(plot.id, time); by.keys
##     n.keys<-length(by.keys)
##     out.i <- by(df[, ], df[, by.keys], fxforestvar)
##     out <- array2DF(out.i, simplify = TRUE)
##     head(out)
##     names.stand.var.computed<-names(out[,(n.keys+1):ncol(out)])

## ##- Defining the number or NA to be assigned when NULL, wich happens
## ##-  when there are not sample size for the species/plot/time
## null.to.change<-NA
## num.stand.var.computed<-length(names.stand.var.computed)
## zz<-data.frame(matrix(null.to.change,nrow=1,ncol=num.stand.var.computed))
## names(zz)<-names.stand.var.computed

##     ##+ (2) Computing per levels of the factor-variable
##     if(catego == 1){
##         df$factvar <- df[, factvar]
##         cl.factvar <- unique(df$factvar)
##         n.cate <- length(cl.factvar)
##         by.keys <- c(plot.id, time, factvar)
##         out.ij <- by(df[, ], df[, by.keys], fxforestvar)
##         out.ij <- array2DF(out.ij, simplify = TRUE)
##         num.keys<-length(by.keys)
##         if(is.numeric(out.ij[,(num.keys+1)])){prob.null.out<-0}
##         if(!is.numeric(out.ij[,(num.keys+1)])){prob.null.out<-1}
##         prob.null.out
##         ##- (i) Start of: caso con todos los niveles por parcela
##         if(prob.null.out==0){
##         col.h <- datana::findColumn.byname(out.ij, factvar)
##         names(out.ij)[col.h] <- level.name
##         out.ij[[factor.name]] <- factvar
##         out.ij[[level.name]]<-as.factor(out.ij[[level.name]])
##         out.factvar <- out.ij
##          }##- End of(i): caso con todos los niveles por parcela
##         ##- (ii) Start of: caso con NO todos los niveles por parcela
##         if(prob.null.out==1){
##             col.indexes<-out.ij[,-ncol(out.ij)]
##             names(col.indexes)[length(by.keys)]<-level.name
##             col.indexes[[level.name]]<-as.factor(col.indexes[[level.name]])
##    out.ij$Value <- lapply(out.ij$Value, function(x) if (is.null(x)) zz else data.frame((x)))

##    zzb<-data.frame(matrix(unlist(out.ij$Value),nrow=nrow(out.ij),
##                           ncol=num.stand.var.computed,byrow=TRUE))
##    names(zzb)<-names.stand.var.computed
##     out.factvar <- cbind(col.indexes, zzb)
##     }##- End of(ii): caso con NO todos los niveles por parcela
##  out.factvar[[factor.name]] <- factvar
## }#?- End of: catego==1

## if(!is.na(factvar)){##+Start of: si hay una variable categorica
##         out[[factor.name]] <- none.name
##         out[[level.name]] <- all.name
    ##         out <- rbind(out, out.factvar)

# Helper function replacing by() and array2DF()
calc_group_stats <- function(subdf, keys) {
    split_fac <- interaction(subdf[, keys, drop = FALSE], drop = TRUE, lex.order = TRUE)
    chunks <- split(subdf, split_fac)
    res_list <- lapply(chunks, function(dh) {
        keys_df <- dh[1, keys, drop = FALSE]
        stats_df <- fxforestvar(dh)
        cbind(keys_df, stats_df)
    })
    res_df <- do.call(rbind, res_list)
    rownames(res_df) <- NULL
    res_df
}

# 1. Calculate overall stand statistics
by.keys_overall <- c(plot.id, time)
out <- calc_group_stats(df, by.keys_overall)

has.fact <- !all(is.na(factvar))

# 2. Calculate factor-level stand statistics
if (has.fact) {
    factvar <- factvar[!is.na(factvar)]
    by.keys_fact <- c(plot.id, time, factvar)
    out.factvar <- calc_group_stats(df, by.keys_fact)

    names(out.factvar)[names(out.factvar) == factvar] <- level.name
    out.factvar[[factor.name]] <- factvar

    out[[factor.name]] <- none.name
    out[[level.name]] <- all.name

    out <- rbind(out, out.factvar)
} else {
    out[[factor.name]] <- none.name
    out[[level.name]] <- all.name
}

    
    ##     ini.col <- datana::findColumn.byname(out, time) + 1
    ##     ini.col
    ##     end.col <- datana::findColumn.byname(out, factor.name) - 1
    ##     end.col
    ##     order.cols <- c(plot.id, time, factor.name, level.name)
    ##     out1 <- out[, order.cols]
    ##     out1
    ##     out2 <- out[, ini.col:end.col]
    ##     out2
    ##     out <- cbind(out1, out2)
    ## } ##+ End of condition: si hay una variable categorica
    ## out <- out[order(out[, time], out[, plot.id]), ]
    ## if (!is.na(factvar)) {
    ##     out <- out[order(out[, time], out[, plot.id], out[, level.name]), ]
    ## }
order.cols <- c(plot.id, time, factor.name, level.name)
order.cols <- order.cols[order.cols %in% names(out)]
metric.cols <- setdiff(names(out), order.cols)
out <- out[, c(order.cols, metric.cols)]

if (has.fact) {
    out <- out[order(out[, time], out[, plot.id], out[, level.name]), ]
} else {
    out <- out[order(out[, time], out[, plot.id]), ]
}    
out
}

#' Assign species botanical information to a data frame
#'
#' @description Assigns species botanical attributes to a dataset,
#' based upon a reference column (`refcol`). The attributes can be
#' any of the fields available in the [biometrics::speclist] dataframe,
#' such as: `spec.sci.name` (genus and epitetus name of the species),
#' `spec.name` (common name), and `spec.sci.abb`
#' (abbreviated scientific name).
#'
#' @param data A dataframe where to assign the species information.
#'
#' @param attri A string vector having the attributes of the species
#' to be assigned from the species list contained in [biometrics::speclist].
#' This vector, by default, has two attributes: `spec.name` and
#' `spec.sci.name`, representing the common name and the scientific
#' name, respectively. Other alternatives are, among others,
#' `spec.sci.abb` (abbreviated scientific name), `genus` (genus of the
#' species), and `family` (family of the species). Notice that the
#' linking column (see option `refbankcol`) is never added as an
#' attribute.
#'
#' @param refcol A string having the name of the column in `data` that
#' holds the codes (or names) used to link the dataset with the
#' species list. Notice that this column does NOT need to have the
#' same name as in [biometrics::speclist]: for example, `refcol = "esp"`
#' works when the codes of the dataset live in a column called `esp`.
#' If a column with the same name exists in [biometrics::speclist],
#' that column of the species list is used as the reference (see
#' option `refbankcol`). Additional options of the [base::merge()]
#' function can be passed to the current `assignspec()`
#' function.
#'
#' @param refbankcol (optional) A string having the name of the
#' reference column inside [biometrics::speclist] to be matched
#' against `refcol`. By default (`NULL`), the species list uses a
#' column with the same name as `refcol` if it exists (e.g.
#' `spec.code`, `spec.resgrp`, `spec.sci.name`), otherwise the code column `spec.code` is
#' used. Notice that option `resgrp` is a shortcut for using the
#' column `spec.resgrp`, and that this linking column is never added
#' as an attribute (see option `attri`).
#'
#' @param resgrp a logical value. If `TRUE`, the codes of `refcol` are
#' matched against the specific species code used by a research group
#' (`spec.resgrp` column of the species list), instead of `spec.code`,
#' and any value given in `refbankcol` is ignored (with a message).
#' By default is set to `FALSE`, thus the matching follows the rules of
#' option `refbankcol`.
#'
#' @param attri.all By default is set to `FALSE`, otherwise, will
#' overwrite the vector provided in option `attri`, with all the
#' attributes available in the species list.
#'
#' @param all.x Whether to preserve not finded values (`TRUE`,
#' default) or not (`FALSE`).
#'
#' @param ... Other options for controlling the [base::merge()]
#' function, which is internally loaded.
#'
#' @seealso [biometrics::speclist] and [base::merge()].
#'
#' @returns A dataframe object including the attributes defined in
#' the parameter `attri`.
#'
#' @examples
#' ## example data frame
#' myData <- data.frame(narb = c(1, 2, 3),
#'                      spec.code = c("notobl", "notpum", "notdom"),
#'                      dbh = c(20, 14, 23))
#' myData
#'
#'
#' ## assign common, scientific and abbreviated name, based on `esp` value (default)
#' assignspec(myData)
#'
#' ## the reference column of the dataset can have any name, e.g. `esp`
#' myData2 <- data.frame(narb = c(1, 2, 3),
#'                       esp = c("notobl", "notpum", "notdom"),
#'                       dbh = c(20, 14, 23))
#' assignspec(myData2, refcol = "esp")
#'
#' ## Assign more than one attribute based on common name
#' ## just to remember, adding a single attribute (different from the default)
#' assignspec(myData, attri = "spec.sci.name")
#' ## now, a more real example
#' newData <- assignspec(myData, attri = c("spec.name","genus","spec.sci.abb"))
#' newData
#' ## by default this function preserve names not found in biometrics::speclist
#' missingData <- rbind(myData, c(4, "notFoundData", 30))
#' missingData
#' assignspec(missingData, attri = "spec.name")
#' ##the latter can be modified with option `all.x` of the `merge()` function
#' assignspec(missingData, attri = "spec.name", all.x = FALSE)
#' ## In the case of wanting all the attributes to be merged, set option
#' ## `attri.all` to `TRUE`, which willl overwrite the vector `attri`.
#' assignspec(missingData, attri = "spec.name", attri.all=TRUE, all.x =
#' FALSE)
#' ## the specific species code used by a research group is in `spec.resgrp`
#' myData3 <- data.frame(narb = c(1, 2, 3),
#'                       spec.code = c("nob", "np", "nd"),
#'                       dbh = c(20, 14, 23))
#' assignspec(myData3, refbankcol = "spec.resgrp")
#' ## the same, but using the shortcut option `resgrp`
#' assignspec(myData3, resgrp = TRUE)
#' ## matching by scientific name: the linking column is not added
#' ## again as an attribute
#' myData5 <- data.frame(narb = c(1, 2, 3),
#'                       species = c("Nothofagus obliqua", "Nothofagus pumilio",
#'                                   "Nothofagus dombeyi"),
#'                       dbh = c(20, 14, 23))
#' assignspec(myData5, refcol = "species", refbankcol = "spec.sci.name")
#'
#' @rdname assignspec
#' @export
#'
##@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
assignspec <- function(data, attri = c("spec.name", "spec.sci.name"),
                      refcol = "spec.code", all.x = TRUE, attri.all = FALSE,
                      refbankcol = NULL, resgrp = FALSE, ...) {
    spl <- biometrics::speclist
    if (!refcol %in% names(data))
        stop("the column '", refcol, "' was not found in 'data'")
    ## the reference column of the species list (the bank)
    if (isTRUE(resgrp)) {
        ##- research-group codes: the link is made with `spec.resgrp`
        if (!is.null(refbankcol) && refbankcol != "spec.resgrp")
            message("assignspec(): 'resgrp = TRUE' links the codes with the ",
                    "column 'spec.resgrp' of the species list, thus the ",
                    "option 'refbankcol' is being ignored.")
        refbankcol <- "spec.resgrp"
    } else if (is.null(refbankcol)) {
        refbankcol <- if (refcol %in% names(spl)) refcol else "spec.code"
    }
    if (!refbankcol %in% names(spl))
        stop("the column '", refbankcol, "' was not found in biometrics::speclist")
    ##- the linking column of the species list is not an attribute to
    ##- be added: its values are already in `refcol`
    if (attri.all != TRUE) {
        attri <- as.vector(attri)
        if (refbankcol %in% attri) {
            message("assignspec(): '", refbankcol, "' is the linking column, ",
                    "thus it is not added as an attribute.")
            attri <- attri[attri != refbankcol]
        }
    }
    all.attr.list <- names(spl)
    colorder <- names(data)
    data$id.corre <- seq_len(nrow(data))
    ncol.ori <- ncol(data)
    tomerge <- c(refbankcol, attri)
    if (attri.all == TRUE) {
        tomerge <- all.attr.list
    }
    out <- merge(data, spl[, tomerge, drop = FALSE],
            by.x = refcol, by.y = refbankcol,
            all.x = all.x, ...
            )
    fillcols <- tomerge[tomerge != refbankcol]
    fillcols <- fillcols[fillcols %in% names(out)]
    ## if in any row `refcol' had an identifier not present in
    ## biometrics::speclist, change the value of merged columns to
    ## "unassigned"
    out[!out[[refcol]] %in% spl[[refbankcol]], fillcols] <- "unassigned"
    ## if in any row `refcol' was na, change the value of merged
    ## columns to "unknown"
    out[is.na(out[[refcol]]), fillcols] <- "unknown"
    newcols <- names(out[!(names(out) %in% colorder)])
    out <- out[c(colorder, newcols)]
    out <- out[order(out$id.corre), ]
    out <- out[, -ncol.ori]
    rownames(out) <- NULL
    out
}

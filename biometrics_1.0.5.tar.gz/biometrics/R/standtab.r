#' Creates a stand table, i.e. a table that describes the tree density
#' of a forest segregated by a tree-size variable `y`. The most common
#' example is to use diameter at breast-heigth (i.e., \eqn{d}) as the
#' variable, thus the resulting table is a way to describe the
#' diameter distribution.
#'
#'
#' @details For a given imputed tree list of a sample plot, tree
#' density is computed by classes of the tree-size variable. Note that
#' the imputed-tree list must have all the tree-level variables
#' needed to compute stand-level variables, such as, diameter and plot
#' size.
#'
#' @title Function to creates a stand for a given imputed-tree-list of
#' a sample plot.
#' @param data data frame having the tree list of a sample plot.
#' @param plot.area column name having the plot area in m\eqn{^{2}}{^2}.
#' @param y.for.class a text of the column-name having the tree-size variable to
#' be used to segregated the tree density. By default is `dbh`.
#' @param yclass.amp a numeric value establishing the width of each
#' class of the variable `y.for.class`. The measurement unit must be
#' the same as the one of the variable `y.for.class`. 
#' @param metric is a logic value, the default is to `TRUE`, thus
#' the diameter `d` has to be in cm, and the resulting tree-level
#' basal area will be in m\eqn{^{2}}{^2}. If `metric` is `FALSE`,
#' the diameter `d` has to be in inches, and the computed tree
#' basal area will be in ft\eqn{^{2}}{^2}.
#' @param want.basal.area is a logic value, if set to `TRUE`,
#' the stand basal area, segregated by the classes of the `y.for.class`
#' is added as a column, next to the tree density one. The basal area
#' column by class is expressed in m\eqn{^{2}}{^2}/ha. The default
#' for this option is `FALSE`.
#' @param y a string-vector with the name(s) of the random
#' variable(s) to which the descriptive statistics will be
#' computed.
#' @param factvar (optional) a string having de name of the variable
#' used as factor. Each level of the 'factvar` is a category.
#' @param end.name.agrevarcd (optional) a string, by default is "ha.cl"   
#' @param name.nstandcd (optional) a string, by default is "nha.cl".
#' @param name.gstandcd  (optional) a string, by default is "gha.cl".
#' @param have.hm (optional) logical, by default equal to TRUE.
#' @param name.hcd (optional) a string, by default is "Hm".
#' @param htree.var (optional) a string with the name of the
#' column(s) in the tree list file having the tree height variable(s), by
#' default is set to NA.
#' @param vtree.var optional) a string with the name of the
#' column in the tree list file having the tree volumen, by default
#' uses "v".
#' @param name.vstandcd  (optional) a string, by default is "vha.cl".
#' @param ... aditional options for basic stats functions.
#'
#' @return Returns a stand table.
#'
#' @author Christian Salas-Eljatib.
#' @references
#' - Salas-Eljatib C. 2025. Biometría y Modelación Forestal.
#'  Borrador de libro, en revisión. 352 p.
#'
#' @examples
#'
#' ## Dataframe to be used
#' df<-biometrics::eucaplot2
#' #see the metadata by typing ?eucaplot2
#' head(df)
#' datana::descstat(df[,c("dap","atot")])
#' ## Preparing the treelist, in the required format
#' df$parce<-1;df$sup.plot<-500;amp.diam=2;
#' out<-standtab(data=df,plot.area="sup.plot",y.for.class = "dap",
#'               yclass.amp = amp.diam)
#' out
#' #the following sum
#' sum(out$nha.class)
#' # must be equal to the stand-level density (in trees/ha)
#' df$expf<-10000/df$sup.plot;sum(df$expf)
#' # Do you want to add the stand basal area segregated by `y.for.class`
#' out2<-standtab(data=df,plot.area="sup.plot",y.for.class = "dap",
#'                yclass.amp = amp.diam, want.basal.area = TRUE)
#' out2
#' #the following sum
#' sum(out2$gha.class)
#' # must be equal to the stand-level basal area (in m2/ha)
#' df$g<-gtree(x=df$dap);df$gtree.ha<-df$g*df$expf;sum(df$gtree.ha)
#' @rdname standtab
#' @export
#'
##@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
standtab <- function(data, plot.area, y.for.class="dbh", yclass.amp,
                     metric = TRUE, want.basal.area = FALSE,y=NA,htree.var=NA,factvar = NA,
             name.nstandcd="nha.cl",
             name.gstandcd="gha.cl",
             have.hm=TRUE,name.hcd="hm.cl",
             vtree.var=NA,name.vstandcd="vha.cl",
             end.name.agrevarcd="ha.cl",...)
{
    df <- data
    df$plot.area <- df[, plot.area]    
    df$expf <- 10000/df$plot.area
    df <- datana::assigncl(data = df, variable = y.for.class, wclass = yclass.amp)
    name.yclass <- names(df[ncol(df)])
    col.h <- datana::findColumn.byname(df, name.yclass)
    df$y.class <- df[, col.h]

df$y.class[df$y.class == 0] <- yclass.amp
  df[[name.yclass]][df[[name.yclass]] == 0] <- yclass.amp    

# Check if grouping factors are provided
  has.fact <- !all(is.na(factvar))
  if (has.fact) {
    factvar <- factvar[!is.na(factvar)]
  }
  
# Grouping list: PUT FACTVAR FIRST so factor columns appear first in the data.frame
  group_list <- if (has.fact) {
    c(as.list(df[, factvar, drop = FALSE]), list(y.class = df$y.class))
  } else {
    list(y.class = df$y.class)
  }

    ##? stand table pure
out_array <- tapply(df$expf, group_list, sum)
  out_array[is.na(out_array)] <- 0
  
  if (has.fact) {
    out <- as.data.frame.table(out_array, responseName = name.nstandcd)
    out$y.class <- as.numeric(as.character(out$y.class))
  } else {
    y.class <- sort(as.numeric(names(out_array)))
    #out <- data.frame(y.class = y.class, nha.cl = as.numeric(out_array))
   out <- data.frame(y.class = y.class)
out[[name.nstandcd]] <- as.numeric(out_array) 
  }
  
    names(out)[names(out) == "y.class"] <- name.yclass
    
    ## out <- tapply(df$expf, df$y.class, sum)
    ## nha.class <- out
    ## y.class <- sort(as.numeric(names(nha.class)))
    ## out <- data.frame(y.class, nha.class)
    ## names(out)[1] <- name.yclass

##? Pure stand table and basal area
    if(want.basal.area==TRUE){
    df$y.for.class <- df[, y.for.class]        
    df$g <- gtree(x = df$y.for.class, metric = metric)
    df$gtree.ha <- df$g * df$expf                   
    ## out2 <- tapply(df$gtree.ha, df$y.class, sum)
    ## gha.class <- out2
    ## out <- data.frame(y.class, nha.class,gha.class)
    ## names(out)[1] <- name.yclass

out2_array <- tapply(df$gtree.ha, group_list, sum)
    out2_array[is.na(out2_array)] <- 0
    
    if (has.fact) {
      out2_df <- as.data.frame.table(out2_array, responseName = name.gstandcd)
#      out$gha.cl <- out2_df$gha.cl
out[[name.gstandcd]]<- out2_df[[name.gstandcd]]      
    } else {
                                        #out$gha.cl
out[[name.gstandcd]]<- as.numeric(out2_array)
        
    }

    col.h<-datana::findColumn.byname(out,"gha.cl")
    names(out[col.h])<-name.gstandcd    
    }

## average variables (heights)
  if (any(!is.na(htree.var))) {
    for (v in htree.var) {
      hn.aca <- if (is.character(v)) v else names(df)[v]
      
      # Calculate the group mean (excluding NA values if present)
      ## out4 <- tapply(df[[v]], df$y.class, mean, na.rm = TRUE)
      
      ## # Define column name for out (e.g., "h_mean" or "h.class")
      ## hha.class <- paste(hn.aca, "mean", sep = ".")
      ## out[[hha.class]] <- out4
out4_array <- tapply(df[[v]], group_list, mean, na.rm = TRUE)
      hha.class <- paste(hn.aca, "ave.cl", sep = "")
      
      if (has.fact) {
        out4_df <- as.data.frame.table(out4_array, responseName = hha.class)
        out[[hha.class]] <- out4_df[[hha.class]]
      } else {
        out[[hha.class]] <- as.numeric(out4_array)
      }

 out[[hha.class]][is.nan(out[[hha.class]]) | out[[name.nstandcd]] == 0] <-   NA
      
    }
  }

##? agreggated variables
    if(any(!is.na(y))){
    for (v in y) {
# Get the original column name 
  yn.aca <- if (is.character(v)) v else names(df)[v]
  
  # Create new column name for df and compute values
  y.aca <- paste(yn.aca, "arb.ha", sep = "")
  df[[y.aca]] <- df[[v]] * df$expf
      
      out3_array <- tapply(df[[y.aca]], group_list, sum)
        out3_array[is.na(out3_array)] <- 0

if(yn.aca==vtree.var){yn.aca<-vtree.var}        
      yha.class <- paste(yn.aca, end.name.agrevarcd, sep = "")
      
      if (has.fact) {
        out3_df <- as.data.frame.table(out3_array, responseName = yha.class)
        out[[yha.class]] <- out3_df[[yha.class]]
      } else {
        out[[yha.class]] <- as.numeric(out3_array)
      }        
  ## out3 <- tapply(df[[y.aca]], df$y.class, sum)
  
  ## # Create column name for out
  ## yha.class <- paste(yn.aca, "ha.class", sep = "")
  
  ## # Add out3 directly as a new column to the 'out' data frame
  ## out[[yha.class]] <- out3
     }
    }


  ##   # REMOVE UNOBSERVED COMBINATIONS (nha.class == 0)
  ## if (has.fact) {
  ##   out <- out[out$nha.class > 0, ]
  ## }
    
# Sort output rows by factor levels first, then size classes
  sort_cols <- if (has.fact) c(factvar, name.yclass) else name.yclass
  out <- out[do.call(order, out[, sort_cols, drop = FALSE]), ]
  rownames(out) <- NULL

#    col.h<-datana:findColumbyname(out,name.nstandcd)
#    names(out[col.h])<-name.nstandcd
#  out    
  return(out)
}

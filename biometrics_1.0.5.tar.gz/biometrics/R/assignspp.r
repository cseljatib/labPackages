#' Assign species botanical information to a data frame
#'
#' @description Assigns species botanical attributes to a dataset,
#' based upon a reference column (`refcol`). The attributes can be
#' any of the fields available in the [biometrics::spplist] dataframe,
#' such as: `spp.ci.name` (genus and epitetus name of the species),
#' `spp.name` (common name), and `spp.ci.abb`
#' (abbreviated scientific name).
#'
#' @param data A dataframe where to assign the species information.
#'
#' @param attri A string vector having the attributes of the species
#' to be assigned from the species list contained in [biometrics::spplist].
#' This vector, by default, has two attributes: `spp.name` and
#' `spp.ci.name`, representing the common name and the scientific
#' name, respectively. Other alternatives are, among others,
#' `spp.ci.abb` (abbreviated scientific name), `genus` (genus of the
#' species), and `family` (family of the species).
#'
#' @param refcol A string having the name of the column in `data` that
#' holds the codes (or names) used to link the dataset with the
#' species list. Notice that this column does NOT need to have the
#' same name as in [biometrics::spplist]: for example, `refcol = "esp"`
#' works when the codes of the dataset live in a column called `esp`.
#' If a column with the same name exists in [biometrics::spplist],
#' that column of the species list is used as the reference (see
#' option `bankcol`). Additional options of the [base::merge()]
#' function can be passed to the current `assignspp()`
#' function.
#'
#' @param bankcol (optional) A string having the name of the
#' reference column inside [biometrics::spplist] to be matched
#' against `refcol`. By default (`NULL`), the species list uses a
#' column with the same name as `refcol` if it exists (e.g.
#' `sppcode`, `spp.ci.name`), otherwise the code column `sppcode` is
#' used.
#'
#' @param attri.all By default is set to `FALSE`, otherwise, will
#' overwrite the vector provided in option `attri`, with all the
#' attributes available in the species list.
#'
#' @param all.x Whether to preserve not finded values (`TRUE`,
#' default) or not (`FALSE`).
#'
#' @param ... Other options for controlling the [base::merge()]
#' function, which is internally loaded.
#'
#' @seealso [biometrics::spplist] and [base::merge()].
#'
#' @returns A dataframe object including the attributes defined in
#' the parameter `attri`.
#'
#' @examples
#' ## example data frame
#' myData <- data.frame(narb = c(1, 2, 3),
#'                      sppcode = c("nob", "np", "nd"),
#'                      dbh = c(20, 14, 23))
#' myData
#'
#'
#' ## assign common, scientific and abbreviated name, based on `esp` value (default)
#' assignspp(myData)
#'
#' ## the reference column of the dataset can have any name, e.g. `esp`
#' myData2 <- data.frame(narb = c(1, 2, 3),
#'                       esp = c("nob", "np", "nd"),
#'                       dbh = c(20, 14, 23))
#' assignspp(myData2, refcol = "esp")
#'
#' ## Assign more than one attribute based on common name
#' ## just to remember, adding a single attribute (different from the default)
#' assignspp(myData, attri = "spp.ci.name")
#' ## now, a more real example
#' newData <- assignspp(myData, attri = c("spp.name","genus","spp.ci.abb"))
#' newData
#' ## by default this function preserve names not found in biometrics::spplist
#' missingData <- rbind(myData, c(4, "notFoundData", 30))
#' missingData
#' assignspp(missingData, attri = "spp.name")
#' ##the latter can be modified with option `all.x` of the `merge()` function
#' assignspp(missingData, attri = "spp.name", all.x = FALSE)
#' ## In the case of wanting all the attributes to be merged, set option
#' ## `attri.all` to `TRUE`, which willl overwrite the vector `attri`.
#' assignspp(missingData, attri = "spp.name", attri.all=TRUE, all.x =
#' FALSE)
#'
#' @rdname assignspp
#' @export
#'
##@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
assignspp <- function(data, attri = c("spp.name", "spp.ci.name"),
                      refcol = "sppcode", all.x = TRUE, attri.all = FALSE,
                      bankcol = NULL, ...) {
    spl <- biometrics::spplist
    if (!refcol %in% names(data))
        stop("the column '", refcol, "' was not found in 'data'")
    ## the reference column of the species list (the bank)
    if (is.null(bankcol))
        bankcol <- if (refcol %in% names(spl)) refcol else "sppcode"
    if (!bankcol %in% names(spl))
        stop("the column '", bankcol, "' was not found in biometrics::spplist")
    all.attr.list <- names(spl)
    colorder <- names(data)
    data$id.corre <- seq_len(nrow(data))
    ncol.ori <- ncol(data)
    tomerge <- c(bankcol, as.vector(attri))
    if (attri.all == TRUE) {
        tomerge <- all.attr.list
    }
    out <- merge(data, spl[, tomerge],
            by.x = refcol, by.y = bankcol,
            all.x = all.x, ...
            )
    fillcols <- tomerge[tomerge != bankcol]
    fillcols <- fillcols[fillcols %in% names(out)]
    ## if in any row `refcol' had an identifier not present in
    ## biometrics::spplist, change the value of merged columns to
    ## "unassigned"
    out[!out[[refcol]] %in% spl[[bankcol]], fillcols] <- "unassigned"
    ## if in any row `refcol' was na, change the value of merged
    ## columns to "unknown"
    out[is.na(out[[refcol]]), fillcols] <- "unknown"
    newcols <- names(out[!(names(out) %in% colorder)])
    out <- out[c(colorder, newcols)]
    out <- out[order(out$id.corre), ]
    out <- out[, -ncol.ori]
    rownames(out) <- NULL
    out
}

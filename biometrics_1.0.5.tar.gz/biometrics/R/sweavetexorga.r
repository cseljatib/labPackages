# sweavetexOrga.r
# ================
# Core hidden function of the biometrics package.
# Authors:
#   J. H. Gove  <jhgove@unh.edu>  (original Sweave core, Jun 2005)
#   C. Salas-Eljatib  <christian.salas@uchile.cl>  (extensions, 2009-2026)
#
# Python helper scripts called by this function:
#   chapterSlicer.py    -- slices compiled PDF into stamped chapter PDFs
#   buildStandalone.py  -- assembles self-contained LaTeX bundle
#
# Install both system-wide (once):
#   sudo cp chapterSlicer.py buildStandalone.py /usr/local/bin/
#   sudo chmod +x /usr/local/bin/chapterSlicer.py
#   sudo chmod +x /usr/local/bin/buildStandalone.py


###  Compile a Sweave document
### 
###  Runs the full pipeline: Sweave \eqn{\rightarrow} BibTeX
###  \eqn{\rightarrow} pdfLaTeX (\eqn{\times}2).
### 
###  Whenever any of \code{latex.files}, \code{pdf.files}, or
###  \code{standalone} is \code{TRUE}, the Sweave-produced chapter
###  \code{.tex} files are automatically copied to
###  \code{<backup.folder>/chaptersLaTeX/} (with a dated \code{.tar.gz}
###  backup of the previous version) before the respective step runs.
### 
###  @param filename    Base name of the \code{.rnw} file (no extension).
###  @param outname     Rename the output PDF (\code{NA} = keep the same
###    name as \code{filename}).
###  @param extension   Source file extension (default \code{"rnw"}).
###  @param command     LaTeX engine (default \code{"pdflatex"}).
###  @param silent      Suppress pdflatex console output (default
###    \code{FALSE}).
###  @param preview     Open the PDF after build (default \code{FALSE}).
###  @param latex.files Copy Sweave-produced \code{.tex} files to the
###    backup folder (default \code{FALSE}).
###  @param pdf.files   Slice the compiled PDF into stamped chapter PDFs
###    (default \code{FALSE}).
###  @param standalone  Assemble a self-contained LaTeX bundle that
###    compiles anywhere with \code{pdflatex} alone (default
###    \code{FALSE}).
###  @param flatten     Rasterize chapter PDFs after stamping so that
###    text cannot be selected, copied, or pasted into AI tools or word
###    processors (default \code{FALSE}). Requires ImageMagick
###    (\code{magick} command) to be installed.
###  @param flatten.dpi Resolution used when rasterizing (default
###    \code{150}). Higher values give better quality but larger files;
###    \code{150} is sufficient to prevent copy-paste while keeping
###    files small.
###  @param chapters.folder Name of the folder (relative to the project
###    root) where stamped chapter PDFs are written (default
###    \code{"x01chaptersPdf"}).
###  @param standalone.folder Name of the folder where the standalone
###    bundle is written (default \code{"x02standAlone"}).
###  @param backup.folder Name of the folder where chapter \code{.tex}
###    backups are stored (default \code{"x03autoBackup"}).
###  @param slice.script     Full path to \code{chapterSlicer.py}
###    (\code{NULL} = auto-detected from \code{/usr/local/bin/} or the
###    package installation).
###  @param standalone.script Full path to \code{buildStandalone.py}
###    (\code{NULL} = auto-detected).
###  @param banner.line1 First line of the blue header banner stamped on
###    chapter PDFs (\code{NULL} = package default).
###  @param banner.line2 Second banner line.
###  @param banner.line3 Third banner line.
### 
###  @return Invisibly returns a named list:
###    \describe{
###      \item{pdf}{Absolute path to the compiled PDF.}
###      \item{slice.status}{Exit code of \code{chapterSlicer.py}, or
###        \code{NA} if \code{pdf.files = FALSE}.}
###      \item{standalone.status}{Exit code of \code{buildStandalone.py},
###        or \code{NA} if \code{standalone = FALSE}.}
###    }
### 
###  @details
###  \strong{Expected project layout:}
###  \preformatted{
###    bookStat/
###      figures/              R-produced and other figure files
###      figuresNotFromHere/
###      images/
###      imagesNotFromHere/
###      tables/               tab.*.tex table fragments
###      <chapters.folder>/    stamped chapter PDFs  (pdf.files = TRUE)
###      <standalone.folder>/  self-contained bundle (standalone = TRUE)
###      <backup.folder>/
###        chaptersLaTeX/      chapter .tex backups  (any option = TRUE)
###      SweaveTeXBib/         <- setwd() here before calling
###        libroStat.rnw
###        libroStat.tex       produced by Sweave (master)
###        libroStat.pdf       produced by pdflatex (always here)
###        estbasica.tex       chapter .tex produced by Sweave
###        slr.tex             chapter .tex produced by Sweave
###        ...
###        chaptersCore/       hand-written .tex (never modified here)
###        defiFiles/          preamble files
###        kpfonts.sty
###  }
### 
###  \strong{Preventing copy-paste:} When \code{flatten = TRUE},
###  \code{chapterSlicer.py} rasterizes each chapter PDF using ImageMagick
###  after stamping it. The resulting PDF contains only images — there is
###  no text layer, so content cannot be selected or copied. Install
###  ImageMagick on Debian/Ubuntu with:
###  \preformatted{sudo apt install imagemagick}
### 
###  ## @seealso \code{\link{sweaveset}}
### 
###  @examples
###  \dontrun{
###  setwd("~/mybook/SweaveTeXBib")
### 
###  ## Full pipeline with default folder names
###  sweavetexOrga("libroStat",
###                latex.files = TRUE,
###                pdf.files   = TRUE,
###                standalone  = TRUE,
###                flatten     = TRUE)
### 
###  ## Custom folder names
###  sweavetexOrga("libroStat",
###                pdf.files        = TRUE,
###                chapters.folder  = "myChapterPDFs",
###                backup.folder    = "myBackups")
### 
###  ## Compile only
###  sweavetexOrga("libroStat")
###  }
### 
###  @keywords internal
sweavetexOrga <- function(filename,
                          outname           = NA,
                          extension         = "rnw",
                          command           = "pdflatex",
                          silent            = FALSE,
                          preview           = FALSE,
                          latex.files       = FALSE,
                          pdf.files         = FALSE,
                          standalone        = FALSE,
                          flatten           = FALSE,
                          flatten.dpi       = 150,
                          chapters.folder   = "x01chaptersPdf",
                          standalone.folder = "x02standAlone",
                          backup.folder     = "x03autoBackup",
                          slice.script      = NULL,
                          standalone.script = NULL,
                          banner.line1      = NULL,
                          banner.line2      = NULL,
                          banner.line3      = NULL)
{
  sw.dir <- NULL
  sweaveset()
  sw.dirh <- getwd()   # SweaveTeXBib/

  ## Derived folder paths (relative to project root = dirname(sw.dirh))
  proj.root    <- dirname(sw.dirh)
  chapters.dir <- file.path(proj.root, chapters.folder)
  standalone.d <- file.path(proj.root, standalone.folder)
  backup.dir   <- file.path(proj.root, backup.folder, "chaptersLaTeX")

  ## -- 0. Validate -----------------------------------------------------------
  if (missing(filename) || !nzchar(filename))
    stop("'filename' must be a non-empty character string.")
  extension <- paste0(".", sub("^\\.", "", extension))
  if (command == "latex") command <- "simpdftex latex --maxpfb"

  ## -- 1. Sweave -------------------------------------------------------------
  rnw.file <- file.path(sw.dirh, paste0(filename, extension))
  if (!file.exists(rnw.file))
    stop("Source file not found: ", rnw.file)
  message("=== [1/4] Sweave ===")
  utils::Sweave(rnw.file)

  fn            <- sub("\\..*$", "", filename)
  main.tex.name <- paste0(fn, ".tex")

  ## -- 2. BibTeX -------------------------------------------------------------
  message("=== [2/4] BibTeX ===")
  ret <- system(paste("bibtex", shQuote(file.path(sw.dirh, fn))),
                intern = FALSE)
  if (ret != 0L) message("WARNING: bibtex exit code ", ret)

  ## -- 3. pdfLaTeX (two passes) ----------------------------------------------
  message("=== [3/4] pdfLaTeX ===")
  tex.file <- file.path(sw.dirh, main.tex.name)
  if (!file.exists(tex.file))
    stop("Expected .tex not found after Sweave: ", tex.file)

  pdflatex.cmd <- paste(command, "-interaction=nonstopmode",
                        shQuote(main.tex.name))

  old.wd <- getwd()
  on.exit(setwd(old.wd), add = TRUE)
  setwd(sw.dirh)

  message("  Pass 1 ...")
  ret <- system(pdflatex.cmd, intern = FALSE,
                ignore.stdout = silent, ignore.stderr = silent)
  if (ret != 0L) message("WARNING: pdflatex pass 1 exit code ", ret)

  message("  Pass 2 (cross-references) ...")
  ret <- system(pdflatex.cmd, intern = FALSE,
                ignore.stdout = silent, ignore.stderr = silent)
  if (ret != 0L) message("WARNING: pdflatex pass 2 exit code ", ret)

  setwd(old.wd); on.exit(NULL)

  ## -- 4. Clean .log ---------------------------------------------------------
  log.file <- file.path(sw.dirh, paste0(fn, ".log"))
  if (file.exists(log.file)) file.remove(log.file)

  ## -- 5. PDF location -------------------------------------------------------
  pdf.out <- file.path(sw.dirh, paste0(fn, ".pdf"))
  if (!file.exists(pdf.out))
    warning("PDF not found at: ", pdf.out,
            "\n  Check pdflatex output above for errors.")

  ## -- 5b. Rename (optional) -------------------------------------------------
  if (!is.na(outname) && nzchar(outname) && outname != fn) {
    new.pdf <- file.path(sw.dirh, paste0(outname, ".pdf"))
    if (file.rename(pdf.out, new.pdf)) {
      message("PDF renamed: ", basename(pdf.out), " -> ", basename(new.pdf))
      pdf.out <- new.pdf
      fn      <- outname
    } else {
      message("WARNING: could not rename PDF to ", new.pdf)
    }
  }

  ## -- 6. Preview ------------------------------------------------------------
  if (preview)
    system(paste(getOption("pdfviewer", "xdg-open"), shQuote(pdf.out)))

  ## -- 7. Copy chapter .tex files to backup ---------------------------------
  ## Triggered whenever any pipeline option is TRUE.
  ## Copies (NOT moves) Sweave-produced chapter .tex files from sw.dirh
  ## to <backup.folder>/chaptersLaTeX/.  Originals stay in sw.dirh.

  do.backup <- latex.files || pdf.files || standalone

  if (do.backup) {
    message("=== [4a] Copying chapter .tex -> ", backup.folder,
            "/chaptersLaTeX/ ===")

    xbackup.dir <- file.path(backup.dir, ".xBackups")
    dir.create(backup.dir,  showWarnings = FALSE, recursive = TRUE)
    dir.create(xbackup.dir, showWarnings = FALSE, recursive = TRUE)

    ## Archive any existing .tex files before overwriting
    existing.tex <- list.files(backup.dir, pattern = "\\.tex$",
                               full.names = FALSE, recursive = FALSE)
    if (length(existing.tex) > 0L) {
      arc <- file.path(xbackup.dir,
                       paste0("backup_", format(Sys.Date(), "%Y-%m-%d"),
                              ".tar.gz"))
      ret <- system(
        paste0("tar -czf ", shQuote(arc),
               " -C ",      shQuote(backup.dir), " ",
               paste(shQuote(existing.tex), collapse = " ")),
        intern = FALSE)
      if (ret == 0L)
        message("  Backup archive: ", basename(arc),
                "  [", length(existing.tex), " file(s)]")
      else
        message("  WARNING: tar exit code ", ret)
    }

    ## All .tex in sw.dirh except the master
    sweave.tex <- list.files(sw.dirh, pattern = "\\.tex$",
                             full.names = TRUE, recursive = FALSE)
    sweave.tex <- sweave.tex[basename(sweave.tex) != main.tex.name]

    if (length(sweave.tex) == 0L) {
      message("  No chapter .tex files found in ", sw.dirh)
    } else {
      for (f in sweave.tex) {
        ok <- file.copy(f, file.path(backup.dir, basename(f)),
                        overwrite = TRUE)
        message(if (ok) "  Copied: " else "  FAILED: ", basename(f))
      }
    }
  }

  ## -- 8. Slice PDF into chapter PDFs ----------------------------------------
  slice.status <- NA_integer_

  if (pdf.files) {
    message("=== [4b] Slicing chapter PDFs via chapterSlicer.py ===")
    script <- .find_python_script(slice.script, "chapterSlicer.py",
                                  "CHAPTER_SLICER_PATH")
    if (is.null(script)) {
      message("chapterSlicer.py not found. ",
              "Install system-wide or supply 'slice.script'.")
    } else {
      message("  Using : ", script)
      if (!file.exists(pdf.out)) {
        message("  SKIPPED: PDF not found at ", pdf.out)
      } else {
        dir.create(chapters.dir, showWarnings = FALSE, recursive = TRUE)

        args <- shQuote(pdf.out)
        args <- paste(args, "--dest", shQuote(chapters.dir))
        if (flatten)
          args <- paste(args, "--flatten", "--dpi", flatten.dpi)
        if (!is.null(banner.line1))
          args <- paste(args, "--banner1", shQuote(banner.line1))
        if (!is.null(banner.line2))
          args <- paste(args, "--banner2", shQuote(banner.line2))
        if (!is.null(banner.line3))
          args <- paste(args, "--banner3", shQuote(banner.line3))

        slice.status <- system(paste("python3", shQuote(script), args),
                               intern = FALSE)
        if (slice.status == 0L)
          message("  Chapter PDFs -> ", chapters.dir)
        else
          message("  WARNING: exit code ", slice.status)
      }
    }
  }

  ## -- 9. Build standalone bundle --------------------------------------------
  sa.status <- NA_integer_

  if (standalone) {
    message("=== [4c] Building standalone via buildStandalone.py ===")
    script <- .find_python_script(standalone.script, "buildStandalone.py",
                                  "STANDALONE_SCRIPT_PATH")
    if (is.null(script)) {
      message("buildStandalone.py not found. ",
              "Install system-wide or supply 'standalone.script'.")
    } else {
      message("  Using : ", script)
      tex.abs <- file.path(sw.dirh, main.tex.name)
      dir.create(standalone.d, showWarnings = FALSE, recursive = TRUE)

      args <- paste(shQuote(tex.abs), "--out", shQuote(standalone.d))

      sa.status <- system(paste("python3", shQuote(script), args),
                          intern = FALSE)
      if (sa.status == 0L)
        message("  Standalone -> ", standalone.d)
      else
        message("  WARNING: exit code ", sa.status)
    }
  }

  invisible(list(pdf               = pdf.out,
                 slice.status      = slice.status,
                 standalone.status = sa.status))
}


# ── Internal helper -----------------------------------------------------------

.find_python_script <- function(explicit, script.name, env.var) {
  if (!is.null(explicit)) {
    if (file.exists(explicit)) return(explicit)
    warning(script.name, " not found at: ", explicit, call. = FALSE)
    return(NULL)
  }
  cwd.c <- file.path(getwd(), script.name)
  if (file.exists(cwd.c)) return(cwd.c)
  pkg.c <- tryCatch(
    system.file("python", script.name, package = "biometrics",
                mustWork = FALSE),
    error = function(e) "")
  if (nzchar(pkg.c) && file.exists(pkg.c)) return(pkg.c)
  env.p <- Sys.getenv(env.var, unset = "")
  if (nzchar(env.p)) {
    env.c <- file.path(env.p, script.name)
    if (file.exists(env.c)) return(env.c)
  }
  sys.c <- c(file.path("/usr/local/bin", script.name),
             file.path("/usr/local/lib", script.name),
             file.path(Sys.getenv("HOME"), ".local", "bin", script.name))
  found <- Filter(file.exists, sys.c)
  if (length(found)) return(found[[1L]])
  NULL
}

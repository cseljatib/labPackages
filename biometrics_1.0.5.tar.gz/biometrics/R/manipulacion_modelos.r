## funcion que permite agregar campos a modelos
models.elements <- function(model.list, field, value) {
    lapply(model.list, function(model) {
        if (is.null(model[[field]])) {
            model[[field]] <- value   
        }
        return(model)
    })
}

## funcion que permite filtrar modelos por campo
## el resultado son las coincidencias
models.filter <- function(model.list, field, value) {
    Filter(function(model.list) {
        any(model.list[[field]] == value)
    }, model.list)
}

## se quitan de la lista las coincidencias
models.filter.out <- function(model.list, field, value) {
    Filter(function(model.list) {
        if (is.null(model.list[[field]])) {
            return(TRUE)
        } else if (model.list[[field]] != value) {
            return(TRUE)
        } else {
            return(FALSE)
        }
    }, model.list)
}

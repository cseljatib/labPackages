## funcion que permite agregar campos a modelos
models.elements <- function(model.list, field, value) {
    lapply(model.list, function(model) {
        if (is.null(model[[field]])) {
            model[[field]] <- value   
        }
        return(model)
    })
}

## funcion que permite filtrar modelos por campo
## el resultado son las coincidencias
models.filter <- function(model.list, field, value) {
    Filter(function(model.list) {
        any(model.list[[field]] == value)
    }, model.list)
}

## se quitan de la lista las coincidencias
models.filter.out <- function(model.list, field, value) {
    Filter(function(model.list) {
        if (is.null(model.list[[field]])) {
            return(TRUE)
        } else if (model.list[[field]] != value) {
            return(TRUE)
        } else {
            return(FALSE)
        }
    }, model.list)
}

## los nombres de fila como la primera columna de un dataframe, util
## para las salidas de lapply
rnames2col <- function(df) {
        df <- as.data.frame(df)
        df <- cbind(model = rownames(df), df)
        rownames(df) <- NULL
        df
}

## prepara un listado de data.frames para pasarselo a rbind, i.e. si
## faltan columnas en alguno rellena valores con NA
safe2rbind <- function(dflist, totalcols) {
        cols.na <- setdiff(totalcols, names(dflist))
        dflist[cols.na] <- NA
        dflist[totalcols]
    }
## para obtener un data frame con los parametros de cada modelos
get.params <- function(fitted.models) {
    coef.h <- lapply(fitted.models, \(x) coef(x$mod))
    all.coef <- unique(unlist(lapply(coef.h, names)))
    coef.filled <- lapply(coef.h, \(x) safe2rbind(x, all.coef))
    df <- do.call(rbind, coef.filled) |> as.data.frame()
    rnames2col(df)
}

# biometrics-package.R
# =====================
# Package-level declarations for the biometrics package.
#
# @importFrom directives placed here are picked up by devtools::document()
# and written into the NAMESPACE file.  Internal functions that call
# utils::Sweave() do not need their own @importFrom because the import
# is already registered at the package level here.

#' @importFrom utils Sweave
NULL

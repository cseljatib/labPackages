#' List of botanical attributes of plant species 
#'
#' @usage
#' data(speclist)
#'
#' @format
#' The list contains the following fields:
#' \describe{
#'   \item{ntaxon}{Unique number of the taxon (i.e., species).}
#'   \item{kingdom}{Taxonomic rank Kingdom. In this datase, all species belong to the Kingdom Plantae.}
#'   \item{division}{Taxonomic rank division or phylum within the Kingdom.}
#'   \item{class}{Taxonomic rank Class within the Kingdom.}
#'   \item{order}{Taxonomic rank Order within the Class.}
#'   \item{family}{Taxonomic rank Family within the Order.}
#'   \item{spec.sci.full}{Full scientific name including author.}
#'   \item{genus}{Solely the genus of the scientific name.}
#'   \item{spec.sci.epi}{Solely the epithet of the scientific name.}
#'   \item{authorspec}{Species botanical-author.}
#'   \item{subspec}{Subspecies: one of two or more populations of a species varying from one another by morphological characteristics.}
#'   \item{authorsubspec}{Sub-species botanical-author.}
#'   \item{variety}{}
#'   \item{authorvar}{}
#'   \item{shape}{Shape}
#'   \item{authorshape}{Shape's author.}
#'   \item{comnames}{Species common name(s). With blank spaces,  no special characters.}
#'   \item{synonymy}{Synonyms of the scientific name by which the species has been or is known.}
#'   \item{bordcont}{Border countries given the species distribution range.}
#'   \item{habit}{The general appearance, growth form, or architecture e.g., tree, shrub, grass.}
#'   \item{lifecycle}{Life cycle.}
#'   \item{statusori}{Status according to the species origin: Native or Endemic}
#'   \item{regdist}{Distribution range of the species, within Chile administrative regions}
#' \item{elerange}{Elevation range of the species, in meters above sea level.}
#'   \item{note}{}
#'   \item{spec.code}{Species code: three letters of the genus plus three
#' letters of the specific epithet, in lowercase. For instance, `notobl`
#' stands for _Nothofagus obliqua_, and `notalp` for _Nothofagus alpina_.
#' If a code is not unique in the list, extra letters of the name are
#' added (e.g., `calcolc`), and subspecies or varieties of the same
#' species are numbered (e.g., `calcol2`).}
#'   \item{spec.resgrp}{is the potential specific species code that a
#' research group is using. For instance, it could be the biometrics lab
#' at the Universidad de Chile or the biometrics research group at the
#' Beijing Forestry University.}
#'   \item{spec.name}{Species common name. No blank spaces,  no special characters.}
#'   \item{spec.sci.abb}{Species scientific name abbreviation.}
#'   \item{spec.sci.name}{Species scientific name.}
#'   \item{spec.co.name.latex}{Species common name in LaTeX}
#'   \item{spec.co.name}{Species single common name.}
#' }
######################################################################
'speclist'

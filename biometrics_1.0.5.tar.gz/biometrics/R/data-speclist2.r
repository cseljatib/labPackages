#' Listado de atributos botánicos de especies de plantas
#'
#' @usage
#' data(speclist2)
#'
#' @format
#' La lista contiene los siguientes campos:
#' \describe{
#'   \item{numtaxon}{Número único del taxón (es decir, la especie).}
#'   \item{reino}{Rango taxonómico Reino. En este conjunto de datos, todas las especies pertenecen al Reino Plantae.}
#'   \item{division}{Rango taxonómico división o filo dentro del Reino.}
#'   \item{clase}{Rango taxonómico Clase dentro del Reino.}
#'   \item{orden}{Rango taxonómico Orden dentro de la Clase.}
#'   \item{familia}{Rango taxonómico Familia dentro del Orden.}
#'   \item{spec.sci.full}{Nombre científico completo incluyendo el autor.}
#'   \item{genero}{Solamente el género del nombre científico.}
#'   \item{spec.sci.epi}{Solamente el epíteto del nombre científico.}
#'   \item{autorespecie}{Autor botánico de la especie.}
#'   \item{subespecie}{Subespecie: una de dos o más poblaciones de una especie que varían entre sí por características morfológicas.}
#'   \item{autorsubespecie}{Autor botánico de la subespecie.}
#'   \item{variedad}{}
#'   \item{autorvariedad}{}
#'   \item{forma}{Forma}
#'   \item{autorforma}{Autor de la forma.}
#'   \item{nombrecomun}{Nombre(s) común(es) de la especie. Sin espacios en blanco, sin caracteres especiales.}
#'   \item{sinonimia}{Sinónimos del nombre científico por los cuales la especie se ha conocido o es conocida.}
#'   \item{paiseslimitrofes}{Países limítrofes dados por el rango de distribución de la especie.}
#'   \item{habito}{La apariencia general, forma de crecimiento o arquitectura, p. ej., árbol, arbusto, hierba.}
#'   \item{ciclodevida}{Ciclo de vida.}
#'   \item{statussegunorigen}{Estado de acuerdo al origen de la especie: Nativa o Endémica}
#'   \item{distribucionregional}{Rango de distribución de la especie, dentro de las regiones administrativas de Chile}
#'   \item{rangoaltitudinal}{Rango de elevación de la especie, en metros sobre el nivel del mar.}
#'   \item{notas}{}
#'   \item{spec.code}{Código de la especie: tres letras del género más tres letras del epíteto específico, en minúscula. Por ejemplo, `notobl` corresponde a _Nothofagus obliqua_, y `notalp` a _Nothofagus alpina_. Si un código no es único en la lista, se agregan letras extra del nombre (p. ej., `calcolc`), y las subespecies o variedades de la misma especie se numeran (p. ej., `calcol2`).}
#'   \item{spec.resgrp}{es el código específico de especie potencial que está usando un grupo de investigación. Por ejemplo, podría ser el laboratorio de biometría de la Universidad de Chile o el grupo de investigación de biometría de la Universidad Forestal de Pekín.}
#'   \item{spec.name}{Nombre común de la especie. Sin espacios en blanco, sin caracteres especiales.}
#'   \item{spec.sci.abb}{Abreviación del nombre científico de la especie.}
#'   \item{spec.sci.name}{Nombre científico de la especie.}
#'   \item{spec.co.name.latex}{Nombre común de la especie en LaTeX}
#'   \item{spec.co.name}{Nombre común único de la especie.}
#' }
######################################################################
'speclist2'

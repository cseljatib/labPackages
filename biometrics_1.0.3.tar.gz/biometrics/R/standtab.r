standtab <- function(data, plot.area, d, w.amp, factvar = NA, metric = TRUE, 
    eng = TRUE, ...)
{
#-------------------------------------------------------------------------------
#
#  A nice function to produce a stand table
#   C. Salas	christian.salas@yale.edu         dec02, 2009
#  Last changes: jul21, 2010
    ##  temuco, chile
    ## d a text of the column-name having the diameter at breast-heigth
    ## plot.area column name having the plot area in m\eqn{^{2}}{^2}.
#-------------------------------------------------------------------------------
                                        #
    {
        if (eng == TRUE) 
            factor.name <- "factor"
        else factor.name <- "factor"
    }
    {
        if (eng == TRUE) 
            level.name <- "level"
        else level.name <- "nivel"
    }
    {
        if (eng == TRUE) 
            none.name <- "None"
        else level.name <- "Ninguno"
    }
    {
        if (eng == TRUE) 
            all.name <- "All"
        else level.name <- "Todos"
    }
    db <- data
    db$plot.area <- db[, plot.area]
    db$fe <- 10000/db$plot.area
    db <- datana::assigncl(data = db, variable = d, wclass = w.amp)
    name.yclass <- names(db[ncol(db)])
    col.h <- datana::findColumn.byname(db, name.yclass)
    db$y.class <- db[, col.h]
    out <- tapply(db$fe, db$y.class, sum)
    nha.cd <- out
    y.class <- sort(as.numeric(names(nha.cd)))
    out <- data.frame(y.class, nha.cd)
    names(out)[1] <- name.yclass
    out
}

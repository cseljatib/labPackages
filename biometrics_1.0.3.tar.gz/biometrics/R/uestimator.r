#' Computes the *U*-estimator for a number of trees per-are
#' (1 ha=100ares)
#'
#' @details Althought the original function was written by
#' Dr Oscar García, and the corresponding reference is provided,
#' the current function has several changes that makes it to of
#' broader use.
#'
#' @title Function to compute the *U*-estimator for a variable
#' from a sample plot
#' @param sort.y a vector having the tree-level variable of interest being
#' already sorted according to a criterion.
#' @param n.are number of needed trees per are for the sample plot. Remember that
#' 1 are=100 m2 or 1 ha=100 ares. If `nare` is not an integer, it
#'   is rounded to the nearest integer, with a warning.
#'
#' @return The main output is the *U*-estimator
#'
#' @author Dr Oscar García and Christian Salas-Eljatib.
#' @references
#' - Garcia O, Batho A. 2005. Top height estimation in lodgepole pine
#' sample plots. Western Journal of Applied forestry 20(1):64-68.
#'
#' @examples
#'
#' #Creates a fake dataframe
#' h <- c(29.1,28, 24.5, 26, 21,20.5,20.1);
#' sort.h<-sort(h,decreasing=TRUE);sort.h
#' plot.area.m2<-500;plot.area.ha<-plot.area.m2/10000;plot.area.ha
#' nref.ha<-100;n.are<-plot.area.ha*nref.ha;
#' # Using the  function
#' uestimator(sort.y=sort.h,n.are=n.are)
#' @rdname uestimator
#' @export
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
uestimator <- function(sort.y=sort.y, n.are=n.are){
    m <- round(n.are)
    if (m != n.are) warning("The trees/are = ", n.are, " has been rounded")
    sum(choose(0:(length(sort.y) - 1), m - 1) * sort.y) / choose(length(sort.y), m)
}


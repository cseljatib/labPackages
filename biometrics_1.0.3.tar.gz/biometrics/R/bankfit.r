#'
#' @title Function that fit a list of models given a dataframe and save the summary of
#' each one.
#' @param models List object that contains the models to be fitted.
#' To know the structure, see examples below.
#' @param data dataframe object that contains the values that
#' correspond to observed values and variables as columns
#' @examples
#' model.list <- list(
#'     mod1 = list(expr = vtot ~ I(dap^2) + I(dap^2 * atot^2) +I(d6),
#'                 pred.f = function(x) x,
#'                 summodel = function(x) modresults(x)),
#'     mod2 = list(expr = I(dap^2 / vtot) ~ I(1 / atot),
#'                 pred.f = function(x) df.fit$dap^2 / x,
#'                 summodel = function(x) modresults(x)),
#'     mod3 = list(expr = I(log10(vtot)) ~ I(log10(dap)) +
#'                     I(log10(atot)),
#'                 pred.f = function(x) 10^x,
#'                 summodel = function(x) modresults(x)),
#'     mod4 = list(expr = I(log(vtot)) ~ I(log(dap)) + I(log(atot)),
#'                 pred.f = function(x) exp(x),
#'                 summodel = function(x) modresults(x)),
#'     mod5 = list(expr = I(sqrt(vtot)) ~ I(log(dap)) + I(log(atot)),
#'                 pred.f = function(x) x^2,
#'                 summodel = function(x) modresults(x))
#' )
#' 
#' library(datana)
#' df <- treevolroble2
#' head(df)
#' 
#' bankfit(model.list, df)
#' 
#' 
#'@rdname bankfit
#'@export
##@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

bankfit <- function(models = models, data = data) { ## (lista de modelos, datos)
    ## assign("df.fit", data, envir = .GlobalEnv)
    lapply(names(models),
           function(x) {
               mod <- lm(models[[x]][["expr"]],data = data)

               summodel <- models[[x]][["summodel"]](mod)

               summodel
               ## return(list(data=dfaux,modelresults=summodel))
           })
}


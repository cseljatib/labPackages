#' @title Function that fits a list of models on a given dataframe.
#'
#' @param models List that contains the models to be fitted.
#' To know the structure, see examples below.
#' @param data `dataframe` that contains the values that correspond to
#' observed values and variables as columns.
#' @param file  a (writable binary-mode) connection or the name of the
#' file where the data will be saved (when tilde expansion is done).
#' @param file.full wheter to include all output (`TRUE`) or
#' just the fitted models plus their respective `pred.f` field
#' (`FALSE`, default).
#'
#'
#' @examples
#' ## list of example models
#' model.list <- list(
#'     mod1 = list(expr = vtot ~ I(dap^2) + I(dap^2 * atot^2) +I(d6),
#'                 pred.f = function(x, ...) x,
#'                 summodel = function(x, ...) datana::modresults(x)),
#'     mod2 = list(expr = I(log(vtot)) ~ I(log(dap)) + I(log(atot)),
#'                 pred.f = function(x, ...) exp(x),
#'                 summodel = function(x, ...) datana::modresults(x)))
#'
#' ## example dataframe
#' df <- treevolruca2
#' head(df)
#'
#' ## fitting models to dataframe
#' bankfit(models = model.list, data = df)
#'
#' @rdname bankfit
#' @export
##@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
bankfit <- function(models = models, data = data, file = NULL,
                    file.full = FALSE) {
    bankfit.out <- lapply(names(models),
                  function(x) {
                      mod <- lm(models[[x]][["expr"]], data = data)
                      summodel <- models[[x]][["summodel"]](mod)
                      pred.f <- models[[x]][["pred.f"]]
                      list(mod = mod, summ = summodel,
                           data = data, pred.f = pred.f)##saves the example dataframe
                  })
    names(bankfit.out) <- names(models)
    if (!is.null(file)) {
        if (file.full == FALSE) {
            bankfit.out <- lapply(bankfit.out, function(x) {
                x["data"] <- NULL
                x["summ"] <- NULL
                return(x)
            })
            save(bankfit.out, file = file)
        }
        if (file.full == TRUE) {
            save(bankfit.out, file = file)
        }
    } else {
        return(bankfit.out)
    }
}

fxforestvar<-function(dh){data.frame(nha = sum(dh$fexp),gha = sum(dh$gtree.ha),dmean= mean(dh$d),dg = dg.fx(n=sum(dh$fexp),g=sum(dh$gtree.ha)),ddom= domvar(data=dh,varint= "d",varsort= "d",plot.area=mean(dh$plot.area)),hmean= mean(dh$h),hdom= domvar(data=dh,varint= "h",varsort= "h",plot.area=mean(dh$plot.area))
,
vtot.ha = sum(dh$vtot.tree.ha))
}

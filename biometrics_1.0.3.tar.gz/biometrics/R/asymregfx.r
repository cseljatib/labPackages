#' Function of the asymptotic regression model, based
#' upon its parameters and a variable, as
#' follows
#' \deqn{y_i= \alpha +
#' \left(\beta-\alpha\right) \left\{\mathrm{e}^{
#' \left[-\left(\mathrm{e}^{-\gamma}\right) x_i \right]
#' }\right\},
#' }
#' where: \eqn{y_i} and \eqn{x_i} are the response
#' and predictor variable, respectively, for the *i*-th observation;  
#'  and the rest are parameters (i.e., coefficients).
#'
#' @title Function to compute the result of the asymptotic
#' regression model, as an allometric functional form.
#' @param x is the predictor variable.
#' @param paramod is a vector having the  coefficients
#' of the model in the following order:
#' \eqn{\alpha,\beta} and \eqn{\gamma}.
#' @param phi is an optional constant term that force the prediction
#' of *y* when *x=0*. Thus, the new model becomes
#' \eqn{ y_i = \alpha + \left(\phi-\alpha\right) \left\{\mathrm{e}^{
#' \left[-\left(\mathrm{e}^{\gamma}\right) x_i \right]
#' }\right\} }, thus the model will have only two parameters.
#' By default \eqn{\phi} is set to `NA`.
#'
#' @return Returns the response variable based upon
#' the predictor variable and the coefficients. 
#' @author Christian Salas-Eljatib.
#' @references
#' - Pinheiro JC, DM Bates. 2000. Mixed-effects Models in S and
#' Splus. New York, USA. Springer-Verlag. 528 p. 
#' - Salas-Eljatib C. 2025. Funciones matematicas y
#' sus reparametrizaciones para la alometria de arboles. Documento
#' de trabajo No. 1, Serie: Cuadernos de biometria,
#' Laboratorio de Biometria y Modelacion Forestal, Universidad
#' de Chile. Santiago, Chile. 52 p.
#' @examples
#' #---------------------
#' # 3-parameters variant
#' alpha<- 20; beta<- 2;gamma<-2.2
#' coefs<-c(alpha,beta,gamma);
#' # Predictor variable values to be used
#' time<-seq(0,50,by=0.1)
#' # Using the function
#' y<-asymreg.fx(x=time,paramod=coefs)
#' plot(time,y,type="l",ylim=c(0,20))
#' #---------------------
#' # 2-parameters variant
#' alpha<- 20; beta<- 2.2; forced.y0=1.3
#' coefs<-c(alpha,beta); #only two parameters
#' # Using the function, now phi must be provided
#' y<-asymreg.fx(x=time,paramod=coefs,phi =forced.y0)
#' plot(time,y,type="l",ylim=c(0,20))
#'  
#' @rdname asymreg.fx
#' @export
#'
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
asymreg.fx <- function(x=x, paramod=paramod, phi=NA){
    alpha<-paramod[1];beta<-paramod[2];
    if(is.na(phi)==TRUE){gamma<-paramod[3]}
    if(is.na(phi)==TRUE){y=alpha +(beta-alpha)*(exp(-exp(-gamma)*x))}
    ##when phi, which is y(0), is defined, then the model has only
    ## two parameters
    if(is.na(phi)==FALSE){y=alpha +(phi-alpha)*(exp(-exp(-beta)*x))}
    y
}

mySweaveSettings<-function(sweave.fold='SweaveTeXBib',docs.fold="docs",          fig.fold="figures",r.fold="r",data.fold="data",          datao.fold="dataouts",out.fold="outs",tab.fold="tables",          gis.fold="gisFiles",trash.fold='xnotreallyneeded')
{
##-------------------------------------------------------------------
# File: mySweaveSettings.R
# R file with my Sweave settings
#
# Here we define the sub-folders to be used when using sweavetexOrde.R
## Pre-last changes: Dec 16, 2009
## Last changes: feb6, 2026    
##- ----------------------------------------------------
#utils::globalVariables(c("cur.dirb","sw.dir"))

cur.dir.base<-getwd()    

    ##? Where is the folder where is the base Sweave file (*.Rnw)
    cur.path<-cur.dirb<-"../"    


#? subdirectory for Sweave codes
    subDirectorySw <- sweave.fold #'SweaveTeXBib'#
    len.mainfold<- nchar(subDirectorySw)

    root.folder<-datana::extractRight(cur.path,len.mainfold)    
    if(root.folder==subDirectorySw){run.from.sw.folder=1} else {run.from.sw.folder=0}
    
#? subdirectory for documents
subDirectoryDocs <- docs.fold#'docs'#
#? subdirectory for figures
subDirectoryF <- fig.fold#'figures'#
#?subdirectory for figures Fixed (not created from the R process)
#subDirectoryFf <<- 'figuresf' ##> not used anymore
#? subdirectory for R scripts
subDirectoryR <- r.fold#'r' #
#? subdirectory for Data
subDirectoryData <- data.fold#'data' #
#? subdirectory for DataOuts
subDirectoryDataO <- datao.fold#'dataouts' #
#? subdirectory for Outputs
subDirectoryO <- out.fold# 'outs' #
#? subdirectory for LaTeX tables
subDirectoryT<- tab.fold# 'tables' #
#? subdirectory for leaving all the rest files
subDirectoryBasu<- trash.fold# 'xnotreallyneeded' #
#? subdirectory for gis files
subDirectoryGis<- gis.fold# 'gisData' #

##* en caso que lo corra desde el Sweave main folder
if(run.from.sw.folder==1){    
if(is.null(subDirectorySw)){
       filePathSw <- getwd()} else {
       filePathSw <- cur.dirb}
}

##* en caso que no lo corra desde el Sweave main folder
if(run.from.sw.folder==0){
if(is.null(subDirectorySw)){
       filePathSw <- getwd()} else {
       filePathSw <- file.path(cur.dirb, subDirectorySw)}    
}

if(is.null(subDirectoryDocs)){
       filePathDocs <- getwd()} else {
       filePathDocs <- file.path(cur.dirb, subDirectoryDocs)}

if(is.null(subDirectoryF)){
       filePathF <- getwd()} else {
       filePathF <- file.path(cur.dirb, subDirectoryF)}         

## if(is.null(subDirectoryFf)){
##        filePathFf <- getwd()} else {
##        filePathFf <- file.path(cur.dirb, subDirectoryFf)}         

if(is.null(subDirectoryR)){
       filePathR <- getwd()} else {
       filePathR <- file.path(cur.dirb, subDirectoryR)}         

if(is.null(subDirectoryData)){
       filePathData <- getwd()} else {
       filePathData <- file.path(cur.dirb, subDirectoryData)}         

if(is.null(subDirectoryDataO)){
       filePathDataO <- getwd()} else {
       filePathDataO <- file.path(cur.dirb, subDirectoryDataO)}         


    
if(is.null(subDirectoryO)){
       filePathO <- getwd()} else {
       filePathO <- file.path(cur.dirb, subDirectoryO)}         

    filePathO.f <-
    paste(cur.dir.base, subDirectoryO,sep = "/")
    
if(is.null(subDirectoryT)){
       filePathT <- getwd()} else {
       filePathT <- file.path(cur.dirb, subDirectoryT)}         

if(is.null(subDirectoryBasu)){
       filePathBasu <- getwd()} else {
       filePathBasu <- file.path(cur.dirb, subDirectoryBasu)}         

if(is.null(subDirectoryGis)){
       filePathGis <- getwd()} else {
       filePathGis <- file.path(cur.dirb, subDirectoryGis)}         


##+ ===================================================
##! Defining the paths as objects to be used later
##+ ===================================================

sw.dir<-NULL;cur.dirb<-NULL;fig.dir<-NULL;r.dir<-NULL;
docs.dir<-NULL;data.dir<-NULL;datao.dir<-NULL;
out.dir<-NULL;tab.dir<-NULL;basu.dir<-NULL;gis.dir<-NULL;
    
assign("cur.dirb",cur.path, envir = .GlobalEnv)
##assign("sw.dir",filePathSw , envir = .GlobalEnv)        
assign("sw.dir",filePathSw , envir = .GlobalEnv) 
    ##    sw.dir<- filePathSw
assign("fig.dir",filePathF , envir = .GlobalEnv)    
#fig.dir<- filePathF
##figf.dir<<- filePathFf
assign("r.dir",filePathR , envir = .GlobalEnv)
                                        #    r.dir<- filePathR
assign("docs.dir",filePathDocs , envir = .GlobalEnv)    
##docs.dir<- filePathDocs
assign("data.dir",filePathData , envir = .GlobalEnv)    
    ##data.dir<- filePathData
assign("datao.dir",filePathDataO , envir = .GlobalEnv)        
##datao.dir<- filePathDataO
    assign("out.dir",filePathO , envir = .GlobalEnv)
    
    ##    out.dir<- filePathO
assign("out.dir.f",filePathO.f, envir = .GlobalEnv)    
assign("tab.dir",filePathT, envir = .GlobalEnv)
##    tab.dir<- filePathT
assign("basu.dir",filePathBasu, envir = .GlobalEnv)
#    basu.dir<- filePathBasu
assign("gis.dir",filePathGis, envir = .GlobalEnv)
#    gis.dir<- filePathGis
}

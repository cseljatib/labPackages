#' Computes the so-called dominant stand-level variable,
#' corresponding to the average of a tree-level variable for
#' the `nref.ha` largest sorting-tree-level diameter trees in 1-ha.
#'
#' @details The original function was written by Dr Oscar García for computing
#' top height, and the corresponding reference is provided. Nevertheless,
#' several changes were applied, to make the current function provide a broader
#' application. Regardless, the function aims to calculate a "dominant"
#' stand-level variable by taking into account the plot area.
#' Thus, requires having a dataframe having both the variable
#' of interest (e.g., height) and the sorting variable used for the
#'  computation (e.g., diameter) for all trees in a sample plot, as well as,
#' the plot area.
#'
#' @title Function to compute a dominant stand-level variable based on
#' a sample plot data.
#' @param data data frame having the tree list of a sample plot.
#' @param var.int The column name of the data having the tree-level variable of
#'  interest (e.g., "toth"). Can be entered as the actual name, without the
#'  need of using quotation marks.
#' @param var.sort The column name of the data having the tree-level variable
#' to be used as reference (e.g., "dbh") for defining the sorting variable
#'  of interest.
#' @param plot.area A numeric value of the plot area in m\eqn{^{2}}{^2}.
#' @param nref.ha It is the number of trees/ha used as reference. By default `nref.ha` is set to 100..
#'
#' @return The main output is the calculated dominant stand-variable for the
#' given sample plot. The unit of the computed variable is the same as the
#' one used as variable of interest.
#'
#' @author Christian Salas-Eljatib.
#' @references
#' - García O, Batho A. 2005. Top height estimation in lodgepole pine
#'  sample plots. Western Journal of Applied forestry 20(1):64-68.
#'
#' @examples
#'
#' # Dataframe to be used
#' df<-biometrics::eucaplot2
#' ?eucaplot2
#' head(df)
#' datana::descstat(df)
#' # Using the domvar function
#' domvar(data=df,var.int="atot",var.sort="dap",plot.area=500)
#' @rdname domvar
#' @export
#'
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
domvar <-function(data=data,var.int=var.int,var.sort=var.sort,
                  plot.area=plot.area,nref.ha=100){
df<-data;
df$y<-df[,var.int];df$x<-df[,var.sort];
## yvar.name<-substitute(var.int);yvar.name<-as.character(yvar.name)
## xvar.name<-substitute(var.sort);xvar.name<-as.character(xvar.name)
## df$y<-df[[yvar.name]];df$x<-df[[xvar.name]];
sorty.byx<-df[ order(-df$x), "y"]; sorty.byx
ntrees.plot<- length(sorty.byx)   
 plot.ha<-plot.area/10000;plot.ha
 nref.plot<-A<-plot.ares<-plot.ha*nref.ha;plot.ares
 nref.plot  #number of A-largest trees in the plot   
    m <- ntrees.plot / A; m #nref.ares
    mlo <- floor(m); mlo
    mhi <- ceiling(m); mhi
    U <- uestimator(sort.y=sorty.byx, n.are=mlo)
    if (mhi == mlo) return(U)
    (mhi - m) * U + (m - mlo) * uestimator(sort.y=sorty.byx, n.are=mhi)
}

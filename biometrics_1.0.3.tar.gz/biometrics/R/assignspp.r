#' Function that assigns species name information to a data frame
#'
#' @description
#' Assigns the requested names using `biometrics::spp`
#' dataset. Internally it uses the `merge()` function, so the `refcol`
#' parameter has to exists both in the given `data` and in
#' `biometrics::spp`. Aditional `merge()` parameters can be passed to
#' this function.
#'
#' @param data
#' Dataframe to assign names.
#'
#' @param names
#' String names to assign. This names has to exists in
#' `biometrics::spp`. Multiple values can be specified within a
#' vector. Defaults to common name ("spp.name"), scientific name
#' ("spp.ci.name") and scientific abbreviated name ("spp.ci.abb").
#'
#' @param refcol Column to select to assign name based on.
#'
#' @param all.x Whether to preserve not finded values (`TRUE`,
#' default) or not (`FALSE`).
#'
#' @param ... Other options used to control behavior of [base::merge()].
#'
#' @seealso [base::merge()] which this function wraps.
#'
#' @returns A dataframe object with merged data.
#' @examples
#' ## example data frame
#' myData <- data.frame(narb = c(1, 2, 3),
#'                      esp = c("nob", "np", "nd"),
#'                      htot = c(20, 14, 23))
#' myData
#'
#'
#' ## assign common, scientific and abbreviated name, based on `esp` value (default)
#' assignspp(myData)
#'
#' ## assign scientific name based on common name
#' ## first we assign the common name
#' newData <- assignspp(myData, "spp.name")
#' assignspp(newData, "spp.ci.name", "spp.name")
#'
#' ## by default this function preserve names not found in biometrics::spp
#' missingData <- rbind(myData, c(4, "notFoundData", 30))
#' missingData
#' assignspp(missingData, "spp.name")
#' ##this can be modified with `merge()` parameters
#' assignspp(missingData, "spp.name", all.x = FALSE)
#' @rdname assignspp
#' @export
##@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
assignspp <- function(data,
                      names = c("spp.name", "spp.ci.name",
                                "spp.ci.abb"),
                      refcol = "esp", all.x = TRUE, ...) {

    tomerge <- c(refcol, as.vector(names))
    merge(data, biometrics::spp[, tomerge], by = refcol,
          all.x = all.x, ...)
}

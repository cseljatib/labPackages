#' Function of the asymptotic regression model that is
#' constrained to pass through the origin, based
#' upon parameters  (i.e., coefficients) and a variable, as
#' follows
#' \deqn{y_i= \alpha
#' \left\{1- \mathrm{e}^{
#' \left[-\left(\mathrm{e}^{-\beta}\right) x_i \right]
#' }\right\}
#' }
#' where: \eqn{y_i} and \eqn{x_i} are the response
#' and predictor variable, respectively, for the *i*-th observation;  
#'  and the rest are parameters (i.e., coefficients).
#'
#' @title Function to compute the result of the asymptotic
#' regression model  that is constrained to pass through the origin,
#' as an allometric functional form.
#' @param x is the predictor variable.
#' @param a is the coefficient-parameter  \eqn{\alpha}.
#' @param b is the  coefficient-parameter  \eqn{\beta}.
#' @param phi is an optional constant term that force the prediction
#' of *y* when *x=0*. Thus, the new model becomes
#' \eqn{ y_i = \phi+ f(x_i,\mathbf{\theta})}, where
#' \eqn{\mathbf{\theta}} is the vector of coefficients of
#' the above described function represented by
#' \eqn{f(\cdot)}. The default
#' value for \eqn{\phi} is 0.
#'
#' @return Returns the response variable based upon
#' the predictor variable and the coefficients. 
#' @author Christian Salas-Eljatib.
#' @references
#' - Pinheiro JC, DM Bates. 2000. Mixed-effects Models in S and
#' Splus. New York, USA. Springer-Verlag. 528 p.
#' - Salas-Eljatib C. 2025. Funciones matemáticas y
#' sus reparametrizaciones para la alometría de árboles. Documento
#' de trabajo No. 1, Serie: Cuadernos de biometría,
#' Laboratorio de Biometría y Modelación Forestal, Universidad
#' de Chile. Santiago, Chile. 52 p. \url{https://biometriaforestal.uchile.cl}
#' @examples
#' # Predictor variable values to be used
#' time<-seq(5,80,by=0.01)
#' # Using the function
#' y<-asymori.fx(x=time,a=20,b=2)
#' plot(time,y,type="l")
#'  
#' @rdname asymori.fx
#' @export
#'
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
asymori.fx <- function(x, a=alpha,b=beta, phi=0){ 
    alpha<-a;beta<-b;   
    phi+ alpha * (1-exp(-exp(beta)*x))
}

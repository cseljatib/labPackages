#' Function of the originally proposed allometric model by Curtis,
#' based upon two parameters, and a single predictor variable as
#' follows
#' \deqn{y_i= \frac{x_i}{\alpha +\beta x_i},}
#' where: \eqn{y_i} and \eqn{x_i} are the response
#' and predictor variable, respectively, for the *i*-th observation;  
#'  and the rest are parameters (i.e., coefficients). Please read the
#' details on this model in Salas-Eljatib (2025).
#'
#' @title Function to computes the result of the original
#' Curtis's allometric model.
#' @param x is the predictor variable.
#' @param paramod is a vector having the  coefficients
#' of the model in the following order: \eqn{\alpha,\beta}.
#' @param phi is an optional constant term that force the prediction
#' of *y* when *x=0*. Thus, the new model becomes
#' \eqn{ y_i = \phi+ f(x_i,\mathbf{\theta})}, where
#' \eqn{\mathbf{\theta}} is the vector of coefficients of
#' the above described function represented by
#' \eqn{f(\cdot)}. The default
#' value for \eqn{\phi} is 0.
#'
#' @return Returns the response variable based upon
#' the predictor variable and the coefficients. 
#' @author Christian Salas-Eljatib.
#' @references
#' - Curtis RO. 1967. Height-diameter and height-diameter-age
#' equations for second-growth Douglas-fir. Forest Sci. 13(4):365-375.
#' - Salas-Eljatib C. 2025. Funciones matematicas y
#' sus reparametrizaciones para la alometria de arboles. Documento
#' de trabajo No. 1, Serie: Cuadernos de biometria,
#' Laboratorio de Biometria y Modelacion Forestal, Universidad
#' de Chile. Santiago, Chile. 52 p.
#' @examples
#' # Parameters
#' alpha<- 20; beta<- 8;
#' coefs<-c(alpha,beta);
#' # Predictor variable values to be used
#' time<-seq(5,60,by=0.01)
#' # Using the function
#' y<-curtisori.fx(x=time,paramod=coefs)
#' plot(time,y,type="l")
#'  
#' @rdname curtisori.fx
#' @export
#'
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
curtisori.fx <- function(x=x, paramod=paramod, phi=0){
    alpha<-paramod[1];beta<-paramod[2];
    phi+ (x/(alpha+beta*x)) 
}

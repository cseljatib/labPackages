#' Listado de especies con nombres científicos y comunes
#'
#' @usage
#' data(spp)
#'
#' @format
#' Contiene las siguientes columnas:
#' \describe{
#'   \item{numtaxon}{}
#'   \item{reino}{}
#'   \item{division}{}
#'   \item{clase}{}
#'   \item{orden}{}
#'   \item{familia}{}
#'   \item{spp.ci.full}{}
#'   \item{spp.ci.gen}{}
#'   \item{spp.ci.epi}{}
#'   \item{autorespecie}{}
#'   \item{subespecie}{}
#'   \item{autorsubespecie}{}
#'   \item{variedad}{}
#'   \item{autorvariedad}{}
#'   \item{forma}{}
#'   \item{autorforma}{}
#'   \item{nombrecomun}{}
#'   \item{sinonimia}{}
#'   \item{paiseslimitrofes}{}
#'   \item{habito}{}
#'   \item{ciclodevida}{}
#'   \item{statussegunorigen}{}
#'   \item{distribucionregional}{}
#'   \item{rangoaltitudinal}{}
#'   \item{notas}{}
#'   \item{esp}{Abreviatura de la especie.}
#'   \item{spp.name}{Nombre común de la especie.}
#'   \item{spp.ci.abb}{Nombre científico abreviado.}
#'   \item{spp.ci.name}{Nombre científico de la especie.}
#'   \item{spp.co.name.latex}{}
#'   \item{spp.co.name}{}
#' }
######################################################################
'spp'

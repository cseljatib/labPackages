#' Computes several descriptive statistics of variables at
#' the tree-level per sample plot. It can also be be applied
#' to compute them by levels of factor within each available plot.
#'
#' @details For a given tree list of a sample plot, several
#' descriptive statistics are computed for the selected random
#' variables, by plot and measurement year. 
#'
#' @title Function to compute descriptive statistics at tree-level,
#' segregated by a factor (`factvar`) per sample plot.
#' @param data data frame having the tree list of a sample plot.
#' @param plot.id a string having the plot code-number or unique
#' identificator.
#' @param t a number of year of measurement, if not provided the
#' current year is assigned by default.
#' @param y a string-vector with the name(s) of the random
#' variable(s) to which the descriptive statistics will be
#' computed. By default uses `dbh` as the name of the variable.
#' @param d a text of the column-name having the diameter at
#' breast-heigth. By default is assumed to be in cm. See option
#' `metrics` to change it to the imperial system.
#' @param factvar a string having de name of the variable
#' used as factor. Each level of the 'factvar` is a category.
#' @param t a number of year of measurement, if not provided the
#' current year is assigned by default.
#' @param full logical; if `TRUE`, the output includes some extra
#' descriptive statistics as explained in the datana::descstat()
#' function. The default is to `FALSE`.
#' @param short.names logical; if `TRUE`, the name of the
#' statistics are short names as explained in the datana::descstat()
#' function. The default is to `FALSE`.
#' @param eng logical; if `TRUE` (by default), the language of some
#' of the output-column names will be English; if "FALSE" will
#' be Spanish. For instance, the levels of the
#' factor-variable (`factvar`) is named "level"; otherwise will be
#' "nivel".
#' @param metric is a logic value, the default is to `TRUE`, thus
#' the diameter `d` has to be in cm, and the resulting tree-level
#' basal area will be in m\eqn{^{2}}{^2}. If `metric` is `FALSE`,
#' the diameter `d` has to be in inches, and the computed tree
#' basal area will be in ft\eqn{^{2}}{^2}.
#' @param ... aditional options for basic stats functions.
#'
#' @return Returns a data frame with the statistics per plot and
#' time for the selected y variables. If `factvar` is given, the
#' same statistics will be added but segregated by each level
#' (or category) of the `factvar`.
#'
#' @author Christian Salas-Eljatib.
#' @references
#' - Salas-Eljatib C. 2025. Biometría y Modelación Forestal.
#'  Borrador de libro, en revisión. 352 p.
#'
#' @examples
#'
#' # Dataframe to be used
#' df<-biometrics::eucaplot2
#' #?eucaplot2
#' head(df)
#' datana::descstat(df[,c("dap","atot")])
#' df$parce<-1
#' ## Using the function
#' treestat(data=df,plot.id="parce",y="atot",d="dap")
#' # Now, for two random variables, instead of a single one 
#' treestat(data=df,plot.id="parce",y=c("dap","atot"),d="dap")
#' # Do the same as before, but adding the computation by a factor
#' treestat(data=df,plot.id="parce",y="atot",d="dap",factvar="clase.copa")
#' df$time<-2025;df$time[1:5]<-2020
#' df
#' ## Using the function per measurement year
#' treestat(data=df,plot.id="parce",y="atot",d="dap",t="time",full=TRUE)
#' # Do the same as before, but adding the computation by a factor
#' treestat(data=df,plot.id="parce",y="atot",d="dap",t="time",factvar="clase.copa",full = TRUE)
#' ## same as before, but for two random variables
#' treestat(data=df,plot.id="parce",y=c("dap","atot"),d="dap",
#' t="time",factvar="clase.copa",full = TRUE)
#' @rdname treestat
#' @export
#'
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
treestat <- function(data, plot.id, t = NA,
     y, d=NA, factvar = NA, full=FALSE,short.names=TRUE,
     metric = TRUE, eng=TRUE,...)
{
    if(eng==TRUE){level.name<-"level"}
    if(eng==FALSE){level.name<-"nivel"}
    
##- =============================    
##+ Inicio de funcion interna-especifica clave    
fxdescstatdf<-function(dh,...) {
    data.frame(t(datana::descstat(dh,...))
 )}
##+ termino de funcion clave
##- =============================
    
  df <- data
  if (sum(is.element(y, "g"))) {
    if (is.na(d)) {
      stop("Error: tree dbh column-name not found")
    }
  }
  df$d <- df[, d]
  df$g <- gtree(x=df$d,metric=metric)
  df$plot.id <- df[, plot.id]

##? Is there any factor-variable?
  catego <- prod(!is.na(factvar));catego
  
  if (is.na(t)) {
    df$t <-  as.numeric(format(Sys.Date(), "%Y"))
    t = "t"
  }  
  if (!is.na(t)) {df$t <- df[, t]}
  if(full==TRUE){reduced=FALSE}
  num.variables<-length(unique(y))
  out<-c(); out.factvar<-c()
  for (i in 1:num.variables) {
    df$y <- df[, y[i]]
    stat.names<-row.names(datana::descstat(df$y,full = full,short.names = short.names))
    stat.names

##+ (1) Computing without seggregation
    by.keys <- c(plot.id,t);by.keys
    out.i<-by(df$y, df[,by.keys], fxdescstatdf,full=full,short.names=short.names)
    out.i<-array2DF(out.i,simplify = TRUE)
    names(out.i)<-c(by.keys,paste(stat.names, ".", y[i],sep = ""))
##!the following was working OK previously   
##     out.i<-aggregate(df$y, by=list(df$plot.id, df$t),
##                       FUN = datana::descstat,
##                       full=full,short.names = short.names)
##     output.col<-datana::findColumn.byname(out.i,"x")
##     out.i<-data.frame(cbind(out.i[,-output.col], t(data.frame(out.i[,output.col]))))
## names(out.i)<-c(by.keys,paste(stat.names, ".", y[i],sep = ""))
##     row.names(out.i)<-1:nrow(out.i)
    if(!is.null(out)){out <- merge(out, out.i, by = c(plot.id, t))}
    if(is.null(out)){out<-out.i}
  }

##+ (2) Computing per levels of the factor-variable     
 if (catego == 1) {
    df$factvar <- df[, factvar]
    cl.factvar<-unique(df$factvar)
    n.cate<-length(cl.factvar);n.cate
    for (i in 1:length(unique(y))) {
     df$y <- df[, y[i]]
     by.keys <- c(plot.id,t,factvar);by.keys
     out.ij<-by(df$y, df[,by.keys], fxdescstatdf,full=full,short.names=short.names)
     out.ij<-array2DF(out.ij,simplify = TRUE)
     out.ij
    names(out.ij)<-c(by.keys[1:2],level.name,paste(stat.names, ".", y[i],sep = ""))
##!the following was workin propertly before          
   ## by.keys.fac <- c(by.keys,factvar);by.keys.fac
   ##  out.ij<-aggregate(df$y, by=list(df$plot.id, df$t,df$factvar),
   ##                    FUN = datana::descstat,
   ##                   full=full,short.names = short.names)
   ##  output.col<-datana::findColumn.byname(out.ij,"x");output.col
   ##  out.ij<-data.frame(cbind(out.ij[,-output.col], t(data.frame(out.ij[,output.col]))))
   ##      names(out.ij)<-c(by.keys,"level",paste(stat.names, ".", y[i],sep = ""))
   ## row.names(out.ij)<-1:nrow(out.ij)
    #    out.ij
    out.ij$factor <- factvar
    if(eng==TRUE){out.ij$level <- as.factor(out.ij$level)}
    if(eng==FALSE){out.ij$nivel <- as.factor(out.ij$nivel)}

    if(!is.null(out.factvar)){out.factvar <- merge(out.factvar, out.ij, by = c(plot.id, t,"factor",level.name))}     
    if(is.null(out.factvar)){out.factvar<-out.ij}    
      }    
  }

if(!is.na(factvar)){  
if(eng==TRUE){out$factor <- "None"}
   if(eng==FALSE){out$factor <- "Ninguno"}    
   if(eng==TRUE){out$level <- "All"}
   if(eng==FALSE){out$nivel <- "Todos"} 
  out <- rbind(out, out.factvar)
  ini.col<-datana::findColumn.byname(out,t)+1;ini.col
  end.col<-datana::findColumn.byname(out,"factor")-1;end.col
   ## if(eng==TRUE){order.cols<-c(plot.id,t,"factor","level")}
   ## if(eng==FALSE){order.cols<-c(plot.id,t,"factor","nivel")}
order.cols<-c(plot.id,t,"factor",level.name)
out1<-out[,order.cols];out1
 out2<-out[,ini.col:end.col];out2 
  out<-cbind(out1,out2)
}
    out<-out[order(out[,t],out[,plot.id]),]
if(!is.na(factvar)){  
#if(eng==TRUE){out<-out[order(out[,t],out[,plot.id],out[,"level"]),]} 
#if(eng==FALSE){out<-out[order(out[,t],out[,plot.id],out[,"nivel"]),]}
out<-out[order(out[,t],out[,plot.id],out[,level.name]),]
}
out        
}

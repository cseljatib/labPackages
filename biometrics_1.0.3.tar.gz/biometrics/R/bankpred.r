#' @title Function that predicts the variable of interest for each model
#' and generates a dataframe with the results.
#' @param file  a (writable binary-mode) connection or the name of the
#' file where the data will be saved (when tilde expansion is done).
#' @param newdata An auxiliary dataframe for the prediction of the
#' response variable's values using a data sample distinct from the
#' one employed for model fitting.
#' @examples
#' \dontrun{
#' ## list of example models
#' model.list <- list(
#'     mod1 = list(expr = vtot ~ I(dap^2) + I(dap^2 * atot^2) +I(d6),
#'                 pred.f = function(x, ...) x,
#'                 summodel = function(x, ...) datana::modresults(x)),
#'     mod2 = list(expr = I(log(vtot)) ~ I(log(dap)) + I(log(atot)),
#'                 pred.f = function(x, ...) exp(x),
#'                 summodel = function(x, ...) datana::modresults(x)))
#' 
#' ## example dataframe
#' df <- treevolruca2
#' head(df)
#' 
#' ## fitting models to dataframe and saving them
#' bankfit(models = model.list, data = df, file = "out.rdata")
#' 
#' 
#' ## using fitted models file from biometrics::bankfit()
#' bankpred(file = "out.rdata") 
#' }
#' @rdname bankpred
#' @export
##@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
bankpred <- function(file = stop("you must provide a file"),
                     newdata = NULL) {
    bankfit.out <- NULL ## hack tpo get around CMD check
    load(file) ##! CSE: que lea tambien objetos, no solo archivos
    bankpred.out <- lapply(names(bankfit.out), function(x) {
        mod <- bankfit.out[[x]]$mod
        pred.f <- bankfit.out[[x]]$pred.f
        ## if newdata is provided
        if (!is.null(newdata)) {
            yhat <-  tryCatch(predict(mod, newdata), error = function(e) NA)
            ypred <- tryCatch(pred.f(x = yhat, dap = newdata$dap), error = function (e) NA)
            dfh <- newdata
        }
        ## if newdata is NULL
        if (is.null(newdata)) {
            yhat <- predict(mod)
            dfh <- bankfit.out[[x]]$data
            ypred <- tryCatch(pred.f(x = yhat, dap = dfh$dap), error = function (e) NA)
        }
        list(yhat = yhat, ypred = ypred, dfh = dfh)
    })
    ## listado de modelos
    names(bankpred.out) <- names(bankfit.out)
    dfs <-lapply(names(bankpred.out), function(z) {
        dfaux <- bankpred.out[[z]]$dfh
        dfaux$y.hat <- bankpred.out[[z]]$yhat
        dfaux$y.pred <- bankpred.out[[z]]$ypred
        dfaux$model <- z
        return(dfaux)
    })
    names(dfs) <- names(bankfit.out)

    ## todos los dataframes por modelo unidos
    dfout <- do.call(rbind, dfs)
    rownames(dfout) <- NULL
    list(listpred = bankpred.out, dflist = dfs, dfout=dfout)
}

#' Function of the Ratkowsky allometric
#' model, based upon parameters (i.e., coefficients) and a variable,
#' as defined by the mathematical expression
#' \deqn{y_i= \alpha
#' \mathrm{e}^{\left(\frac{-\beta}{x_i +\gamma}\right)},
#' }
#' where: \eqn{y_i} and \eqn{x_i} are the response
#' and predictor variable, respectively, for the *i*-th observation;  
#'  and the rest are parameters (i.e., coefficients).
#' Further details on this function can be found in
#' Salas-Eljatib (2025).
#'
#' @title Function that computes the result of the Ratkowsky
#' allometric model.
#' @param x is the predictor variable.
#' @param paramod is a vector having the  coefficients
#' of the model in the following order:
#' \eqn{\alpha,\beta} and \eqn{\gamma}.
#' @param phi is an optional constant term that force the prediction
#' of *y* when *x=0*. Thus, the new model becomes
#' \eqn{ y_i = \phi+ f(x_i,\mathbf{\theta})}, where
#' \eqn{\mathbf{\theta}} is the vector of coefficients of
#' the above described function represented by
#' \eqn{f(\cdot)}. The default
#' value for \eqn{\phi} is 0.
#'
#' @return Returns the response variable based upon
#' the predictor variable and the coefficients. 
#' @author Christian Salas-Eljatib.
#' @references
#' - Zhang L. 1997. Cross-validation of non-linear growth functions
#' for modelling tree height-diameter relationships. Annals of
#' Botany 79(3):251–257.
#' - Salas-Eljatib C. 2025. Funciones matematicas y
#' sus reparametrizaciones para la alometria de arboles. Documento
#' de trabajo No. 1, Serie: Cuadernos de biometria,
#' Laboratorio de Biometria y Modelacion Forestal, Universidad
#' de Chile. Santiago, Chile. 52 p.
#' @examples
#' # Parameters
#' alpha<- 28; beta<- 34; gamma<-0.85
#' coefs<-c(alpha,beta,gamma);
#' # Predictor variable values to be used
#' d<-seq(5,60,by=0.01)
#' # Using the function
#' h<-ratkow.fx(x=d,paramod=coefs)
#' plot(d,h,type="l")
#'  
#' @rdname ratkow.fx
#' @export
#'
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
ratkow.fx <- function(x=x, paramod=paramod, phi=0){
    alpha<-paramod[1];beta<-paramod[2]; gamma<-paramod[3];     
    phi+ alpha*exp(-beta/(x+gamma))
}

#' Ozono en LA en 1976
#'
#' @description
#' Un estudio de la relación entre la concentración atmosférica de
#' ozono y la metereología en la Cuenca de Los Ángeles en 1976. Un
#' número de casos con variables sin registro fueron removidos por
#' simplicidad.
#'
#' @usage
#' data(ozone2)
#'
#' @format Un data frame con 330 observaciones de las siguientes 10
#' variables.
#' \describe{
#'     \item{O3}{concentración de ozono en ppm, en Standbug AFB.}
#'     \item{vh}{un vector numérico}
#'     \item{viento}{velocidad del viento}
#'     \item{humedad}{un vector numérico}
#'     \item{temp}{temperatura}
#'     \item{ibh}{altura base de inversión}
#'     \item{gpd}{gradiente de presión de Dragget}
#'     \item{ibt}{un vector numérico}
#'     \item{vis}{visibilidad}
#'     \item{dia}{día del año}
#' }
#'
#' @source
#' Los datos fueron obtenidos desde la dataframe `ozone` de la
#' librería `faraway`.
#'
#' @references
#' Breiman, L. and J. H. Friedman (1985). Estimating optimal
#' transformations for multiple regression and correlation. Journal of
#' the American Statistical Association 80, 580-598.
#'
#' @examples
#' data(ozone2)
#' head(ozone2)
#' plot(O3 ~ temp, data = ozone2)
"ozone2"

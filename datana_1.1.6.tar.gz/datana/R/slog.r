#' Safe logarithm
#'
#' Computes the logarithm of a numeric input, if the calculation
#' throws an error (_i.e._, a zero or a negative argument is passed as
#' input) an small value is added to the argument to compute again.
#'
#' @param x a numeric or complex vector.
#' @param n the small value to add to `x`, 1e-10 by default.
#' @param ... optional arguments to pass to [base::log()].
#' @return A vector of the same length as ‘x’ containing the
#' transformed values.
#' @examples
#' log(c(1, 0, -1))
#' slog(c(1, 0, -1))
#' @export
######################################################################
slog <- function(x, n = 1e-10, ...) {
    input <- log(x, ...)
    if (any(is.nan(input)) || any(is.infinite(input))) {
        log(x + n, ...)
    } else {
        input
    }
}

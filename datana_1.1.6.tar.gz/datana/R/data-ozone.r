#' Ozone in LA in 1976
#'
#' @description
#' A study the relationship between atmospheric ozone concentration
#' and meteorology in the Los Angeles Basin in 1976. A number of cases
#' with missing variables have been removed for simplicity.
#'
#' @usage
#' data(ozone)
#'
#' @format A data frame with 330 observations on the following 10
#' variables.
#' \describe{
#'     \item{O3}{Ozone conc., ppm, at Standbug AFB.}
#'     \item{vh}{a numeric vector}
#'     \item{wind}{wind speed}
#'     \item{humidity}{a numeric vector}
#'     \item{temp}{temperature}
#'     \item{ibh}{inversion base height}
#'     \item{dpg}{Daggett pressure gradient}
#'     \item{ibt}{a numeric vector}
#'     \item{vis}{visibility}
#'     \item{day}{day of the year}
#' }
#'
#' @source
#' The data were assembled from the `ozone` dataframe from the
#' `faraway` library.
#'
#' @references
#' Breiman, L. and J. H. Friedman (1985). Estimating optimal
#' transformations for multiple regression and correlation. Journal of
#' the American Statistical Association 80, 580-598.
#'
#' @examples
#' data(ozone)
#' head(ozone)
#' plot(O3 ~ temp, data = ozone)
"ozone"

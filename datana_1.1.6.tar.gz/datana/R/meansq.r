#' Computes the mean square of a numeric vector. It is the
#' following
#' \deqn{\frac{1}{n} \sum_{i=1}^{n} y_i^{2}}
#'
#' @details For instance, It could be useful for computing the
#' mean squared error of a model.
#'
#' @title Function to compute the mean square of a vector
#' @param v is a numeric vector
#'
#' @return This function returns the mean square, i.e., a numeric scalar.
#' @author Christian Salas-Eljatib.
#' @references
#' Salas-Eljatib, C. 2021. Análisis de datos con el programa
#'  estadístico R: una introducción  aplicada. Ediciones
#'  Universidad Mayor, Santiago, Chile. 170 p.
#'  \url{https://eljatib.com/rlibro}
#' @examples
#'
#' x <- rnorm(10, mean=134, sd=10)
#' meansq(x)
#' @rdname meansq
#' @export
#'
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
##! # Mean squared of a numeric vector `v`
meansq<-function(v) {
     sum(v^2)/length(v)
}

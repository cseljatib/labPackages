##! # Mean squared of a numeric vector `v`
meansq<-function(v) {
     sum(v^2)/length(v)
}

#' Cobertura territorial, ambiental y sociodemografica de los 34
#' municipios que componen el area del Gran Santiago, Santiago, Chile..
#'
#' @description
#' El conjunto de datos contiene 476 observaciones, 34 categoricas y
#'  442 numericas. Los datos de cobertura
#' terrestre se generaron mediante tecnicas de clasificacion de
#' teledeteccion utilizando imagenes de satelite
#' Sentinel-2 del año 2016. Las temperaturas se obtuvieron de la banda
#'  TIRS 10 de las imagenes de los satelites
#' Landsat 8. Las concentraciones de material particulado se estimaron
#' mediante tecnicas de modelado espacial
#' de 10 estaciones de contaminacion distribuidas en la ciudad. La altitud
#' se genero a partir de un modelo de
#' elevacion digital. La poblacion y la pobreza se obtuvieron de la encuesta
#' Casen 2017.
#' @usage
#' data(landcover2)
#' @format Variables se describen a continuacion:
#' \describe{
#' \item{comuna}{Name of Municipality}
#' \item{const.p}{Porcentaje de superficie cubierta por area construida}
#' \item{vegeta.p}{Porcentaje de superficie cubierta por vegetacion}
#' \item{desnu.p}{Porcentaje de superficie cubierta por suelo desnudo}
#' \item{pasto.p}{Porcentaje de superficie cubierta por cesped}
#' \item{deci.p}{Porcentaje de superficie cubierta por vegetacion de
#' hoja caduca}
#' \item{sverde.p}{Porcentaje de superficie cubierta por vegetacion
#' siempre verde}
#' \item{temp.inv}{Temperatura de la superficie terrestre en grados
#'  celsius a las 2 p.m.en un dia de invierno con 0% de nubes}
#' \item{temp.ver}{Temperatura de la superficie de la tierra en grados
#'  celsius a las 2 p.m.en un dia de verano con 0% de nubes}
#' \item{pm10.inv}{Material particulado promedio de 10 micrones durante
#' los meses de invierno}
#' \item{pm10.ver}{Material particulado promedio de 10 micrones durante
#'  los meses de verano}
#' \item{pobreza.p}{Porcentaje de personas por debajo de la linea de
#' pobreza año 2017}
#' \item{altitud}{Altitud media del termino municipal}
#' \item{pob}{Poblacion total del municipio}
#'  }
#' @source
#' Los datos fueron cedidos por el Dr Ignacio Fernandez de la
#'  Universidad Adolfo Ibañez (Santiago, Chile).
#' @references
#' Not yet
#' @examples
#' data(landcover2)
#' head(landcover2)
'landcover2'

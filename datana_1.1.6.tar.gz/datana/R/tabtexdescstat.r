#' Function to create a LaTeX file for a table of
#'  descriptive statistics of continuous variables from a dataframe.
#' 
#' @details The resulting file is a LaTeX table, that can be
#' added to your main LaTeX document by using `\input{filename}`.
#' 
#' @title Creates a LaTeX file having a descriptive statistics table
#' for continuous variables
#' @param data a dataframe containing numeric variables as columns.
#' @param y a string having the column names of the dataframe
#' to which the descriptive statistics will be computed.
#' @param varnames a string having the name of each of the variables
#' to be used in the LaTeX table, thus they are fancyer. The length of
#' `varnames` must be equal to the length of `y`.
#' @param cap a string having the caption of the LaTeX table.
#' @param nametab a string having a brief name to be used in
#' both the label of the table and the file name. For instance,
#' if "=descdata", the table can be refered in your LaTeX
#' document by using `\ref{tab:descdata}`
#' @param save.file The defauls is set to ``FALSE'', if is set to
#' TRUE, then the option `filename` must be provided.
#' @param filename A string having the name of the resulting LaTeX
#' file having the table. The default is set to "tabdescdata.tex".
#' @param rowlab a character with the name to be used as label for
#' the column where the variables will be printed. The default is
#' set to "Variables".
#' @param font.size.tab The defauls is set to "normalsize". You could
#'  also try with "footnotesize". 
#' @param font.type.tab The defauls is set to "normalfont".
#' @param ... Other options of the main functions being used here.
#' Such as the ones passed to the descstat() function: `decnum` for
#' the decimal points to be used in the table, `eng` for either
#' English or Spanish in the statistic names, and `landscape` in
#' case you want to have the statistics as columns instead of rows,
#' in wich case you should use `landscape=TRUE`.
#' By default `landscape` is set to `FALSE`, thus the output table
#' will have the statistics as rows, and in each column the variables.
#' Otherwise, if `TRUE` the variables will be the rows, and each
#' statistics the columns. This option is only recommended when no
#' factors are included in the processing.
#' 
#' @importFrom utils head
#'
#' @return This function creates a LaTeX file having 
#' the following descriptive statistics: sample size, minimum,
#' maximum, mean, median, SD, and coefficient of variation. 
#'   If the full option is set to TRUE, the following statistics
#' are added to the table: 25th and 75th percentiles, the
#' interquartile range, skewness, and kurtosis.
#' @author Christian Salas-Eljatib.
#' @references
#' Salas-Eljatib, C. 2021. Análisis de datos con el programa
#' estadístico R: una introducción aplicada. Ediciones Universidad
#' Mayor, Santiago, Chile. 170 p. \url{https://eljatib.com/rlibro}
#' @examples
#'
#' df <- datana::idahohd
#' head(df)
#' descstat(data=df,y=c("dbh","toth"))
#' 
#' ##! Example 1 
#' tabtexdescstat(data=df,y=c("dbh","toth"),
#'      varnames = c("Diameter","Height"),nametab="idaho",
#'  cap="Descriptive statistics table")
#' ##! Example 2
#' tabtexdescstat(data=df,y=c("dbh","toth"),
#' varnames = c("Diametro","Altura"),nametab="idaho",
#' cap="Cuadro con estadistica descriptiva",eng=FALSE)
#' ##! Example 3: variables as columns
#' descstat(data=df,y=c("dbh","toth"),landscape =  TRUE)
#' tabtexdescstat(data=df,y=c("dbh","toth"),
#'   varnames= c("Diameter","Height"),landscape = TRUE,nametab="idaho",
#'     cap="Descriptive statistics table--landscape orientation")
#' @rdname tabtexdescstat
#' @export
#' 
##@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
tabtexdescstat<-function(data,y,varnames,cap,nametab,
   save.file=FALSE,filename="tabdescdata.tex",
   rowlab="Variable",font.size.tab="normalsize",
   font.type.tab="normalfont", ...){

df<-data    
df.h<-data[,y]
    all.out<-descstat(df,y,all.outputs = TRUE, ...)
    class(all.out)
stat.names<-all.out$stat.names;stat.names
    tab.h <- all.out$table;tab.h
if(save.file==TRUE){    
fileNametex<-filename
}

rowlabel.h <-rowlab
labtab.h <- paste("tab:",nametab,sep = "")

if(save.file==TRUE){
l <-Hmisc::latex(tab.h,
 size=font.size.tab, cgroupTexCmd=font.type.tab,rowlabel=rowlabel.h, 
 file=fileNametex, col.just=rep("c",ncol(tab.h)),
 first.hline.double=FALSE,double.slash=FALSE,caption=cap,
 caption.loc="top",label=labtab.h,where="!h",...)}
    
    if(save.file==FALSE){
message("=======Start of the output=======")                
message("The following is the LaTeX output table","\n")        
Hmisc::latex(tab.h,file="",#table=FALSE,center=center,
 size=font.size.tab, cgroupTexCmd=font.type.tab,rowlabel=rowlabel.h, 
  col.just=rep("c",ncol(tab.h)),
 first.hline.double=FALSE,double.slash=FALSE,caption=cap,
 caption.loc="top",label=labtab.h,where="!h",...)        
message("=======End of the output=======","\n")                  
    }
}

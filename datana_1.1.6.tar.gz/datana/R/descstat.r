#' Function to create a descriptive statistics table for continuous
#'  variables from a dataframe.
#'
#' @details The resulting table offers the main central and dispersion
#' statistics.
#'
#' @title Creates a descriptive statistics table for continuous
#' variables.
#' @param data a dataframe containing numeric variables as columns.
#' @param y a string-vector with the name(s) of the random
#' variable(s) to which the descriptive statistics will be
#' computed. If not provided, all the numeric columns of the dataframe
#' will be used for computing the results.
#' @param factvar (optional) a string having de name of the variable
#' used as factor. Each level of the 'factvar` is a category.
#' @param decnum the number of decimals to be used in the output. The
#' default is set to 3.
#' @param eng logical; if `TRUE` (by default), the language of the
#' statistics will be in English; if "FALSE" will be in Spanish.
#' descriptive statistics. The default is to `FALSE`.
#' @param full logical; if `TRUE`, the output includes some extra
#' descriptive statistics. The default is to `FALSE`.
#' @param reduced logical; if `TRUE`, the output includes the same
#' descriptive statistics as using the summary() basis R function.
#' @param short.names logical; if `TRUE`, the names of the
#' computed statistics are in lower cases and are short compared to
#' the more formal ones. For instance, "sd" is used instead of
#' "Std. Dev.", furthermore, no space is used among letters.
#' The default is to `FALSE`.
#' @param all.outputs logical; if `TRUE`, the output is a list having
#' items with the output as a dataframe, as a table (better for
#' LaTeX), and other details. The default is to `FALSE`.
#' @param grouped.return It is a vector having both
#' 'stacked' and 'list'. By default is equal to `c("stacked", "list")`
#' @param landscape logical, by default is set to `FALSE`, if you
#' want the statistics as the columns of the printed output and the
#' variables as the rows, then set landscape to `TRUE`.
#' @param long.format logical, by default is set to `FALSE`, if you
#' are aiming to export the results to LaTeX, then set this option
#' to `TRUE`.
#' @param print.results logical, by default is set to `TRUE`, if you
#' do not want to see the results being printed, then set this option
#' to `FALSE`.
#' @param ... aditional options for basic stats functions.
#'
#' @return This function wraps descriptive statistics into a
#' summarize table having the following statistics: sample size,
#' minimum, maximum, mean, median, SD, and coefficient of variation.
#'  If the `full` option is set to `TRUE`, the following
#' statistics will be added to the table: 25th and 75th
#'   percentiles, the interquartile range, skewness, and kurtosis.
#' @author Christian Salas-Eljatib and Tomas Cayul and Nicolas Campos.
#' @references
#' - Salas-Eljatib C. 2021. Análisis de datos con el programa estadístico R:
#' una introducción aplicada. Ediciones Universidad Mayor. Santiago, Chile.
#' \url{https://eljatib.com}
#' @examples
#' df <- datana::idahohd
#' ##create a factor dbh.class
#' df <- datana::assigncl(data = df, variable = "dbh")
#' head(df)
#' ## using the function
#' descstat(data=df,y="dbh") #for the numeric variable 'dbh'
#' #+ if no 'y' is specified, all the numeric variables
#' ## are used for computing the results
#' descstat(data=df) #notice however, that numeric does not really mean
#'                   #actual "numeric variable"
#' ## exploring other parameters
#' descstat(data=df,y="dbh",decnum = 5,full=TRUE)
#' descstat(data=df,y="dbh",decnum = 5,full=TRUE,)
#' descstat(data=df,y="dbh",eng = FALSE)
#' descstat(data=df,y="dbh",eng = FALSE,landscape = TRUE)
#' #+ Now, for two numeric variables
#' descstat(data=df,y=c("dbh","toth"),eng = FALSE,full = TRUE,short.names = TRUE)
#' descstat(data=df,y=c("dbh","toth"),full = TRUE,short.names = TRUE)
#' ## exploring other parameters
#' descstat(df,y=c("dbh","toth"),decnum=1,eng=FALSE)
#' ##! same as before but in a landscape-orientation
#' descstat(df,y=c("dbh","toth"),landscape = TRUE)
#' ##* in case you want to export the output as a dataframe
#' outf<-descstat(df,y=c("dbh","toth"),decnum=1,eng=FALSE,all.outputs = TRUE)
#' outf
#' ##? the 'reduced' option
#' descstat(df,y=c("dbh","toth"),reduced=TRUE)
#' descstat(df,y=c("dbh","toth"),reduced=TRUE,eng=FALSE)
#' descstat(df,y=c("dbh","toth"), eng = TRUE, reduced = TRUE)
#' 
#' ##- trying with a factor
#' descstat(df,y=c("dbh","toth"), factvar = "spp")
#' descstat(df,y=c("dbh","toth"), factvar = "spp", eng = FALSE,full=TRUE)
#' ## trying with two factors
#' descstat(df,y=c("dbh","toth"), factvar = c("dbh.class","spp"))
#' ##! same as before but in a landscape view
#' descstat(df,y=c("dbh","toth"), factvar = c("dbh.class","spp"),landscape = TRUE)
#' 
#' ## in case you want to export the output as a dataframe
#' outf<- descstat(df,y=c("dbh","toth"), factvar = c("dbh.class","spp"),
#'                 all.outputs = TRUE)
#' outf$stat.cname
#' outf$var.names
#' head(outf$table,15)
#' head(outf$out.df,15)
#' ## If no factvar is considered, you might want
#' ## the statistics as columns, and the variables as rows
#' # if you want to do so, proceed as follows
#' descstat(data=df,y=c("dbh","toth"),eng = FALSE,landscape = TRUE)
#' 
#' @rdname descstat
#' @export
#'
##@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
descstat <- function(data, y=NULL, factvar = NA, decnum = 3, eng = TRUE, full = FALSE, 
                     reduced = FALSE, all.outputs = FALSE, 
                     short.names = FALSE, 
                     grouped.return = c("stacked", "list"),
                     long.format = FALSE,
                     print.results = TRUE,landscape = FALSE, 
                     ...) 
{
  grouped.return <- match.arg(grouped.return)
  data <- as.data.frame(data)
  
#  if (isTRUE(table.transpose)) {all.outputs<-TRUE}
  
  # ============================================================
  # LABELS
  # ============================================================
.get_labels <- function(eng = TRUE, short.names = FALSE, full = FALSE, reduced = FALSE) {
  
  if (full) reduced <- FALSE
  if (reduced) full <- FALSE
  
  if (eng) {
    stat.cname <- "Statistic"
    if (short.names) {
      base.names <- c("n", "min", "max", "mean", "median", "sd", "cv")
      extra.names <- c("25p", "75p", "iqr", "ske", "kurt")
      reduced.names <- c("min", "25p", "median", "75p", "max")
      # ADD missing labels for short.names
      stop.mess.a <- "No numeric variables found in the dataframe to summarize."
      stop.mess.b <- "No valid variables found in option 'y'."
      stop.mess.c <- "After excluding factvar columns, no variables remain in 'y'."
      head.title.single <- "Factor level"
      head.title.multi <- "Factors level combination"
    } else {
      base.names <- c("n", "Minimum", "Maximum", "Mean", "Median", "Std. Dev.", "CV(%)")
      extra.names <- c("25th Percentile", "75th Percentile", "Interq. range", "Skewness", "Kurtosis")
      reduced.names <- c("Minimum", "25th Percentile", "Median", "75th Percentile", "Maximum")
      stop.mess.a <- "No numeric variables found in the dataframe to summarize."
      stop.mess.b <- "No valid variables found in option 'y'."
      stop.mess.c <- "After excluding factvar columns, no variables remain in 'y'."
      head.title.single <- "Factor level"
      head.title.multi <- "Factors level combination"
    }  
  } else {
    stat.cname <- "Estad\u00edstico"
    
    if (short.names) {
      base.names <- c("n", "min", "max", "media", "mediana", "sd", "cv")
      extra.names <- c("per25", "per75", "riq", "ske", "kurt")
      reduced.names <- c("min", "per25", "mediana", "per75", "max")
      stop.mess.a <- "Ninguna variable num\u00e9rica en los datos para ser resumida."
      stop.mess.b <- "Ninguna variable valida se ha encontrado en la opci\u00f3n 'y'."
      stop.mess.c <- "Luego de excluir factvar, ninguna variable queda en y."
      head.title.single <- "Nivel del factor"
      head.title.multi <- "Combinaci\u00f3n de niveles de los factores"
    } else {
      base.names <- c("n", "M\u00ednimo","M\u00e1ximo", "Media", "Mediana", "Desv. St.", "CV(%)")
      extra.names <- c("Percentil 25", "Percentil 75", "Rango Interc.", "Asimetr\u00eda", "Curtosis")
      reduced.names <- c("M\u00ednimo", "Percentil 25", "Mediana", "Percentil 75", "M\u00e1ximo")
      stop.mess.a <- "Ninguna variable num\u00e9rica en los datos para ser resumida."
      stop.mess.b <- "Ninguna variable valida se ha encontrado en la opci\u00f3n 'y'."
      stop.mess.c <- "Luego de excluir factvar, ninguna variable queda en y."
      head.title.single <- "Nivel del factor"
      head.title.multi <- "Combinaci\u00f3n de niveles de los factores"
    }
  }

  stat.names <- if (full) {
    c(base.names, extra.names)
  } else if (reduced) {
    reduced.names
  } else {
    base.names
  }

  list(
    stat.names = stat.names,
    stat.cname = stat.cname,
    stop.mess.a = stop.mess.a,
    stop.mess.b = stop.mess.b,
    stop.mess.c = stop.mess.c,
    head.title.single = head.title.single,
    head.title.multi = head.title.multi
  )
}
  
  # ============================================================
  # WIDE -> LONG
  # ============================================================
  .to_long <- function(tab, group.info = NULL, landscape = FALSE, stat.cname = "Statistic") {
    tab <- as.data.frame(tab, check.names = FALSE)
    
    if (landscape == FALSE) {
      statnames <- row.names(tab)
      varnames <- names(tab)
      
      out <- expand.grid(
        Statistic = statnames,
        Variable = varnames,
        stringsAsFactors = FALSE
      )
      out$Value <- as.vector(as.matrix(tab))
      names(out)[1] <- stat.cname
      out <- out[, c("Variable", stat.cname, "Value"), drop = FALSE]
      
    } else {
      varnames <- row.names(tab)
      statnames <- names(tab)
      
      out <- expand.grid(
        Variable = varnames,
        Statistic = statnames,
        stringsAsFactors = FALSE
      )
      out$Value <- as.vector(as.matrix(tab))
      names(out)[2] <- stat.cname
      out <- out[, c("Variable", stat.cname, "Value"), drop = FALSE]
    }
    
    if (!is.null(group.info)) {
      for (nm in rev(names(group.info))) {
        out[[nm]] <- group.info[[nm]]
      }
      out <- out[, c(names(group.info), setdiff(names(out), names(group.info))), drop = FALSE]
    }
    
    row.names(out) <- NULL
    out
  }


full.local <- isTRUE(full)
reduced.local <- isTRUE(reduced)

labels <- .get_labels(
  eng = eng,
  short.names = short.names,
  full = full.local,
  reduced = reduced.local
)

stop.mess.a <- labels$stop.mess.a
stop.mess.b <- labels$stop.mess.b
stop.mess.c <- labels$stop.mess.c
head.title.single <- labels$head.title.single
head.title.multi <- labels$head.title.multi
  
  # ============================================================
  # ONE SUMMARY TABLE
  # ============================================================
.descstat_one <- function(dfy, labels) {
  dfy <- as.data.frame(dfy)
  
  is.num <- sapply(dfy, is.numeric)
  dfy <- dfy[, is.num, drop = FALSE]
  
  if (ncol(dfy) == 0) {
    stop(labels$stop.mess.a)  # ✅ use labels$stop.mess.a
  }

  stat.names <- labels$stat.names
  stat.cname <- labels$stat.cname
    
    n <- sapply(dfy, function(x) sum(!is.na(x)))
    Minimo <- sapply(dfy, function(x) if (all(is.na(x))) NA else min(x, na.rm = TRUE))
    Maximo <- sapply(dfy, function(x) if (all(is.na(x))) NA else max(x, na.rm = TRUE))
    Media <- sapply(dfy, function(x) if (all(is.na(x))) NA else mean(x, na.rm = TRUE))
    Mediana <- sapply(dfy, function(x) if (all(is.na(x))) NA else stats::median(x, na.rm = TRUE))
    Desv.Est. <- sapply(dfy, function(x) if (sum(!is.na(x)) <= 1) NA else stats::sd(x, na.rm = TRUE))
    CV <- abs(100 * Desv.Est. / Media)
    
    percentiles <- sapply(dfy, function(x) {
      if (all(is.na(x))) c(NA, NA)
      else stats::quantile(x, probs = c(0.25, 0.75), na.rm = TRUE, names = FALSE)
    })
    
    if (is.vector(percentiles)) {
      percentiles <- matrix(percentiles, nrow = 2)
      colnames(percentiles) <- names(dfy)
    }
    
    q1 <- percentiles[1, ]
    q3 <- percentiles[2, ]
    iqr <- sapply(dfy, function(x) if (all(is.na(x))) NA else stats::IQR(x, na.rm = TRUE))
    sk <- sapply(dfy, function(x) if (sum(!is.na(x)) <= 2) NA else datana::skewn(x, na.rm = TRUE))
    kurto <- sapply(dfy, function(x) if (sum(!is.na(x)) <= 3) NA else datana::kurto(x, na.rm = TRUE))
    
    if (full.local == TRUE) {
      outmat <- rbind(n, Minimo, Maximo, Media, Mediana, Desv.Est., CV,
                      q1, q3, iqr, sk, kurto)
    } else if (reduced.local == TRUE) {
      outmat <- rbind(Minimo, q1, Mediana, q3, Maximo)
    } else {
      outmat <- rbind(n, Minimo, Maximo, Media, Mediana, Desv.Est., CV)
    }
    
    var.names <- names(dfy)
    
    # canonical table (always same orientation)
    outab <- outmat
    row.names(outab) <- stat.names
    outab <- data.frame(outab, check.names = FALSE)
    names(outab) <- var.names
    outab <- round(outab, decnum)
    
    # user-facing output
    out.df <- outab
    if (landscape == TRUE) {
        out.df <- t(out.df)
        outab <- t(outab)
      if (nrow(out.df) == 1) {
        row.names(out.df) <- var.names
      }
    }


  
list(
      out.df = out.df,
      table = outab,
      stat.names = stat.names,
      var.names = var.names,
      stat.cname = stat.cname)
}



  # ============================================================
  # STACK DISPLAY OUTPUT
  # ============================================================
  .stack_display <- function(out.list, labels, landscape = FALSE, long.format = FALSE) {
    stacked <- do.call(rbind, lapply(out.list, function(x) {
      res <- x$result
      group.info <- x$group.info
      
      if (long.format == TRUE) {
        return(.to_long(res$out.df, group.info = group.info, landscape = landscape, stat.cname = res$stat.cname))
      }
      
      tab <- as.data.frame(res$out.df, check.names = FALSE)
      
      if (landscape == TRUE) {
        tab$Variable <- row.names(tab)
        row.names(tab) <- NULL
        tab <- tab[, c("Variable", setdiff(names(tab), "Variable")), drop = FALSE]
      } else {
        tab[[labels$stat.cname]] <- row.names(tab)
        row.names(tab) <- NULL
        tab <- tab[, c(labels$stat.cname, setdiff(names(tab), labels$stat.cname)), drop = FALSE]
      }
      
      for (nm in rev(names(group.info))) {
        tab[[nm]] <- group.info[[nm]]
      }
      tab <- tab[, c(names(group.info), setdiff(names(tab), names(group.info))), drop = FALSE]
      tab
    }))
    
    row.names(stacked) <- NULL
    stacked
  }
  
  # ============================================================
  # STACK CANONICAL TABLES (LATEX-FRIENDLY)
  # ============================================================
  .stack_canonical_tables <- function(out.list, stat.cname = "Statistic") {
    outtab.all <- do.call(rbind, lapply(out.list, function(x) {
      tab <- x$result$table
      group.info <- x$group.info
      
      tab <- as.data.frame(tab, check.names = FALSE)
      tab[[stat.cname]] <- row.names(tab)
      row.names(tab) <- NULL
      tab <- tab[, c(stat.cname, setdiff(names(tab), stat.cname)), drop = FALSE]
      
      for (nm in rev(names(group.info))) {
        tab[[nm]] <- as.character(group.info[[nm]])
      }
      tab <- tab[, c(names(group.info), setdiff(names(tab), names(group.info))), drop = FALSE]
      tab
    }))
    
    row.names(outtab.all) <- NULL
    outtab.all
  }
  
  # ============================================================
  # RESOLVE factvar
  # ============================================================
  if (!(length(factvar) == 1 && is.na(factvar))) {
    if (is.numeric(factvar)) {
      factvar_names <- names(data)[factvar]
    } else {
      factvar_names <- factvar
    }
    factvar_names <- intersect(factvar_names, names(data))
  } else {
    factvar_names <- character(0)
  }
  
  # ============================================================
  # RESOLVE y
  # ============================================================
  if (is.null(y)) {
    numeric_vars <- names(data)[sapply(data, is.numeric)]
    y_names <- setdiff(numeric_vars, factvar_names)
    
    if (length(y_names) == 0) {
       #stop("No numeric variables available to summarize.")
       stop(labels$stop.mess.a)
    }
  } else {
    if (is.numeric(y)) {
      y_names <- names(data)[y]
    } else {
      y_names <- y
    }
    
    y_names <- intersect(y_names, names(data))
    
    if (length(y_names) == 0) {
        #stop("No valid variables found in 'y'.")
        stop(stop.mess.b)
    }
    
    y_names <- setdiff(y_names, factvar_names)
    
    if (length(y_names) == 0) {
        #stop("After excluding factvar columns, no variables remain in 'y'.")
        stop(stop.mess.c)
    }
  }
  
  dfy <- as.data.frame(data[, y_names, drop = FALSE])
  
#  labels <- .get_labels(eng = eng, short.names = short.names, full = full, reduced = reduced)
  
  # ============================================================
  # CASE 1: NO GROUPING
  # ============================================================
if (length(factvar_names) == 0) {
#  res <- .descstat_one(dfy)
    res <- .descstat_one(dfy, labels = labels)
    
  if (long.format == TRUE) {
    res$out.df <- .to_long(res$out.df, group.info = NULL, landscape = landscape, stat.cname = res$stat.cname)
  }
  
  # optional transpose ONLY for ungrouped canonical table
  out_table <- res$table
  ## if (isTRUE(table.transpose)) {
  ##   out_table <- t(out_table)
  ##   out_table <- data.frame(out_table, check.names = FALSE)
  ## }

  # ✅ PRINT (this fixes your issue)
  if (isTRUE(print.results)) {
    cat("\n")
    print(res$out.df)
  }

  # ✅ RETURN (unchanged logic)
  if (all.outputs == TRUE) {
    if (isTRUE(print.results)) {
      return(invisible(list(
        out.df = res$out.df,
        table = out_table,
        stat.names = res$stat.names,
        var.names = res$var.names,
        stat.cname = res$stat.cname
      )))
    } else {
      return(list(
        out.df = res$out.df,
        table = out_table,
        stat.names = res$stat.names,
        var.names = res$var.names,
        stat.cname = res$stat.cname
      ))
    }
  } else {
    if (isTRUE(print.results)) {
      return(invisible(res$out.df))
    } else {
      return(res$out.df)
    }
  }
}
  
  # ============================================================
  # CASE 2: GROUPED DESCRIPTIVES
  # ============================================================
  group.df <- data[, factvar_names, drop = FALSE]
  group.df[] <- lapply(group.df, as.factor)
  
  split.index <- interaction(group.df, drop = TRUE, sep = " | ")
  split.data <- split(seq_len(nrow(data)), split.index, drop = TRUE)
  
  out.list <- lapply(split.data, function(idx) {
    subdf <- dfy[idx, , drop = FALSE]
    
    # store ACTUAL factor labels, not numeric codes
    group.info <- as.data.frame(
      lapply(group.df[idx[1], , drop = FALSE], as.character),
      stringsAsFactors = FALSE
    )
    
    list(
      result = .descstat_one(subdf,labels=labels),
      group.info = group.info
    )
  })
  
  # ------------------------------------------------------------
  # PRINT nicely by default
  # ------------------------------------------------------------
  if (isTRUE(print.results)) {
    cat("\n")

    if (length(factvar_names) == 1) {
      header_title <- head.title.single#"Factor level"
    } else {
      header_title <- head.title.multi#"Factors level combination"
    }
    
    for (i in seq_along(out.list)) {
      group.info <- out.list[[i]]$group.info
      res <- out.list[[i]]$result$out.df
      
      cat(rep("=", 70), sep = "", "\n")
      cat(header_title, ": ", sep = "")
      cat(paste(paste(names(group.info), group.info[1, ], sep = " = "), collapse = " & "))
      cat("\n")
      cat(rep("-", 70), sep = "", "\n")
      print(res)
      cat("\n")
    }
  }
  
  # ------------------------------------------------------------
  # grouped.return = "list"
  # ------------------------------------------------------------
  if (grouped.return == "list") {
    final.list <- lapply(out.list, function(x) {
      res <- x$result
      group.info <- x$group.info
      
      if (long.format == TRUE) {
        res$out.df <- .to_long(res$out.df, group.info = group.info, landscape = landscape, stat.cname = res$stat.cname)
      }
      
      if (all.outputs == TRUE) {
        return(list(
          out.df = res$out.df,
          table = res$table,
          stat.names = res$stat.names,
          var.names = res$var.names,
          stat.cname = res$stat.cname
        ))
      } else {
          return(res$out.df)          
      }
    })
    
    names(final.list) <- names(out.list)
    return(final.list)
  }
  
  # ------------------------------------------------------------
  # grouped.return = "stacked"
  # ------------------------------------------------------------
  out.df.all <- .stack_display(out.list, labels, landscape = landscape, long.format = long.format)
  full.group.table <- .stack_canonical_tables(out.list, stat.cname = labels$stat.cname)

if (all.outputs == TRUE) {
  if (isTRUE(print.results)) {
    return(invisible(list(
      out.df = out.df.all,
      table = full.group.table,
      stat.names = out.list[[1]]$result$stat.names,
      var.names = out.list[[1]]$result$var.names,
      stat.cname= out.list[[1]]$result$stat.cname
    )))
  } else {
    return(list(
      out.df = out.df.all,
      table = full.group.table,
      stat.names = out.list[[1]]$result$stat.names,
      var.names = out.list[[1]]$result$var.names,
      stat.cname= out.list[[1]]$result$stat.cname      
    ))
  }
} else {
  if (isTRUE(print.results)) {
    return(invisible(out.df.all))
  } else {
    return(out.df.all)
  }
}
  
}

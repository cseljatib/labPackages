#' Linear interpolation function
#'
#' @details Function that interpolates via linear interpolation. This
#' function is used by datana::interp.
#' 
#' @param data data.frame to interpolate on. It has to have two
#' columns and just one NA value
#'
#' @author Christian Salas-Eljatib and Nicolás Campos
#'
#' @examples
#' x <- c(40, 30, 20, 10, 0)
#' y <- c(0, 5, 10, NA, 20)
#' df <- data.frame(x, y)
#' df
#' interp.l(df)
#'
#' @rdname interp
#' @export
######################################################################
interp.l <- function(data) {
    if (ncol(data) != 2) {
        stop("provide 2 columns")
    }

    if ((dim(data) - dim(stats::na.omit(data)))[1] != 1) {
        stop("the data must contain only 1 NA value")
    }
    ## search for the colum which has NA
    filas1 <- length(stats::na.omit(data[, 1]))
    filas2 <- length(stats::na.omit(data[, 2]))

    if (filas1 > filas2) {
        corden <- 1
        cna <- 2
    } else if (filas1 < filas2) {
        corden <- 2
        cna <- 1
    }

    ## order de data based on the values of the non-NA colum
    df.h <- data[order(-data[, corden]), ]

    ## identify the index of the NA row
    naindex <- which(is.na(df.h[, cna]))

    ## perform the interpolation
    ## y2 = y1 + (x2 - x1) * (y3 - y1) / (x3 - x1)
    x1 <- df.h[naindex - 1, corden]
    x2 <- df.h[naindex, corden]
    x3 <- df.h[naindex + 1, corden]
    y1 <- df.h[naindex - 1, cna]
    y3 <- df.h[naindex + 1, cna]

    newvalue <- y1 + (x2 - x1) * (y3 - y1) / (x3 - x1)

    ## replace NA with the value calculated
    df.h[naindex, cna] <- newvalue

    ## return the interpolated dataframe and value
    list(newdata = df.h,
         newvalue = newvalue)
}

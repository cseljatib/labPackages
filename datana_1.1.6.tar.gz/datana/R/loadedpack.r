#' Function to list all the packages of an R
#' session, and their respective versions.
#'
#' @details It is specially set to data management.
#' 
#' @title List loaded packages
#'
#' @return This function returns a list.
#' @author Christian Salas-Eljatib
#' @references
#' Salas-Eljatib, C. 2021. Análisis de datos con el programa
#' estadístico R: una introducción
#'  aplicada. Ediciones Universidad Mayor, Santiago, Chile. 170 p. 
#'  \url{https://eljatib.com/rlibro}
#' @examples 
#'
#' plot.id <- c("BNE1","BNE2","PLE1")
#' loadedpack()
#' @rdname loadedpack
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
loadedpack <- function(){
  version=c()
  list.loaded.pack=(.packages()) 
  for(i in 1:length(list.loaded.pack)){
    pack.p=list.loaded.pack[i] 
    version.p=utils::packageDescription(list.loaded.pack[i])$Version
    paso=c(pack.p,version.p)
    version=rbind(version,paso)
  }
  version=data.frame(version,row.names=NULL)
  names(version)=c('Package','Version')
  cat("List of all loaded packages and their versions",'\n')
  cat("----------------------------------------------",'\n')
  version
}

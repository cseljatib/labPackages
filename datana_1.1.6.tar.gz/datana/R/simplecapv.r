#' @noRd
simplecapv <- function(x) {
	Vectorize(x)
}
##' ### x is the simplecap function

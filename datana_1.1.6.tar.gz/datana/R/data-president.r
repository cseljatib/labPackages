#' Elección presidencial del 2021 en Chile.
#' @description
#' Datos de cada mesa en la segunda vuelta presidencial en Chile. La elección
#' se llevó a cabo el 19 de Diciembre del 2021.
#' @usage
#' data(president)
#' @format Los datos contienen las siguientes columnas:
#' \describe{
#'   \item{region.no}{Número de la región adminsitrativa de Chile.}
#'   \item{region}{Nombre de la región administrativa de Chile}
#'   \item{provincia}{Nombre  de la Provincia.}
#'   \item{circu.senatorial}{Circunscripción senatorial.}
#'   \item{distrito}{Número de Distrito.}
#'   \item{comuna}{Nombre de la Comuna.}
#'   \item{circu.elec}{Nombre de la Circunscripción electoral.}
#'   \item{local}{Local de votación. Generalmente es un colegio.}
#'   \item{no.mesa}{Número de mesa.}
#'   \item{tipo.mesa}{Tipo de mesa de votación.}
#'   \item{mesas.fusionadas}{Mesa de votación fusionada.}
#'   \item{electores}{Número de personas habilitadas para sufragar. La
#' totalidad de ellos conforma el padrón electoral.}
#'   \item{nro.en.voto}{Opción de voto en la papeleta (`1` = `GABRIEL
#' BORIC FONT`, `2` = `JOSE ANTONIO KAST RIST`, `NA` = `NULO` o `BLANCO`)}
#'   \item{candidato}{Una de cuatro opciones: Candidato (`GABRIEL
#' BORIC FONT` o `JOSE ANTONIO KAST RIST`), o tipo de voto (`VOTOS EN
#' BLANCO` o `VOTOS NULOS`)}
#'   \item{votos.tricel}{Número total de votos según el TRICEL (Tribunal
#'   Calificador de Elecciones).}
#'  }
#' @source
#' Los datos fueron obtenidos desde el sitio web del Servicio Electoral del
#'  Gobierno de Chile (SERVEL) en \url{https://www.servel.cl/2021/09/22/servel-publico-padrones-electorales-definitivos-para-chile-y-el-extranjero-y-nomina-de-inhabilitados/}.
#'  El archivo de datos descargado el 24 de Octubre del 2022
#' corresponde a
#'   `Resultados mesa presidencial TRICEL 2v 2021-1.xlsx`.
#' @examples
#' data(president)
#' head(president)
'president'

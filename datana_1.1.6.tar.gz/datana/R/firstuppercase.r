#' @noRd
first.uppercase<-function(name){
paste0(toupper(substr(name, 1, 1)), substr(name, 2, nchar(name)))
}

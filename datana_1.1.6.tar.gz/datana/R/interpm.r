#' Linear model interpolation function
#'
#' @details Function that interpolates via fitting a linear model to
#' the data. This function is used by datana::interp when `spline`
#' interpolation fails.
#'
#' @param data data.frame to interpolate on. It has to have two
#' columns and just one NA value
#'
#' @author Christian Salas-Eljatib and Nicolás Campos
#'
#' @examples
#' x <- c(40, 30, 20, 10, 0)
#' y <- c(0, 5, 10, NA, 20)
#' df <- data.frame(x, y)
#' interp.m(df)
#'
#' @rdname interp
#' @export
######################################################################
interp.m <- function(data) {
    if (ncol(data) != 2) {
        stop("provide 2 columns")
    }

    if ((dim(data) - dim(stats::na.omit(data)))[1] != 1) {
        stop("the data must contain only 1 NA value")
    }
    ## search for the colum which has NA
    filas1 <- length(stats::na.omit(data[, 1]))
    filas2 <- length(stats::na.omit(data[, 2]))

    if (filas1 > filas2) {
        corden <- 1
        cna <- 2
    } else if (filas1 < filas2) {
        corden <- 2
        cna <- 1
    }

    ## order de data based on the values of the non-NA colum
    df.h <- data[order(-data[, corden]), ]

    ## identify the index of the NA row
    naindex <- which(is.na(df.h[, cna]))

    ## perform the interpolation
    ## fitting a linear model
    mod.h <- stats::lm(df.h[, cna] ~ df.h[, corden])
    b0 <- stats::coef(mod.h)[1]
    b1 <- stats::coef(mod.h)[2]
    newvalue <- b0 + b1 * df.h[naindex, corden] ## predict doesn't work
    names(newvalue) <- NULL

    ## replace NA with the value calculated
    df.h[naindex, cna] <- newvalue

    ## return the interpolated dataframe and value
    list(newdata = df.h,
         newvalue = newvalue)
}

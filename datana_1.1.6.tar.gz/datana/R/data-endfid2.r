#' Puntaje ENDFID 2021 por carrera
#'
#' @description
#' Puntaje promedio por carrera de la Evaluación Nacional Diagnóstica de la 
#' Formación Inicial Docente (ENDFID), enfocado en matemática. Se tienen 79 observaciones.
#' Se incluyen dos variables binarias: `cuech` (pertenece `1` o no `0` al CUECH) y `pace` (tiene cupos PACE `1` o no `0`). 
#' @usage
#' data(endfid2)
#' @format Variables se describen a continuación:
#' \describe{
#' \item{prog}{Nombre de la carrera dictada}
#' \item{uni}{Universidad correspondiente al programa}
#' \item{zona}{Ubicación de la sede de la carrera}
#' \item{region}{Región de la sede de la carrera}
#' \item{prog}{Tipo de carrera (1 Ped. En Matemáticas, 
#' 2 Enseñanza General Básica, 3 Programa formación pedagógica)}
#' \item{cuech}{Universidad pertenece al Consejo de Universidades del Estado (1 si, 0 no)}
#' \item{pace}{Carrera incluye cupos PACE (1 si, 0 no). El PACE es el
#' Programa de Acompañamiento y Acceso Efectivo a la Educación
#' Superior del Ministerio de Educación de Chile, que busca permitir
#' el acceso a la educación superior por parte de estudiantes de
#' enseñanza media provenientes de establecimientos educacionales
#' públicos.}
#' \item{pcpg}{Puntaje promedio de la carrera en la Prueba de Conocimientos Pedagógicos Generales}
#' \item{pcdd}{Puntaje promedio de la carrera en la Prueba de Conocimientos Disciplinarios y Didácticos}
#' \item{matri}{Cantidad de estudiantes matriculados en la carrera el 2022}
#'  }
#' @source
#' Datos obtenidos desde el Centro de Perfeccionamiento, Experimentación 
#' e Investigaciones Pedagógicas (CPEIP) del Mineduc y desde los
#' sitios web respectivo de cada universidad. Los datos fueron
#' digitados por Diego Fernández, estudiante del Prof. Christian
#' Salas-Eljatib en el Magíster en Políticas Públicas de la
#' Universidad de Chile.
#'
#' Mayores antecedentes sobre la Evaluación Nacional Diagnóstica
#' de la Formación Inicial Docente del Ministerio de Chile pueden ser
#' revisados en \url{https://www.diagnosticafid.cl/}
#' 
#' @examples
#' data(endfid2)
#' df<-endfid2
#' head(df)
#' table(df$zona,df$cuech)
#' boxplot(pcdd~cuech, data=df)
#' boxplot(pcdd~cuech, data=df, xlab = "Universidad",las=1,
#' names = c("No del CUECH", "Pertenece al CUECH"))
'endfid2'

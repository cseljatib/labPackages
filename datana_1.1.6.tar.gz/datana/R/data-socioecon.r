#' Socio-economic indicators for a common year — (poverty/social-spending/inequality)
#'
#' @description
#' Cross-sectional dataset for 40 countries, all observed in 2016. The
#' reference year was chosen from 2016--2022 as the one maximizing
#' the number of countries with simultaneous non-missing values
#' for \code{gini}, \code{poverty} and \code{socspend}. Only countries
#' complete in those three variables are included. For a wider country
#' coverage see \code{socioeconw}.
#' 
#' @usage
#' data(socioecon)
#'
#' @format A data frame with 40 rows and 28 variables:
#' \describe{
#'   \item{iso3}{ISO 3166-1 alpha-3 country code (3-letter identifier).}
#'   \item{country}{Country name in English.}
#'   \item{cont}{Continent name derived from the ISO3 code via the \code{countrycode} package. One of: Africa, Americas, Asia, Europe, Oceania.}
#'   \item{region}{World Bank geographic region (e.g., 'Latin America & Caribbean', 'Sub-Saharan Africa').}
#'   \item{income}{World Bank income group: 'High income', 'Upper middle income', 'Lower middle income', or 'Low income'.}
#'   \item{oecd}{Logical. \code{TRUE} if the country is an OECD member (38 members as of 2024).}
#'   \item{refyear}{Reference year from which all variables for this country are drawn.}
#'   \item{poverty}{Population living below the international poverty line of USD 2.15/day (2017 PPP), as a percentage of total population. Source: World Bank SI.POV.DDAY.}
#'   \item{gini}{Gini index of income or consumption inequality, scaled 0--100 (0 = perfect equality, 100 = perfect inequality). Source: World Bank SI.POV.GINI.}
#'   \item{homicide}{Intentional homicide rate per 100,000 inhabitants per year. Source: UNODC via World Bank VC.IHR.PSRC.P5.}
#'   \item{gdp}{Gross Domestic Product in current US dollars. Source: World Bank NY.GDP.MKTP.CD.}
#'   \item{gdpppp}{GDP per capita based on purchasing power parity (PPP) in current international dollars. Source: World Bank NY.GDP.PCAP.PP.CD.}
#'   \item{gni}{Gross National Income per capita (Atlas method) in current US dollars. Source: World Bank NY.GNP.PCAP.CD.}
#'   \item{inflation}{Annual inflation rate based on the Consumer Price Index, in percent. Source: World Bank FP.CPI.TOTL.ZG.}
#'   \item{unemp}{Unemployment as a percentage of the total labour force (ILO modelled estimate). Source: World Bank SL.UEM.TOTL.ZS.}
#'   \item{exports}{Exports of goods and services as a percentage of GDP. Source: World Bank NE.EXP.GNFS.ZS.}
#'   \item{pop}{Total population (de facto, all residents). Source: World Bank SP.POP.TOTL.}
#'   \item{popf}{Total female population. Source: World Bank SP.POP.TOTL.FE.IN.}
#'   \item{popm}{Total male population. Source: World Bank SP.POP.TOTL.MA.IN.}
#'   \item{fertility}{Total fertility rate: average number of children per woman under current age-specific rates. Source: World Bank SP.DYN.TFRT.IN.}
#'   \item{deaths}{Crude death rate per 1,000 inhabitants per year. Source: World Bank SP.DYN.CDRT.IN.}
#'   \item{infmort}{Infant mortality rate: deaths under age 1 per 1,000 live births. Source: World Bank SP.DYN.IMRT.IN.}
#'   \item{lifeexp}{Life expectancy at birth in years (both sexes). Source: World Bank SP.DYN.LE00.IN.}
#'   \item{density}{Population density: people per square kilometre of land area. Source: World Bank EN.POP.DNST.}
#'   \item{urban}{Urban population as a percentage of total population. Source: World Bank SP.URB.TOTL.IN.ZS.}
#'   \item{area}{Total surface area in square kilometres (including inland water bodies). Source: World Bank AG.SRF.TOTL.K2.}
#'   \item{landarea}{Land area in square kilometres (excluding inland water bodies). Source: World Bank AG.LND.TOTL.K2.}
#'   \item{socspend}{Public social expenditure as a percentage of GDP, covering old-age, health, family, unemployment, housing and other social programmes. Source: OECD SOCX via Our World in Data.}
#' }
#'
#' @source
#' World Bank World Development Indicators via the \code{wbstats} R package;
#' OECD Social Expenditure Database (SOCX) via Our World in Data
#' (\url{https://ourworldindata.org/grapher/social-spending-oecd-longrun});
#' country metadata via the \code{countrycode} R package.
#'
#' @references
#' World Bank (2024). World Development Indicators.
#' \url{https://databank.worldbank.org/source/world-development-indicators}
#'
#' OECD (2024). Social Expenditure Database (SOCX).
#' \url{https://www.oecd.org/en/data/datasets/social-expenditure-database-socx.html}
#'
#' Arel-Bundock V, Enevoldsen N, Yetman C (2018). countrycode: An R package
#' to convert country names and country codes. Journal of Open Source Software,
#' 3(28), 848. \doi{https://doi.org/10.21105/joss.00848}
#'
#' @examples
#' library(datana)
#' data(socioecon)
#' df<-socioecon
#' head(df)
#' plot(gini ~ socspend, data = df,
#'      xlab = 'Social spending (% GDP)', ylab = 'Gini index')
'socioecon'

# This is a handy function for looking for trends in residuals etc.
mywhiskers2<-function(x,y,nclass=10,limits=NA,add=FALSE,
      se=TRUE,main="",xlab="x",ylab="y",ylim=NA,lwd=1) {
            away<-is.na(x+y)
            x<-x[!away]
            y<-y[!away]
  if (is.na(limits[1])) limits<-seq(min(x),max(x)+1e-10,length=nclass+1) else nclass=length(limits)-1
 means<-sapply(1:nclass,function(i) mean(y[x>=limits[i]&x<limits[i+1]]))
 if (se){ses<-sapply(1:nclass,function(i) stats::sd(y[x>=limits[i]&x<limits[i+1]])/
                                                         sqrt(sum(x>=limits[i]&x<limits[i+1])))
        } else {
  ses<-sapply(1:nclass,function(i) stats::sd(y[x>=limits[i]&x<limits[i+1]]))
              }
            lb<-means-ses
            ub<-means+ses
            xclass<-1/2*(limits[-1]+limits[-nclass-1])
            if (add) {
               graphics::points(xclass,means) 
               } else {
               if(is.na(ylim[1])) ylim<-c(min(lb),max(ub))
               plot(xclass,means,ylim=ylim,main=main,xlab=xlab,ylab=ylab,xlim=range(x))
               }
            sapply(1:nclass,function(i) graphics::lines(xclass[c(i,i)],c(lb[i],ub[i]),lwd=lwd))
}

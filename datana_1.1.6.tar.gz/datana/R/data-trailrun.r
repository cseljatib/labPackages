#' Record times in Scottish hill races
#' @description The record times in 1984 for 35 Scottish hill races.
#' @format Data frame of 35 rows and 3 columns:
#' \describe{
#' \item{dist}{Distance in kilometeres}
#' \item{climb}{Total height gained during the route, in meters}
#' \item{time}{Record time in minutes}
#' }
#' @source
#' A.C. Atkinson (1986) Comment: Aspects of diagnostic regression
#' analysis. _Statistical Science_ **1**, 397-402.
#'
#' \[A.C. Atkinson (1988) Transformations unmasked. _Technometrics_
#' **30**, 311-318 “corrects” the time for Knock Hill from 78.65 to
#' 18.65. It is unclear if this based on the original records.\]
#'
#' @references
#' Venables, W. N. and Ripley, B. D. (2002) _Modern Applied Statistics
#' with S._ Fourth edition.  Springer.
#'
#' @examples
#' data(trailrun)
#' plot(time~dist, data = trailrun)
#' plot(time~climb, data = trailrun)
"trailrun"

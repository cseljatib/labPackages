#' @noRd
revisascripts <- function(ruta = "./", long = FALSE, force = FALSE,
                          evitar = ifelse(!is.null(getOption("revisa.env")),
                                          getOption("revisa.env")$last.run,
                                          "revisascripts.r")) {
    ## variables hack
    status <- NULL
    ## si se fuerza, corre todos los scripts (excepto este), si no se
    ## fuerza, evita los que salieron ok antes (last.run)
    if (force) {
        evitar <- "revisascripts.r"
    } else if (!is.null(getOption("revisa.env"))) {
        evitar <- getOption("revisa.env")$last.run
    }
    ## listado de archivos a revisar
    archivos.r <- list.files(path = ruta, pattern = "\\.[Rr]$")
    archivos.r <- archivos.r[!archivos.r %in% evitar]
    archivos.r <- paste0(ruta, archivos.r)
    archivos.r

    ## resultados
    resultados <- data.frame(file = basename(archivos.r),
                             status = character(length(archivos.r)),
                             message = character(length(archivos.r)),
                             stringsAsFactors = FALSE)

    for (i in seq_along(archivos.r)) {
        archivo.h <- archivos.r[i]
        message(sprintf("[%d/%d] Corriendo %s", i,
                        length(archivos.r),
                        basename(archivo.h)))
        output <- tryCatch({
            withCallingHandlers({
                ## funcion que corre el script en un proceso aparte de R
                callr::r(func = function(script) {
                    sys.source(file = script,
                               envir = globalenv())
                }, args = list(script = archivo.h))
                list(ok = TRUE, msg = "OK")
            }, warning = function(w) {
                invokeRestart("muffleWarning")
            })
           
        }, error = function(e) {
            ## en caso de error se cambio el estado del script
            ## list(ok = FALSE, msg = gsub(".*!\\\033\\[39m", "", conditionMessage(e)))
            list(ok = FALSE, msg = gsub(".*:\\\n!", "", conditionMessage(e)))
        })
        ## Se guardan los resultados
        if (output$ok) {
            resultados$status[i] <- "OK"
            resultados$message[i] <- ""
            message("  -> OK")
        } else {
            resultados$status[i] <- "ERROR"
            resultados$message[i] <- output$msg
            message(sprintf("  -> ERROR: %s", output$msg))
        }
    }

    cat("\nResumen:\n")
    if (!long) {
        resume <- function(string) {
            n <- nchar(string)
            if (n < 70) {
                corto <- string
            } else {
                corto <- substr(string, n - 70, n)
                paste0("...", corto)
            }
        }
        resultados$message <- sapply(resultados$message, resume)
    }
    ## nuevo entorno para dejar los resultados
    revisa.env <- new.env(parent = emptyenv())
    print(resultados, row.names = FALSE)
    assign("resultados", resultados, envir = revisa.env)
    assign("last.run", subset(resultados, status == "OK")$file, envir = revisa.env)
    revisa.env$last.run <- c(revisa.env$last.run, evitar)
    options(revisa.env = revisa.env)
}

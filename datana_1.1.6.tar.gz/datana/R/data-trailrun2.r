#' Tiempo récord en carreras de montaña en Escocia
#' @description Tiempo récord en 1984 para 35 carreras de montaña en Escocia.
#' @format Data frame con 35 filas y 3 columnas:
#' \describe{
#' \item{dist}{Distancia en kilómetros}
#' \item{ascenso}{Altura total ganada durante la carrera, en metros}
#' \item{tiempo}{Tiempo récord, en minutos}
#' }
#' @source
#' A.C. Atkinson (1986) Comment: Aspects of diagnostic regression
#' analysis. _Statistical Science_ **1**, 397-402.
#'
#' \[A.C. Atkinson (1988) Transformations unmasked. _Technometrics_
#' **30**, 311-318 “corrects” the time for Knock Hill from 78.65 to
#' 18.65. It is unclear if this based on the original records.\]
#'
#' @references
#' Venables, W. N. and Ripley, B. D. (2002) _Modern Applied Statistics
#' with S._ Fourth edition.  Springer.
#'
#' @examples
#' data(trailrun2)
#' plot(tiempo~dist, data = trailrun2)
#' plot(tiempo~ascenso, data = trailrun2)
"trailrun2"

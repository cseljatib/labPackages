#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom graphics par
#' @importFrom Hmisc latex
#' @importFrom methods is
#' @importFrom stats anova
## usethis namespace: end
NULL

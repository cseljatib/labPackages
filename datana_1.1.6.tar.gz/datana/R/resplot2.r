resplot2<-function(x,res,limits=NA,ylim=range(res),
    xlab="x",ylab="res",main="") {
    plot(x,res,col="gray",ylim=ylim,xlab=xlab,ylab=ylab,main=main)
    mywhiskers(x,res,add=TRUE,lwd=5,limits=limits)
    graphics::abline(0,0)
    mywhiskers2(x,res,se=FALSE,add=TRUE,limits=limits)   
}

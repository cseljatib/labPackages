#' The function creates a scatterplot with a superposing smoothed 
#' line as a way to reveal any potential pattern between the
#' variables.
#'
#' @details Notice that the smoothed-line is derived from a rather
#' standard algorithm (i.e., loess), implemented in the function
#' `smoothfit`, thus it is only an approximation.
#'
#' The function accepts two interfaces, just like [graphics::plot()]:
#' (i) vectors, e.g. `plotrend(x = df$varx, y = df$vary)`; and
#' (ii) a formula, e.g. `plotrend(vary ~ varx, data = df)`.
#'
#' When `factvar` is given (as a factor vector, as the name of a
#' column in `data`, or as `| factvar` inside the formula), the graph
#' becomes a [lattice::xyplot()] with one panel per level of the
#' factor, `vary ~ varx | factvar`, and each panel gets its own
#' loess smooth (the lattice counterpart of `smoothfit`).
#'
#' Commonly used graphical parameters are:
#' `col` The colors for lines and points. Multiple colors can be specified so that each point can be given its own color. If there are fewer colors than points they are recycled in the standard fashion. Lines will all be plotted in the first colour specified.
#' `bg` a vector of background colors for open plot symbols, see points. Note: this is not the same setting as par("bg").
#' `pch` a vector of plotting characters or symbols: see points.
#' `cex` a numerical vector giving the amount by which plotting characters or symbols should be scaled relative to the default.
#' This works as a multiple of par("cex"). NULL and NA are
#' equivalent to 1.0. Note that this does not
#' affect annotation: see below.
#' `lty` a vector of line types, see `par`.
#' `cex.main`, `col.lab`, `font.sub`, etc settings for main- and sub-title and axis annotation, see title and `par`.
#' `lwd` a vector of line widths, see `par`.
#' @title Function for building a scatterplot with a superposing
#' smoothed line
#'
#' @param x A numeric vector representing the X-axis variable; or a
#' formula of the form `y ~ x` (as in `plot`), optionally
#' `y ~ x | factvar` (as in `xyplot`).
#' @param y A numeric vector representing the Y-axis variable
#' (response). It is ignored when `x` is a formula.
#' @param data (optional) A data frame containing the variables of
#' the formula, as in `plot(y ~ x, data = df)`.
#' @param factvar (optional) A factor (or vector coerced to factor) to
#' split the graph by: either the vector itself, or the name of a
#' column in `data`. When given, an `xyplot(vary ~ varx | factvar,
#' data = df)` with a loess smooth per panel is drawn.
#' @param col A string specifying the color of the data points. The
#' default is "black".
#' @param linecol A string specifying the smooth line color. The
#' default is set to "red".
#' @param lwd the width of the smooth line to be drawn. The
#' default is set to `2`.
#' @param ylab (optional) A string specifying Y-axis label.
#' @param xlab (optional) A string specifying X-axis label.
#' @param ... other graphical parameters (see par and
#' section 'Details' below).
#' @references
#' - Salas-Eljatib C. 2021. Análisis de datos con el programa
#' estadístico R:
#' una introducción aplicada.
#' Ediciones Universidad Mayor. Santiago, Chile. 170 p.
#'  \url{https://eljatib.com}
#' @references
#' - Salas C, Stage AR, and Robinson AP. 2008. Modeling effects of
#' overstory density and competing
#' vegetation on tree height growth. Forest Science 54(1):107-122.
#'  \doi{10.1093/forestscience/54.1.107}
#' @return The function returns the above described graph. When
#' `factvar` is used, the `lattice` object is returned (and printed),
#' exactly as `xyplot` does.
#' @author Christian Salas-Eljatib
#' @examples
#' df <- datana::maple
#' head(df)
#' m1<-lm(leaf~dbh,data=df)
#' # Example 1, a residual plot (vectors, as usual)
#' plotrend(x=df$dbh,y=residuals(m1))
#' abline(h=0)
#' # Example 2, the formula interface, as in plot(leaf~dbh, data=df)
#' plotrend(leaf ~ dbh, data = df)
#' # Example 3, split by a factor: one panel per level, each with
#' # its own smooth fit (an xyplot alike)
#' plotrend(Petal.Length ~ Sepal.Length | Species, data = iris)
#' @rdname plotrend
#' @export
#' 
##+===========================================================
plotrend<-function(x, y=NULL, data=NULL, factvar=NULL,
                   col="black",linecol="red",lwd=2,
                   xlab=NULL, ylab=NULL,
                   ...){
  x.expr <- substitute(x)
  y.expr <- substitute(y)
  factvar.expr <- substitute(factvar)
  fv <- NULL
  fname <- NULL

  ##--------------------------------------------------------
  ## (a) formula interface: plotrend(y ~ x, data=df), and also
  ##     plotrend(y ~ x | factvar, data=df) ala xyplot()
  ##--------------------------------------------------------
  if(inherits(x,"formula")){
    lhs <- x[[2]]
    rhs <- x[[3]]
    if(is.call(rhs) && isTRUE(as.character(rhs[[1]])=="|")){
      xterm <- rhs[[2]]
      fterm <- rhs[[3]]
    } else {
      xterm <- rhs
      fterm <- NULL
    }
    yname <- deparse(lhs)
    xname <- deparse(xterm)
    mf <- stats::model.frame(
      stats::as.formula(paste(yname,"~",xname), env=environment(x)),
      data=data)
    yv <- mf[[1]]
    xv <- mf[[2]]
    if(!is.null(fterm)){
      if(!is.null(factvar))
        warning("factvar given both in the formula and in 'factvar'; the formula's '| factvar' is used")
      fv <- eval(fterm, envir=data, enclos=environment(x))
      fname <- deparse(fterm)
    }
  } else {
  ##--------------------------------------------------------
  ## (b) vectors interface: plotrend(x=df$varx, y=df$vary)
  ##--------------------------------------------------------
    if(is.null(y))
      stop("when 'x' is not a formula, 'y' must also be given; ",
           "or use the formula style: plotrend(y ~ x, data = df)")
    xv <- x
    yv <- y
    xname <- deparse(x.expr)
    yname <- deparse(y.expr)
  }

  ##--------------------------------------------------------
  ## the factvar argument (if not already set by the formula)
  ##--------------------------------------------------------
  if(is.null(fv) && !is.null(factvar)){
    if(is.character(factvar) && length(factvar)==1 &&
       is.data.frame(data) && factvar %in% names(data)){
      fv <- data[[factvar]]
      fname <- factvar
    } else {
      fv <- factvar
      fname <- deparse(factvar.expr)
    }
  }

  if(is.expression(xlab)){has.xlab <-1} else {has.xlab <-0}
  if(has.xlab==0){  
      if(prod(is.na(xlab))){has.xlab <-0} else {has.xlab <-1}
      }
  ## has.xlab
  if(has.xlab==1){xlab.h<-xlab}
    if(has.xlab==0){xlab.h<-xname}

 if(is.expression(ylab)){has.ylab <-1} else {has.ylab <-0}
 if(has.ylab==0){     
     if(prod(is.na(ylab))){has.ylab <-0} else {has.ylab <-1}
     }
   if(has.ylab==1){ylab.h<-ylab}
   if(has.ylab==0){ylab.h<-yname}

  ##--------------------------------------------------------
  ## no factvar: the usual base-graphics scatterplot + smoothfit
  ##--------------------------------------------------------
  if(is.null(fv)){
    graphics::plot(xv, yv, xlab = xlab.h, ylab = ylab.h,
                   bty="l",
                   col=col,
                   las=1,...)
    smoothfit(x=xv, y=yv,linecol=linecol,lwd=lwd,...)
    return(invisible(NULL))
  }

  ##--------------------------------------------------------
  ## with factvar: xyplot(vary~varx|factvar) + a smooth per panel
  ##--------------------------------------------------------
  dd <- data.frame(xrend=xv, yrend=yv, frend=factor(fv))
  lattice::xyplot(yrend ~ xrend | frend, data=dd,
                  xlab=xlab.h, ylab=ylab.h,
                  col=col, ...,
                  panel=function(x, y, ...){
                    lattice::panel.xyplot(x, y, ...)
                    lattice::panel.loess(x, y, col=linecol, lwd=lwd)
                  })
}
#+===========================================================

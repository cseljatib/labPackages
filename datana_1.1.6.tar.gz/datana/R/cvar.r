#' Computes the coefficient of variation for a numeric vector. For a
#' variable \eqn{y}, this coefficient it is
#' the ratio between the standard deviation (\eqn{\widehat{\sigma}_y})
#' and the sample mean (\eqn{\widehat{\sigma}_y}) of the variable \eqn{y},
#' as follows.
#' \deqn{{CV}_{y} = \frac{\widehat{\sigma}_y}{\overline{y}}}. 
#'  The coefficient of variaton it is a practical statistics to
#' compare the variability of random variables having different units
#' of measurement.
#'
#' @details Notice that is customary to also represent the coefficient
#' of variation in percentual terms, by multiplying the resulting
#' ratio to 100.
#'
#' @title Function to compute the coefficient of variation of a numeric vector
#' @param v is a numeric vector
#'
#' @return This function returns the coefficient of variation, a
#' numeric scalar.
#' @author Christian Salas-Eljatib.
#' @references
#' Salas-Eljatib, C. 2021. Análisis de datos con el programa
#'  estadístico R: una introducción  aplicada. Ediciones
#'  Universidad Mayor, Santiago, Chile. 170 p.
#'  \url{https://eljatib.com/rlibro}
#' @examples
#'
#' x.var <- rnorm(10, sd=10, mean=55)
#' cvar(x.var)
#' @rdname cvar
#' @export
#'
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
cvar <- function(v){
        stats::sd(v)/mean(v)
}

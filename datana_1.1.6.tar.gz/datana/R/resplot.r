resplot<-function(x,res,limits=NA,ylim=range(res),xlab="x",
                  ylab="res",main=""){
    plot(x,res,col="red",ylim=ylim,xlab=xlab,ylab=ylab,main=main)
    mywhiskers(x,res,add=TRUE,lwd=5,limits=limits)
    graphics::abline(0,0)
    mywhiskers(x,res,se=FALSE,add=TRUE,limits=limits)         
}

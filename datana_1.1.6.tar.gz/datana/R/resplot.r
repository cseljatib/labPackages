resplot<-function(x,res,limits=NA,ylim=range(res),xlab="x",
                  ylab="res",las=1, main="",...){
 plot(x,res,col="red",ylim=ylim,xlab=xlab,ylab=ylab,las=las,main=main,...)
 mywhiskers(x,res,add=TRUE,lwd=5,limits=limits);
 graphics::abline(0,0)
 mywhiskers(x,res,se=FALSE,add=TRUE,limits=limits);
}
#' # Creates a fake dataframe
#' set.seed(1234)
#' df <- as.data.frame(cbind(Y=rnorm(30, 30,9), X=rexp(30,rate=0.9)))
#' head(df)
#' descstat(df)
#' plot(Y~X, data=df)
#' # Fitting a candidate model
#' mod1 <- lm(Y~X, data=df)
#' #Using the resplot function
#' resplot(x = df$X, res=residuals(mod1))

#' Computes three statistics as a way to assess the prediction
#' capabilities of a model, based on comparing 
#' observed versus predicted values of a response variable
#' of interest. The statistics are the root mean square
#' differences (\eqn{RMSD}), the aggregated difference
#' (\eqn{AD}), and the absolute aggregated differences (\eqn{AAD}).
#'  All of them are based on 
#' \deqn{r_i = y_i - \widehat{y}_i}
#' where \eqn{y_i} and \eqn{\widehat{y}_i} are the observed and the 
#' predicted value of the response variable \eqn{y} for 
#' the \eqn{i}-th observation, respectively. Notice that both the
#' observed and the predicted values must be in the same measurement
#' units. Accordingly, the resulting values for the above detailed
#' statistics will be in those units.
#'  
#' @details The function computes the three aforementioned statistics
#' expressed in both (a) the units of the response variable and
#' (b) the percentage.  Notice that to represent each statistic
#' in percentual terms, we divided them by the mean observed value
#' of the response variable.
#' 
#' @title Function to compute prediction statistics based on observed
#' values
#' @param obs observed values of the variable of interest
#' @param pre predicted values of the variable of interest. That is
#' to say, if the response variable of a fitted model has a
#' transformation of the variable of interest, `pre` has to be
#' back-trasnformed to the original units of the variable of interest.
#' @param want.percent A logic option for requesting to also
#' computed the prediction statistics as a percentage of the sample
#' mean of `obs`. By default is set to FALSE.
#' @param want.n A logic option to add the
#' sample size `n` to the output. Bu default is set to FALSE
#' @param decnum the number of decimals to be used in the output. The
#' default is set to 6.
#' @param ... Passing all other potential options.
#'
#' @return The main output depends on the `want.percent`; if `TRUE`,
#' then it has the following six prediction statistics as a vector: 
#' (`rmsd`, `rmsd.p`,`ad`, `ad.p`,  `aad`, `aad.p`); where
#' `rmsd.p` stands for `RMSD` expressed as a percentage, and the
#' same applies to `AD.p` and `AAD.p`. Meanwhile,
#' if `want.percent=FALSE`, then it has the following three
#' prediction statistics as a vector: (`rmsd`,`ad`,`aad`)
#'  
#' @author Christian Salas-Eljatib.
#' @references
#' - Salas C, Ene L, Gregoire TG, Nasset E, Gobakken T. 2010. Modelling tree diameter
#'  from airborne laser scanning derived variables: a comparison of spatial statistical
#'  models. Remote Sensing of Environment 114(6):1277-1285. \doi{10.1016/j.rse.2010.01.020}
#'  
#' - Salas C. 2002. Ajuste y validación de ecuaciones de volumen para un 
#' relicto del bosque de roble-laurel-lingue. 
#' Bosque 23(2):81–92. \doi{10.4067/S0717-92002002000200009}. 
#' 
#' @examples
#'
#' # Creates a fake dataframe
#' set.seed(1234)
#' df <- as.data.frame(cbind(Y=rnorm(30, 30,9), X=rexp(30,rate=0.9)))
#' head(df)
#' descstat(df,y=c("Y","X"))
#' # Fitting a candidate model
#' mod1 <- lm(Y~X, data=df)
#' #Using the predstat function
#' predstat(obs=df$Y,pre=fitted(mod1))
#' # note the units of these statistics are the same of the Y variable.
#' # If you want to add the statistics in percentual units.
#' predstat(obs=df$Y,pre=fitted(mod1),want.percent = TRUE)
#'  # If some of the predicted values is missing (e.g. because of a
#' # missing predictor variable) the number of observations can be exported
#' df2 <- data.frame(yobs=df$Y,ypre=fitted(mod1))
#' df2[c(14,26), 2] <- NA
#' descstat(df2,y=c("yobs","ypre"))
#' #Notice the different sample size
#' predstat(obs = df2$yobs, pre = df2$ypre, want.n = TRUE)
#' #Thus, only 28 observations are used, as it should be.
#' @rdname predstat
#' @export
#'
##@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
predstat <- function(obs = obs, pre = pre, decnum=6,
                    want.percent = FALSE, want.n = FALSE,...) {
    df <- data.frame(obs, pre)
    df <- stats::na.omit(df)
    obs <- df$obs
    pre <- df$pre
    n<-nrow(df);
    res.y<-obs-pre
    res.y.2=(res.y)^2
    rmsd=sqrt( sum(res.y.2)/n ) #root mean square differences 
    rmsd.p=(rmsd/(mean(obs)))*100
    RMSD=c(rmsd,rmsd.p)
    ad=sum(res.y)/n #aggregated difference (AD) or mean residual
    ad.p=(ad/(mean(obs)))*100
    AD=c(ad,ad.p)
    aad=sum(abs(res.y))/n #aggregated of the absolute value differences 
    aad.p=(aad/(mean(obs)))*100
    AAD=c(aad,aad.p)
    output=round(c(RMSD,AD,AAD),decnum)
    names(output)=c('rmsd','rmsd.p','ad','ad.p','aad','aad.p')

    if(want.percent==FALSE){
        output=round(c(rmsd,ad,aad),decnum)
        names(output)=c('rmsd','ad','aad')      
    }
    if (want.n==TRUE) {
        output <- c(n, output)
        names(output)[1] <- "n"
    }
    output
}   

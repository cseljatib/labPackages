getfilename <- function() {
  file <- Sys.getenv("R_CONTEXT_FILE", unset = NA)
  
  if (is.na(file) || !nzchar(file)) {
    return(NA)
  }
  
  # Get filename only
  name <- basename(file)
  
  # Remove extension
  name <- tools::file_path_sans_ext(name)
  
  return(name)
}

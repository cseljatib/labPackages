getfilenamepath <- function() {
  file <- Sys.getenv("R_CONTEXT_FILE", unset = NA)
  if (!is.na(file) && nzchar(file)) {
    return(normalizePath(file))
  }
  return(NA)
}

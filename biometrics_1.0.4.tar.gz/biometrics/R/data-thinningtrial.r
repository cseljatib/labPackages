#' Stand variables by thinning treatment for secondary forests of _Drymis winteri_
#' near Valdivia, Chile.
#'
#' @description
#' The average of stand variables per thinning treatments applied to
#' secondary forest of _Drymis winteri_ in Hueicolla, in the Coastal
#' range of Valdivia (Chile). Data are measurements carried out during
#' 1986 and 1990. The thinning treatments are as follows:
#' distance among trees of 2 m, 3 m, y 4 m;  release thinning, and
#' control (i.e., no thinning).
#' The values are the mean of the following stand variables: density
#' (trees/ha), basal area (\eqn{^{2}}{^2}/ha) and volume (\eqn{^{3}}{^3}/ha).
#'
#' @usage
#' data(thinningtrial)
#'
#' @format
#' The dataframe has the following columns:
#' \describe{
#'   \item{treat}{Thinning treatment: distance among trees of 2m, 3m,
#' and 4m; release thinning; and control.}
#'   \item{time}{Year of measurement (1986 o 1990)}
#'   \item{nha}{Average density, in arb/ha.}
#'   \item{gha}{Average basal area, in m\eqn{^{2}}{^2}/ha}
#'   \item{vha}{Average volume, in m\eqn{^{3}}{^3}/ha.}
#' }
#'
#' @source
#' Data were derived from the tables number 4, 6 and 7, of the paper
#' of Navarro et al. (1997).
#'
#' @references
#' Navarro, C., Donoso, P., y Rosas, M. (1997). Crecimiento de renovales
#' de *Drymis winteri* sometidos a distintos tratamientos de raleo.
#' En: Donoso, C. (Ed.), Bosques templados de Chile y Argentina.
#' Editorial Universitaria, Santiago de Chile.
#'
#' @examples
#' data(thinningtrial)
#' head(thinningtrial)
#' df<-thinningtrial
#' require(lattice)
#' xyplot(nha~time|treat, data=df, type="b",as.table=TRUE)
#' xyplot(nha~time,groups=treat, data=df, type="b",auto.key = TRUE)
#' xyplot(gha~time|treat, data=df, type="b",as.table=TRUE)
"thinningtrial"

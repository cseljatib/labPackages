#' Ubicación cartesiana de árboles en el bosque de Llancahue 
#'
#' @description
#' Corresponde a la posición cartesiana, especie, y diámetro de árboles 
#' en una parcela de muestreo
#'  en el bosque de Llancahue, cerca de Valdivia, Chile. La parcela 
#'  es rectangular con
#'  dimensiones de 130 m por 70 m. Mayores antecedentes aparecen en 
#'  las referencias. 
#' @usage
#' data(llancahue2)
#' @format Contains tree-level variables, as follows:
#' \describe{
#'  \item{arb.id}{Identificador del árbol.}
#'   \item{spp}{Codificación de la especie como sigue: 
#'   "AP" es *Aextoxicon punctatum*, 
#' "EC" es *Eucryphia cordifolia*, 
#' "GA" es *Gevuina avellana*, 
#' "LP" es *Laureliopsis philippiana*, 
#' "LS" es *Laurelia sempervirens*, 
#' "ND" es *Nothofagus dombeyi*, "PS" es *Podocarpus saligna*, 
#' y "Ot" representa a cualquier especie distintat a cualquiera
#' de las ya definidas.}
#' \item{dap}{Diámetro a la altura del pecho, en cm.}
#' \item{coord.x}{Posición cartesiana en el eje-X, en m.}
#' \item{coord.y}{Posición cartesiana en el eje-Y, en m.}
#'  }
#' @source 
#'  Los datos fueron cedidos por el Prof. Daniel Soto de Universidad
#'  de Aysen (Coyhaique, Chile). 
#' @references
#' - Soto DP, Salas C, Donoso PJ, Uteau D. 2010. Heterogeneidad
#' estructural y espacial de un bosque mixto dominado por
#' *Nothofagus dombeyi* después de un disturbio parcial. 
#' Revista Chilena de Historia Natural 83(3): 335-347.
#' @examples
#' data(llancahue2)    
#' head(llancahue2) 
#' descstat(llancahue2$dap)
#' boxplot(dap~spp, data=llancahue2)
'llancahue2'
